
import os, sys, json, re, time, traceback, datetime, importlib.abc, importlib.util, runpy
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R3_TOY_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r3_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
import r3_resolve as RS
TRACE = CFG.get("trace")
PKG = os.environ.get("R3_TOY_PACKAGE")
DEPTH = [0]

def _stack():
    return traceback.extract_stack()[:-2]

def _launcher(st):
    names = [(os.path.basename(f.filename), f.name) for f in st]
    if ("a1_health.py", "run_system") in names:
        return "a1_health.run_system"
    if ("v2_solver.py", "callgrind_instructions") in names:
        return "v2_solver.callgrind_instructions"
    if ("v2_driver.py", "solve") in names:
        return "v2_driver.solve"
    if ("a1_pari.py", "curve_facts") in names:
        return "a1_pari.curve_facts"
    if ("v2_driver.py", "child_job") in names:
        return "v2_driver.child_job"
    return "other:" + ",".join("%s:%s" % n for n in names if n[0].startswith(("v2_", "a1_", "r3_")))[-160:]

def _log(ev, extra=None):
    if not TRACE:
        return
    st = _stack()
    rec = {"event": ev, "pid": os.getpid(), "package": PKG, "argv": sys.argv[1:4],
           "stack": ["%s:%d:%s" % (os.path.basename(f.filename), f.lineno, f.name) for f in st if "implementation-v2" in f.filename][-10:]}
    if extra:
        rec.update(extra)
    with open(TRACE, "a") as fh:
        fh.write(json.dumps(rec, default=str) + "\n")

sys.addaudithook(lambda ev, args: _log("import:" + args[0]) if ev == "import" and args and args[0] in ("cypari2", "sage.all", "sage") else None)
import cypari2
_Base = cypari2.Pari
class TracingPari(_Base):
    def __init__(self, *a, **k):
        _log("cypari2.Pari()")
        super().__init__(*a, **k)
    def __call__(self, s, *a, **k):
        m = re.search(r"ffgen\(Mod\(1, (\d+)\)\*\((.*?)\), 'w\)", str(s))
        ex = {"expr_head": str(s)[:160]}
        if m:
            ex["p"] = int(m.group(1))
            ex["field_degree"] = max(int(x) for x in re.findall(r"w\^(\d+)", m.group(2)))
        _log("cypari2.Pari.__call__", ex)
        return super().__call__(s, *a, **k)
cypari2.Pari = TracingPari

def _tag_of(argv):
    for i, x in enumerate(argv):
        if x == "-f" and i + 1 < len(argv):
            b = os.path.basename(argv[i + 1])
            return b[:-3] if b.endswith(".ms") else b
    return None

class Hook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"] and name != "v2_solver":
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"].get(_n, {}).items():
                setattr(module, k, v)
            if _n == "v2_solver":
                rc = module.run_child
                def run_child(argv, *a, **k):
                    st = _stack()
                    t0 = time.time()
                    rec = rc(argv, *a, **k)
                    t1 = time.time()
                    _log("child_end", {"child_argv0": os.path.basename(argv[0]), "child_flags": [x for x in argv if x in ("-P", "-g", "--tool=callgrind")],
                                       "msolve_in_argv": any(os.path.basename(x) == "msolve" for x in argv), "tag": _tag_of(argv),
                                       "launcher": _launcher(st), "inside_wrapper_original_call": DEPTH[0] > 0,
                                       "t_start": t0, "t_end": t1, "outcome": rec.get("outcome"),
                                       "rlimit_as_child_getrlimit": rec.get("rlimit_as_child_getrlimit")})
                    return rec
                module.run_child = run_child
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())

_orig_call_original = RS._call_original
def _traced_call_original(original, args, kwargs):
    site = R.SITE_S2 if getattr(original, "__name__", "") == "run_system" else R.SITE_S1
    tag = args[3] if len(args) > 3 else None
    t0 = time.time()
    DEPTH[0] += 1
    try:
        res = _orig_call_original(original, args, kwargs)
    finally:
        DEPTH[0] -= 1
    t1 = time.time()
    out = res.get("outcome") if site == R.SITE_S1 else res.get("v2_outcome_class")
    _log("original_call_end", {"site": site, "tag": tag, "t_start": t0, "t_end": t1, "gb_only": kwargs.get("gb_only"),
                                "callgrind_timeout": kwargs.get("callgrind_timeout"), "outcome": out,
                                "recorded_attempt_ok_with_callgrind_timeout": bool(site == R.SITE_S1 and kwargs.get("callgrind_timeout") and out == "ok"),
                                "has_instructions_callgrind": "instructions_callgrind" in res})
    return res
RS._call_original = _traced_call_original

# ---- DV-16 forcing (HR-9 (a)-(e)) on the r3_resolve indirections, at a1_health.run_system (development only)
CASE = os.environ.get("R3_FORCE_CASE") or "U"
SHIMLOG = CFG["shim_log"]
TARGET = CFG["target_tag"]
OFFSET = [datetime.timedelta(0)]
calls = {}
def slog(rec):
    with open(SHIMLOG, "a") as fh:
        fh.write(json.dumps(rec, default=str) + "\n")
if CASE != "U":
    _inner = RS._call_original
    def forced(original, args, kwargs):
        tag = args[3]
        if tag != TARGET or getattr(original, "__name__", "") != "run_system":
            return _inner(original, args, kwargs)
        k = calls[tag] = calls.get(tag, 0) + 1
        res = _inner(original, args, kwargs)
        out_dir = args[4]
        osha = None
        try:
            import hashlib
            osha = hashlib.sha256(open(os.path.join(out_dir, tag + ".ms.out"), "rb").read()).hexdigest()
        except OSError:
            pass
        real = {"v2_outcome_class": res.get("v2_outcome_class"), "v2_outcome_reason": res.get("v2_outcome_reason"), "pass": res.get("pass"),
                "D": res.get("dimension_of_quotient_printed"), "output_sha256": osha, "nvars": 3, "p": res.get("p")}
        force = (CASE in ("a", "c", "e") and k == 1) or CASE in ("b", "d")
        if force:
            si = res.get("solution_info") or {}
            res["v2_outcome_class"] = "degenerate_parametrisation"
            res["v2_outcome_reason"] = ("eliminating polynomial degree %s != quotient dimension %s (DV-16 FORCED by the development shim)"
                                        % (si.get("elim_degree"), res.get("dimension_of_quotient_printed")))
            res["pass"] = False
        if CASE == "c" and k == 2:
            res["input"]["sha256"] = "0" * 64
        if CASE == "d" and k == 2:
            OFFSET[0] += datetime.timedelta(seconds=float(RS._STATE["health_module"].DEV_TIMEOUT_S) + 1.0)
        slog({"case": CASE, "site": "a1_health.run_system", "tag": tag, "attempt": k, "forced": force, "clause_forced": "ii" if force else None,
              "real_result": real, "recorded_as": {"v2_outcome_class": res.get("v2_outcome_class"), "pass": res.get("pass")},
              "input_sha_forced": CASE == "c" and k == 2, "clock_offset_s": OFFSET[0].total_seconds()})
        return res
    RS._call_original = forced
    if CASE == "d":
        RS._now = lambda: RS._utc() + OFFSET[0]
    if CASE == "e":
        RS._wait_spacing = lambda prev_end: slog({"case": CASE, "wait_spacing_shimmed_away_after": str(prev_end)})

entry = CFG["entry"][os.environ["R3_TOY_ENTRY"]]
sys.argv = [entry] + sys.argv[1:]
runpy.run_path(entry, run_name="__main__")
