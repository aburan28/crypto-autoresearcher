import os, sys, json, hashlib, datetime, subprocess
REPO = "/home/user/crypto-autoresearcher"
EXP = os.path.join(REPO, "experiments/EXP-GFPN-05ff43")
FROZEN = ["specification.yaml", "amendments", "implementation", "implementation.md", "trial-plan.json",
          "implementation-v2", "implementation-v2.md", "trial-plan-v2.json",
          "implementation-v2-a1", "implementation-v2-a1.md", "trial-plan-v2-a1.json",
          "implementation-v2-r1", "implementation-v2-r1.md", "trial-plan-v2-r1.json", "trial-plan-v2-a1-r1.json",
          "implementation-v2-r2", "implementation-v2-r2.md", "trial-plan-v2-r2.json", "trial-plan-v2-a1-r2.json",
          "runs/RUN-GFPN-ac4487", "runs/RUN-GFPN-3377f1", "execution-report-v2.yaml", "analysis.md", "corrections"]
DEV = sorted(d for d in os.listdir(os.path.join(EXP, "dev-evidence")) if d != "stage-r3-dv")
FROZEN += ["dev-evidence/" + d for d in DEV]
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()
files = {}
for f in FROZEN:
    p = os.path.join(EXP, f)
    if os.path.isfile(p):
        files[f] = {"sha256": sha(p), "bytes": os.path.getsize(p), "mtime": os.path.getmtime(p)}
    elif os.path.isdir(p):
        for dp, dn, fn in os.walk(p):
            for x in fn:
                q = os.path.join(dp, x)
                files[os.path.relpath(q, EXP)] = {"sha256": sha(q), "bytes": os.path.getsize(q), "mtime": os.path.getmtime(q)}
    else:
        files[f] = {"missing": True}
pyc = [{"path": os.path.relpath(os.path.join(dp, x), EXP), "bytes": os.path.getsize(os.path.join(dp, x)),
        "mtime_utc": datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(dp, x)), datetime.timezone.utc).isoformat()}
       for dp, dn, fn in os.walk(EXP) for x in fn if x.endswith((".pyc", ".pyo")) or "__pycache__" in dp]
runs = sorted(os.listdir(os.path.join(EXP, "runs")))
st = subprocess.run(["git", "-C", REPO, "status", "--porcelain", "--untracked-files=all"], capture_output=True, text=True).stdout
head = subprocess.run(["git", "-C", REPO, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
out = {"taken_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "head": head, "git_status_porcelain": st.splitlines(),
       "frozen_roots": FROZEN, "n_files": len(files), "files": files, "byte_code_files": pyc, "runs_listing": runs, "n_runs_entries": len(runs)}
json.dump(out, open(sys.argv[1], "w"), indent=1)
print("baseline", out["taken_at_utc"], "files", len(files), "pyc", len(pyc), "runs entries", len(runs), "head", head, "status lines", len(st.splitlines()))
