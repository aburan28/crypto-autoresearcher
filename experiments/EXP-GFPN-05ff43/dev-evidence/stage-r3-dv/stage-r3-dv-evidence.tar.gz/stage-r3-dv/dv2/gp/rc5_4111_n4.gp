default(parisize, 256000000);
default(parisizemax, 4000000000);
print("R3GP N=", my(g = ffgen(Mod(1, 4111)*(12*w^0 + 3586*w^1 + 5*w^2 + 1*w^4), 'w)); my(E = ellinit([0, subst(2*w^0, 'w, g), 0, subst(1*w^2, 'w, g), subst(0, 'w, g)])); ellcard(E));
quit;
