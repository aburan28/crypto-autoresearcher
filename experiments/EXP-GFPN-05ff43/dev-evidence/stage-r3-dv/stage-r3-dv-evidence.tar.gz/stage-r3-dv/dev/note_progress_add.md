- 11:23:10Z DV-7 attempt 2 (full harness `r3_devchecks.py dv7`). Steps (1)-(2) complete. The SE-5 probe was run ONCE:
  toy G1 (fixture --p 1033) was completed_valid in world A (PYTHONHASHSEED "0") and in world B ("12345"). The **SE-5 verdict
  was PASS** (no REG-1-compared field differs), and REG-1 on a perturbed copy returned FAIL, as it must. Step (3): the toy G2
  (fixture --p 1039) ended `failed` / `implementation_error` (the frozen driver's AC-5 reading). In it, the toy raw_u and
  S3_rescaled systems kept the SSF signature (clause ii) on all six SE-3 attempts (K = 5; counters: 36 wrapped calls, 47
  attempts, 11 re-solves, 3 calls with an SSF attempt, 2 still SSF after the last attempt). R-7 then refused every later
  package, writing nothing. Step (4) crashed: the harness passed the checker an accounting path in a directory it had never
  created. Both are harness reasons (deviation RD-6). Preserved:
  `<scratchpad>/r3/dv_attempts/dv7_attempt2_toyG2_persistent_ssf_at_1039_and_accounting_dir_crash/`.
- 11:28:50Z a stray `implementation-v2-r3/__pycache__/r3_common.cpython-311.pyc` was written by an executor inspection
  command that imported `r3_common` without `-B` (the module disables byte-code writing only after its own import). It was
  found at 11:35Z and removed (sha256 99ef27a4…3eb0d). From then on, every inspection command uses `-B` (deviation RD-7).
- 11:33:57Z DV-7 attempt 3 was a continuation harness **outside the layer** (`<scratchpad>/r3/dev/dv7_resume.py`). It
  reused the RECORDED SE-5 packages and did not re-run the probe. The toy G2 prime was declared before launch by the rule
  "smallest prime p >= 2^16 with p = 1 (mod 3)" = 65539, with no further prime to be tried. R-6 refused every launch on the
  stray pyc, writing nothing, and the continuation then crashed on an import-path defect. Preserved:
  `<scratchpad>/r3/dv_attempts/dv7_attempt3_resume_R6_refused_stray_pyc_and_a1_toy_import/`.
- 11:35:36Z DV-7 attempt 4 (the same continuation, with the path fix). Toy G2 at 65539: `failed` /
  `infrastructure_error`. Every msolve child exited with returncode -11 (SIGSEGV) on the toy systems at p = 65539, with 0
  SSF attempts. A crash is never evidence. R-7 refused the rest (38 refusals, nothing written). The checker passed on
  world A G1 and on the toy G2; on world B G1 it failed only on the declared SE-6 override. Preserved:
  `<scratchpad>/r3/dv_attempts/dv7_attempt4_resume_toyG2_65539_msolve_segv/`.
- 11:48:34Z-11:53:48Z DV-7 attempt 5 (`<scratchpad>/r3/dev/dv7_resume5.py`). This is the continuation with a
  **SYNTHETIC toy G2 gate row**, treated as G3 and G4 already are, because the real toy G2 failed at both declared toy
  primes (deviation RD-8). 20 toy packages ran through the delivered wrapper and entries:
  - world A G1 and world B G1 (recorded in attempt 2), F-4, the v2 build, six cells and the v2 aggregate;
  - controls-a1 at 1021 through the r3 a1 entry, the addendum build, six cells and the a1 aggregate.

  All 20 were completed_valid. The checker returned rc 0 on every world-A package, and on world B G1 it failed only on
  the declared SE-6 override. RC-8 phase B: verified. DV-13 PASS over all 20 packages. getrlimit read 10737418240 in
  every child, threads were 1, and the PARI stack status was command_returned. **DV-7: PASS** (section 9).
- 11:54:17Z-12:03:57Z DV-12 (cases U, a..g, through the delivered wrapper and entry with a development forcing shim):
  **PASS (a)-(g)**.
- 12:04:05Z DV-16 attempt 1: a harness defect. The shared case runner never set the in-process REG-1 reference id, so
  REG-1 looked for RUN-GFPN-ac4487 in the toy world, and the run crashed before any child. Preserved:
  `<scratchpad>/r3/dv_attempts/dv16_attempt1_harness_reg1_reference_not_set_in_process/`. Fix in `r3_dv16.py` only
  (deviation RD-10). 12:04:54Z-12:05:46Z DV-16 attempt 2 at the declared toy prime 1021: **PASS (a)-(e)**.
- 12:06Z `r3_inventory.py` (the R3S-10 consumer inventory) was copied into the layer from `<scratchpad>/r3/dev/`, where
  it had been developed and tested read-only. 12:06:01Z DV-15: **PASS** (set O 75, toy lineage 596 rows, 0
  violations). A supplementary DV-15 (b) over the 14 DV-12 / DV-16 case packages found 0 violations (report only).
- 12:07:11Z DV-11: **PASS**. Static launch list = S-1, S-2, S-3, with 0 r3 launch sites. Dynamic counts were all equal.
  R3S-10 inventory: 199 listed functions, 0 stops.
- 12:08:08Z DV-17 attempt 1: a harness defect (wrong receipt path) at start-up, before any child. Preserved (deviation
  RD-11). 12:08:42Z-12:31:47Z DV-17 attempt 2 (detached, quiet machine; 0 other
  solver processes before every launch): **PASS**. 360 calls, 0 compared-field differences, every getrlimit
  10737418240 / 10737418240, minimum spacing 2.006 s, 0 log-visible SSF indicators.
