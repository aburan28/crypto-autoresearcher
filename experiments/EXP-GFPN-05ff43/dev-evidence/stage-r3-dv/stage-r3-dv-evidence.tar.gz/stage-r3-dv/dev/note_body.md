
## 1. Stage outcome, scope and binding

- **Outcome.** Every check DV-1..DV-17 ran and is recorded. Outcomes are in section 9. {{STOP_LINE}} **No run package
  was created** (`maximum_runs: 0`). Nothing under `runs/` was written. No tracked file was modified. No git write
  was made. A development check reports no number as a result: every D, degree and count in the scratch outputs is a
  harness value.
- **Binding.** The nine amendment files were hashed at stage start (10:42:19Z). All nine equal the card's
  `nine_hashes` (DEC-20260924-e52eec VA-1), and `r3_common.BOUND_HASHES` carries the same nine values (R-1):
  - `v1_to_v2_reanchor_and_arm_iii.yaml` e02d4976a5e773b9eee95aa4c376d6154e9c0a9da4e6c6118ed58748054924d3
  - `v2_addendum_rung31.yaml` 2c5e052468e37111023dd116706149fb05d691e7188e26ae1e2c069bad792d0c
  - `v2_addendum_paristack.yaml` 856fdc1d7b71da0cd9073634066dcb2a9a66d69cd10adf4ff5a738f2618390c7
  - `v2_addendum_seedresolve.yaml` dc714a446a22a99fd6762196d4e6ad1b8c9e7eb3920d64cf26036f95ecadee81
  - `v2_addendum_solverevent.yaml` 011d4b2c11f99d696281ccfdd4d65ece4fefcc6ae71de3de813049bbeb2d9b7f
  - `v2_addendum_healthresolve.yaml` ccb55334c542c809b8526e54a2985627a44c435e5ca68a14ef5f6a779291a70d
  - `v2_addendum_launchcover.yaml` c27ffe5c15d13d1c1137bdba11944ac53f0e91c79d8f460a5d2b18066ca5f447
  - `v2_addendum_consumercover.yaml` a900d757980b379c301393d51bde008847f5280fd0b6ac237ae1f67efce4eee0
  - `v2_addendum_valueclose.yaml` 877c5b898921812cd4da2c35a905a423ecd77bdbe204c73e902b459829e8e4f1
- **Dispatch preconditions as found (cited, not re-derived):**
  - DP-1: HEAD 5505464a9.
  - DP-2: memory guard pid 875, kills at MemAvailable < 2,621,440 kB (above 12.0 GB), so the child cap stays at
    10737418240.
  - DP-3: lane held by the dispatcher (claim at 5505464a9, epoch 1, expiring 2026-09-25T10:41:20Z).
  - DP-4/DP-5: toolchain msolve 0.6.5-1build2, valgrind 3.22.0, callgrind_annotate-3.22.0 at /usr/bin, gp 2.15.4
    (pari-gp 2.15.4-2.1build1).
  - DP-6/DP-7: machine quiet at dispatch. It was also quiet at the DV-17 launch (12:08Z): no other msolve, valgrind,
    gp or Sage process ran, and MemAvailable was 15623272 kB.
- **Read, and nothing else under `runs/`:** RUN-GFPN-ac4487 (REG-1 reference; DV-8, DV-15, DV-17) and
  RUN-GFPN-3377f1 (the DV-3 reproduction reference).
- **Read-only inputs:**
  - the frozen trees `implementation-v2/` and `implementation-v2-a1/`;
  - the r2 files (templates only, never imported) and `implementation-v2-r1/r1_toy.py` (template for the DV-7 toy
    constructions, never imported);
  - `dev-evidence/launch-census/`, `dev-evidence/launchcover-premise/`, `dev-evidence/seedresolve-premise/`,
    `dev-evidence/solver-characterization/` and `dev-evidence/stageR1-dv7/`;
  - the goal archives' receipts.
- **Inference.**
  - `requested_policy: executor-implementation`
  - `resolved_model_id: null` (none was supplied; none is invented)
  - `fallback_used: false`
  - `bedrock_used: false`
  - Network: not used.

## 2. Files written (the exact list; for each r3 file, the r2 file and sha256 it started from, or "new")

{{FILES_TABLE}}

No other path inside the repository was written. Every scratch output is under `<scratchpad>/r3/` (section 15).

## 3. PS-1: the branch, the values, the API and the RC-2 read-back semantics

- **Branch.** PS-1 branch **P-A**: parisize 67108864 and parisizemax 536870912. Both entries configure cypari2's
  process-wide PARI stack in `r3_common.PariStack.configure` before any v2 or v2-a1 module is imported (RC-2 (c)).
  The P-B trigger did not fire, so `v2_common.curve_order_pari` is not replaced.
- **API.** `cypari2.Pari()` construction with the requested sizes, followed by `allocatemem`. Read-backs use
  `default(parisize)`, `default(parisizemax)`, `stacksize()` and `stacksizemax()` on a fresh handle.
- **RC-2 (a) start read-back.** This runs immediately before dispatch. The entry exits 2 before any command unless the
  handle reads 67108864 / 536870912.
- **RC-2 (b) exit read-back.** This goes to `pari-stack.json`, with VmHWM / VmRSS. The exit semantics are
  **"requested"** (semantics probe, 10:59Z):
  - after growth of the stack on the same handle (to 268435456, within 536870912), `default(parisize)` still reads
    the requested 67108864;
  - a fresh handle reads 67108864 / 536870912.

## 4. DV-2, DV-3, DV-4 and the semantics probe (10:59:13Z-10:59:17Z; no number is a result)

- **DV-3 PASS.** Without the layer's configuration, the in-process `ellcard` at (16777291, n = 3) overflowed. The
  read-back before the call was 8000000 / 8003584, and the exception was "ellcard: the PARI stack overflows
  (current size: 8003584; maximum size: 8003584)". This reproduces RUN-GFPN-3377f1.
- **DV-2 / DV-4 PASS** at (4111, 3), (16777291, 3) and (4111, 4), two repetitions each, through the delivered r3
  configuration code: every start read-back exact, the call returned, and every exit read-back is "requested".
- **RC-5 cross-checks** at (16777291, 3) and (4111, 4). The in-process order agrees with a gp child:
  `gp -q -f --default nbthreads=1`, RLIMIT_AS 10737418240 set in the child, and getrlimit read back
  {10737418240, 10737418240}. These orders are fixture parameters, not results; the values are in the bundle
  (`dv2/dv2.json`).

## 5. RC-3 redirections, the SE-3 and HR-3 replacements (in-process only), and the read-backs

| entry | attribute | frozen value | r3 value | set when |
| --- | --- | --- | --- | --- |
| r3_entry_v2 | `v2_common.PLAN_PATH` | `experiments/EXP-GFPN-05ff43/trial-plan-v2.json` | `experiments/EXP-GFPN-05ff43/trial-plan-v2-r3.json` | after `import v2_common`, before `import v2_driver` |
| r3_entry_v2 | `v2_common.TASK_ID` | the frozen v2 task id (a forbidden id; `FORBIDDEN_TASK_IDS`) | TASK-20260924-4351ac | same |
| r3_entry_v2 | `v2_driver.solve` (SE-3) | the frozen function (v2_driver.py line 158) | `r3_resolve.solve`, which calls the recorded ORIGINAL | after `import v2_driver`, before dispatch |
| r3_entry_a1 | `a1_common.PLAN_A1_PATH` | `.../trial-plan-v2-a1.json` | `.../trial-plan-v2-a1-r3.json` | before `import a1_driver` |
| r3_entry_a1 | `a1_common.V2_PLAN_PATH` | `.../trial-plan-v2.json` | `.../trial-plan-v2-r3.json` | before `import a1_driver` |
| r3_entry_a1 | `a1_common.RECEIPT_V2_PHASE_B` | the TASK-20260923-0fa03f post-run receipt | `coordination/goals/GOAL-GFPN-380702/archives/TASK-20260924-f1fb0e/post-run-receipt.json` (RC-8; VC-6 (c)) | before `import a1_driver` |
| r3_entry_a1 | `a1_common.V2_GATE_PACKAGES` | (RUN-GFPN-ac4487, RUN-GFPN-3377f1, RUN-GFPN-76420e, RUN-GFPN-b231c1) | (RUN-GFPN-f6a21a, RUN-GFPN-902222, RUN-GFPN-f5412a, RUN-GFPN-bfe956), read from `trial-plan-v2-r3.json` `gate.blocking_packages` | before `import a1_driver` |
| r3_entry_a1 | `a1_common.TASK_ID_RUNS` | the frozen v2-a1 task id (a forbidden id) | TASK-20260924-b3e690 | before `import a1_driver` |
| r3_entry_a1 | `a1_common.PROTOCOL_VERSION` | "2-a1" | "2-a1-r3" | before `import a1_driver` |
| r3_entry_a1 | `v2_common.PLAN_PATH` | set by `a1_common.redirect_v2()` at a1_driver import | = the redirected PLAN_A1_PATH; never set to trial-plan-v2-r3.json | by redirect_v2 (a1_driver.py line 30) |
| r3_entry_a1 | `v2_common.TASK_ID` | redirect_v2's definition-time default (a forbidden id) | TASK-20260924-b3e690 | AFTER `import a1_driver` |
| r3_entry_a1 | `v2_driver.solve` (SE-3; a1_driver's `D`) | the frozen function | `r3_resolve.solve` | after `import a1_driver`, before dispatch |
| r3_entry_a1 | `a1_health.run_system` (HR-3) | the frozen function (a1_health.py; argv line 144, launch line 147) | `r3_resolve.run_system`, which calls the recorded ORIGINAL | after `import a1_driver` (a1_driver imports a1_health at its line 38), before dispatch |

- **Read-back.** It runs after all imports, immediately before dispatch, and goes into `pari-stack.json` under
  `redirections`. It includes the replacement keys:
  - "v2_driver.solve (SE-3 replacement)" (both entries);
  - "a1_health.run_system (HR-3 replacement)" (a1 entry);
  - "a1_health (HR-3: not imported in the v2 entry)" (v2 entry; the v2 entry refuses if a module named a1_health is
    loaded).
- **Refusal.** Each replacement is refused (exit 2, before any command) if the attribute was rebound after install,
  or if the recorded original is not the frozen function. For HR-3 it is also refused if `a1_driver`'s `H` is not
  the frozen `a1_health` module.
- **VA-7 (a).** A redirected value equal to, or containing, one of the six forbidden task ids is refused
  (`r3_common.check_redirections`).
- **Checker isolation.** `r3_check_run.py` runs the frozen `v2_check_run.main` / `a1_check_run.main` in a SEPARATE
  process, with only the redirections applied.

## 6. The two re-solve wrappers and the callgrind-site recording (`r3_resolve.py`)

- **SE-3 at S-1 (`v2_driver.solve`)** and **HR-3 at S-2 (`a1_health.run_system`)** share one bounded loop, `_bounded`.
  - The SSF signature is SF-1 clauses (i)-(v).
  - K = 5 re-solves, so at most six attempts.
  - Each attempt starts at least 2.0 s after the previous attempt's recorded end.
  - Before each re-solve, the attempt's output and log files are renamed with the suffix `.ssf-attempt<k>`.
  - Every attempt has the same cap and timeout as attempt 1.
  - The re-solve cap is SF-2 (c) at S-1 (the call's `timeout_s`) and HR-6 at S-2 (`a1_health.DEV_TIMEOUT_S`, read at
    call time; 1800).
  - SE-2 (4) / HR-5 consistency: a violation raises `SolverEventConsistencyError`, the package ends `failed` /
    `implementation_error`, and the violation is recorded.
  - At S-1, `gb_only=True` calls pass through unwrapped and are counted (`passthrough_calls_gb_only_true`).
- **CG-3 with CC-4 at S-3 (the callgrind child).** S-3 is NOT re-solved (CG-2).
  - After each ORIGINAL S-1 call whose result carries `instructions_callgrind`, the wrapper records the CG-3 fields
    under site "v2_driver.solve/callgrind":
    - `tag` and `attempt_recorded_by_the_wrapper`;
    - the log files' sha256 and size, or "absent";
    - `dimension_of_quotient`;
    - `fglm_squarefree_degree`, which is "absent" when the key is absent (CC-4; CC-8 (a));
    - `positive_dimension_reported`, `random_linear_form_string_in_log` and `log_visible_ssf_indicator`;
    - `printed_quotient_dimension_equals_recorded_attempt`, `reg1_compared_fields_verbatim` and
      `child_readback_equals_requested_cap`.
  - It also keeps the counts `callgrind_children_observed`, `with_log_visible_ssf_indicator`,
    `with_quotient_dimension_mismatch` and `with_readback_differing_from_requested_cap`.
  - No field is added to `raw-result.json`, and nothing reads these values to decide anything (VA-6 (c)).
- **The record.** `solver-events.json` at the run root has:
  - `sites`, with one entry per site: disposition, counters, and events or records;
  - a top-level `consistency_violation`.

  The manifest's `solver_events` block is per site. The event-record writer `_write` has no guard (VA-7).
- **VA-6.**
  - The whole-file sha256 of `solver-events.json` is V-7.
  - Exists, parses, the flag, and the S-1 / S-2 counters are epsilon.
  - V-5 (the CG-3 records and counts) is recorded and reported only.
- **VA-7.**
  - Task-id keys are checked by constant key (`r3_check_run.forbidden_id_keys`).
  - The byte sweep (`forbidden_id_sweep`) reads only `command.txt`, `stdout.log`, `stderr.log`, `environment.json`
    and `pari-stack.json`.
- **VA-8 (b).** Each guard is a separate function with its own class.
- **Readings adopted (disclosed; section 14):**
  - RD-1: the VA-7 "site value" is a site-record field (census M-3: "a key the site record does not carry cannot read
    site data").
  - Derived tokens can therefore appear in the swept files without being site values: PASS / FAIL in `stdout.log`,
    the `pari-stack.json` status, and a `SolverEventConsistencyError` traceback in `stderr.log`.
  - This reading is disclosed, not a STOP.

## 7. The r3 run wrapper, the r3 checker, the plans and REG-1

- **`r3_run_wrapper.py` (R-1..R-13).** Before ANY directory is created, the wrapper evaluates every check and
  refuses (exit 2, nothing written, every failing reason printed) unless all hold:
  - R-1: the nine hashes above.
  - R-2: the RUN-ID is reserved in its r3 plan, and is not a v1, v2, v2-a1, r1 or r2 id, nor any of the 124 retired
    ids.
  - R-3: `runs/RUN-ID` does not exist.
  - R-4: `implementation-v2/`, its note and its plan match the TASK-20260923-0fa03f phase-A receipt, and are tracked
    and clean.
  - R-5: the same for `implementation-v2-a1/`, against the TASK-20260923-4ff597 phase-A receipt.
  - R-6: the same for the r3 layer, this note and both r3 plans, against the TASK-20260924-f1fb0e phase-A receipt.
  - R-7: the PS-4 gate rule:
    - G1..G4 `completed_valid` with `gate_pass` true, and REG-1 (d-parsed) passed;
    - REG-1 is evaluated before G2 and before every later package;
    - addendum packages 2-11 also need the controls_a1 image passed.
  - R-8: every required package has a manifest.
  - R-9: the plan's watchdogs equal `trial-plan-v2.json`'s.
  - R-10: no other solver-like process.
  - R-11: the ceiling over the EIGHT plans (existing + 1 <= 48; currently 2 + 31 + 11 = 44), and the plan's own
    count.
  - R-12: the contingency rule verbatim.
  - R-13: the plan records its label, the ids and sha256 of the seven repair amendments (`repair.amendments.<key>`)
    and its run card. None of the six forbidden task ids appears in the plan, and no r3 constant or redirected value
    carries one (VA-7 (a)).

  Other properties:
  - The preflight is split into single-class helpers (`r7_gate_packages`, `r7_reg1_verdict`, `r7_controls_a1_image`,
    `r8_requires`, `r12_contingency`).
  - The driver child runs with PYTHONHASHSEED "0" (SE-6), read back inside the driver process into the manifest.
  - `environment.json` records the toolchain including `callgrind_annotate`.
  - Launch rule: no outer guard around the wrapper.
- **`r3_check_run.py`.**
  - It runs the frozen checkers in a separate process (section 5).
  - It adds the r3 checks, one class per function: `manifest_protocol_checks`, `pari_stack_checks`,
    `events_file_epsilon`, `events_file_integrity`, `reg1_recorded_check`, `forbidden_id_keys`, `forbidden_id_sweep`
    and `status_agreement`.
  - It adds the SC-4 accounting at BOTH sites: S-1 attempts, and S-2 through `health/health-<p>.json`. The accounting
    is reported only.
- **Plans.** Both plans were written once by `r3_make_plans.py --write` at 11:01:16Z (RC-4 (c) equality asserted in
  the writer). They hold 31 and 11 packages; the branch P-A; the VA-1 repair block; the 124 retired ids; and the
  ceiling note. RC-4 is covered in the two sections at the top of this note; the sha256 values are in section 2.
- **REG-1.**
  - `r3_reg1.py` is the r2 comparator (d-parsed; exclusion list X1..X17), unchanged except `solver_events_check`,
    which reads the S-1 / S-2 events and the flag by constant key.
  - `reg1-exclusion-list.json` is a byte copy (sha256 4122bcb06c1c1bdd7613ef20fa62d09207916badf7786ad3c314a04094a99f2c;
    DV-8).
  - Every reference file read is verified against the TASK-20260923-0fa03f post-run receipt first.

## 8. DV-1 inventory, the HR-11 / CC-1 site concordance and the R3S-10 consumer inventory

**DV-1 (static; 11:15:01Z; flags from the frozen code):**

- **v2 fixture:** `v2_driver.main -> cmd_fixture (275) -> fixture_core (284) -> C.curve_order_pari (308)`. IN-PROCESS
  cypari2, at (4111, n = 3) and (16777291, n = 3). Covered by P-A (DV-2).
- **v2 controls:** `cmd_controls (752) -> C.fixture_n3(4111) (764) -> C.curve_order_pari (771)`. IN-PROCESS, at
  (4111, n = 3). Covered by DV-2.
- **v2 fixture4:** `cmd_fixture4 (526) -> C.fixture_n4 -> C.curve_order_pari (542)`. IN-PROCESS, at (4111, n = 4).
  Covered by DV-4.
- **v2 anchor-identity:** `cmd_anchor_identity (628) -> V.run_child(SAGE_PYTHON, COMPARATOR) (650)`. **FLAGGED**: a
  Sage child with a PARI-backed GF(p^5) and a library-default stack (DEC-20260924-bea197 R-5).
  - The Sage probe child (RLIMIT_AS set in the child; getrlimit read back {10737418240, 10737418240}) reads parisize
    8000000, parisizemax 1073741824, Sage 10.9.
- **v2 build / cells / aggregate:** builders in capped `v2_child.py` children, msolve children, and file reads. No
  PARI.
- **a1 controls-a1:** `cmd_controls_a1 (56) -> P.curve_facts (89) -> V.run_child(/usr/bin/gp)`. A gp CHILD, with
  parisize 256000000 / parisizemax 4000000000 set in its script (a1_pari.py line 38), and no random seed set
  (CG-9 (f)).
- **a1 build / cells / aggregate-a1:** these delegate to the v2 commands or read files. No PARI.
- **r3 layer:** `PariStack` constructions, `allocatemem` and default read-backs only. No computation.
- **callgrind_annotate (S-3):** `v2_solver.callgrind_instructions` line 533 runs `subprocess.run(["callgrind_annotate",
  ...])`. It uses a PATH lookup, a 600 s timeout, and is uncapped in the frozen code. It is not an msolve, valgrind, gp
  or builder child, and is recorded as an observation.
- 235 static PARI / Sage / gp mentions in the frozen trees are listed in `dv1/dv1_static.json` (bundle).

**DV-1 dynamic (DV-7 trace, 1499 events):**
- In-process PARI calls occur only in `curve_order_pari`: for toy G1 (both worlds) at (1033, degree 3), and for F-4
  at (1033, degree 4).
- `cypari2.Pari()` constructions come only from `r3_common` (configure, start_readback) and `curve_order_pari`.
- Children by launcher:
  - `v2_driver.solve` -> msolve;
  - `a1_health.run_system` -> msolve;
  - `v2_solver.callgrind_instructions` -> valgrind;
  - `a1_pari.curve_facts` -> gp;
  - `v2_driver.child_job` -> python3 builders.

**DV-11 (12:07:11Z; PASS; no STOP):**
- **STATIC.** The msolve launch list over `implementation-v2/`, `implementation-v2-a1/` and the r3 layer EQUALS the
  CC-1 sites:
  - S-1 at v2_driver.py 166;
  - S-2 at a1_health.py 147;
  - S-3 at v2_driver.py 209 (argv) and v2_solver.py 517 (launch).

  There are 0 unexpected launch calls and **0 r3-layer launch sites** (HR-11 / CC-1 concordance: no r3 file adds a
  launch site). The census sites of CN-1 outside the two frozen trees are "unreachable (U-1..U-5 of CC-1)".
- **Scope disclosure.** The development harnesses that call the frozen launch functions, namely DV-17's
  `callgrind_instructions` calls and the DV-7 continuations' wrapper calls, live OUTSIDE the layer in
  `<scratchpad>/r3/dev/` (RD-2). No delivered entry can reach them.
- **DYNAMIC** (over the 20 DV-7 attempt-5 toy packages; every per-package count equal):
  - 562 S-1 msolve children = 562 wrapper attempts (+ 0 pass-through);
  - 2 S-2 msolve children = 2 wrapper attempts;
  - 90 S-3 valgrind children = 90 wrapped ok calls with a callgrind timeout = 90 CG-3 records. Every S-3 child lies
    inside a wrapped-call interval and every one has a CG-3 record;
  - 0 classified launches outside both wrappers; 0 other msolve children.
- **Supplementary (report only):** the same count logic applied to the two preserved real toy G2 packages.
  - p = 1039: 47 msolve children = 47 wrapper attempts, including 11 real SSF re-solves; 34 valgrind children = 34
    CG-3 records.
  - p = 65539: 36 = 36; 0 valgrind children.
  - Both are equal (`dv11_extra/`).
- **R3S-10 consumer inventory** (`implementation-v2-r3/r3_inventory.py`; `dv11/inventory/inventory.json` in the
  bundle): 222 functions parsed and 199 listed, each with exactly one class. Counts:

  | class | functions |
  | --- | --- |
  | alpha | 73 |
  | reads no site value | 53 |
  | epsilon | 27 |
  | gamma | 17 (each naming its clause) |
  | reads no site value directly | 6 |
  | beta | 5 |
  | V-1 row K-1 (CG-4) | 5 |
  | V-4 | 3 |
  | V-7 | 2 |
  | V-2 | 2 |
  | V-2 (CG-4) | 2 |
  | V-5 | 2 |
  | V-1 row K-5 | 1 |
  | V-1 row K-2 | 1 |

  The results:
  - 0 unclassified functions;
  - 0 imports from `implementation-v2-r1/`, `implementation-v2-r2/` or `implementation/`;
  - 0 consumers of a V-5 value at E1-E4;
  - 0 consumers using an epsilon value to choose a recorded result;
  - **stops: none**.
- **Class rule (declared).** A function's class is that of the site values it reads DIRECTLY. Orchestrators are
  "reads no site value directly". Development-check functions carry effect E6 under DEV_RULE.

## 9. DV-1..DV-17 outcomes (development observations; no number is a result)

| check | outcome | when (UTC) | notes |
| --- | --- | --- | --- |
| DV-1 | complete | 11:15:01Z static (attempt 2); dynamic from DV-7 | section 8; attempt 1 harness fault (RD-4) |
| DV-2 | PASS | 10:59Z | section 4 |
| DV-3 | PASS | 10:59Z | overflow reproduced without the layer's configuration |
| DV-4 | PASS | 10:59Z | (4111, n = 4) |
| DV-5 | PASS | 11:09Z | plans: M a bijection onto the 42 minted ids; images disjoint from the frozen, r1, r2 and 124 retired ids; the writer regenerates byte-identically |
| DV-6 | PASS (attempt 2) | 11:13Z | 57 wrapper cases (R-1..R-13 incl. the nine hashes, a 175-id R-2 sweep, all seven repair amendments, the six forbidden ids, VA-7 (a)), 13 entry cases (PARI, RC-3, SE-3 (a)/(b), HR-3 attribute / original / `H`, v2 entry with a1_health imported, VA-7 redirection); attempt 1 an implementation defect in R-13 (RD-3) |
| DV-7 | PASS (attempt 5) | 11:23:10Z-11:53:48Z | SE-5 probe run ONCE (attempt 2): PASS; REG-1 on a perturbed copy FAIL (as required); RC-8 phase-B check verified; controls-a1 at 1021 through the r3 a1 entry; checker on every toy package; attempts 1-4 preserved (RD-5..RD-9) |
| DV-8 | PASS | 11:10Z | exclusion list byte-identical to X1..X17 (sha256 4122bcb0…94a99f2c); self-comparison PASS; every perturbation FAIL; reference-integrity negative FAIL as required; 219 reference files verified |
| DV-9 | {{DV9_OUTCOME}} | {{DV9_TIME}} | section 15 |
| DV-10 | PASS | 11:09Z | 42 distinct ids, equal to the allocator outputs in order; none in any existing plan or retired list; no run directory |
| DV-11 | PASS | 12:07:11Z | section 8 |
| DV-12 | PASS (a)-(g) | 11:54:17Z-12:03:57Z | section 10 |
| DV-13 | PASS | DV-7 attempt 5 | the driver child's PYTHONHASHSEED read back "0" in every world-A toy package (19) and "12345" in world B's G1 (the declared SE-5 override); also "0" in the preserved toy G2 packages |
| DV-14 | PASS | DV-7, DV-12, DV-16 | every re-solve attempt started >= 2.0 s after the previous attempt's end: the toy lineage's 11 real re-solves (preserved attempt-2 toy G2; minimum gap 2.010 s), and every forced re-solve of the DV-12 / DV-16 cases that check spacing ((a)-(d) and (a)-(b); all `spacing_ge_2s` true); DV-7 attempt 5 had 0 re-solves |
| DV-15 | PASS | 12:06:01Z | set O 75 outputs (73 ok-classified), 596 toy-lineage rows, invariant holds on every applicable output, 0 violations; section 11 |
| DV-16 | PASS (a)-(e) (attempt 2) | 12:04:54Z-12:05:46Z | toy prime 1021 declared before the check; attempt 1 a harness defect (RD-10) |
| DV-17 | {{DV17_OUTCOME}} | {{DV17_TIME}} | section 12 |

**DV-7 details.**
- **Toy objects.** Toy primes only; no ladder or fixture prime was solved except DV-17's calls at 4111.
  - n = m = 3 fixture data at 1033 and 1039, plus 65539 for the attempt-4 continuation.
  - n = m = 4 data at 1033.
  - Toy ladder rungs chosen by the frozen `a1_toy.toy_ladder` through capped gp children: 1021 (addendum role), and
    1051 (v2 role; 1031 was incomplete, as recorded in the selection trail).
- **Not exercisable at toy scale (recorded, not run):**
  - `anchor-identity`: it hard-codes p' = 16777291 and the Sage anchor system.
  - `controls`: it hard-codes the fixture field at 4111 and ladder primes 4111, 262151 and 16777291.
  - Their gate roles G3 and G4 are SYNTHETIC rows.
  - The v2 builds and cells at 262151 and 16777291 are SYNTHETIC rows.
  - Contingency launches are covered by DV-6's R-12 refusals.
- **Toy G2 (RD-6, RD-8).** The real toy G2 ran twice and failed at both declared toy primes:
  - p = 1039: persistent SSF signature on all six attempts of two calls;
  - p = 65539: msolve SIGSEGV on every child, classified `crashed` / infrastructure_error, never evidence.

  Both packages are preserved, and the checker passed on the 65539 package. Attempt 5 exercised the lineage past
  the gate on a SYNTHETIC toy G2 row. **Consequence, stated plainly:** R-7's REG-1 comparison for a real, passing
  toy G2 was not exercised. R-7's refusal of a failed G2 WAS exercised, in attempts 2 and 4: 38 correct refusals
  each, nothing written.
- **The 20 packages run through the delivered wrapper and entries in attempt 5:**
  - world A: G1, F-4, the v2 build, six cells, the v2 aggregate, controls-a1, the addendum build, six addendum cells
    and aggregate_a1;
  - world B: G1.

  All are `completed_valid`. Every child read getrlimit 10737418240 / 10737418240, msolve threads were 1, and the
  PARI stack status was `command_returned`. The checker returned rc 0 on every world-A package; on world B's G1 it
  failed only on "SE-6: the driver process read back PYTHONHASHSEED '12345', not '0'" (the declared override).
- **Forbidden task ids in toy artifacts (report only).** One occurrence, in the toy COPY of the frozen
  `trial-plan-v2.json`, which carries its own frozen task id.

## 10. DV-12 (a)-(g) and DV-16 (a)-(e) (forced cases through the delivered wrapper; development shims)

{{DV12_16}}

## 11. DV-15 per-output table (SC-3; frozen v2_solver imported read-only; no solver child)

- The invariant, checked on every ok-classified parametrised output: n_den_zero = n_arity = 0 and n_distinct =
  n_points = n_roots.
- The integrity inputs were each verified against their receipts first:
  - the characterization archive `distinct-outputs.tar.gz`;
  - the stage-R1 DV-7 bundle;
  - the seedresolve premise check;
  - RUN-GFPN-ac4487 `solver/`.
- Table (b) covers the 22 non-synthetic toy-lineage package directories: the 20 of DV-7 attempt 5 and the two
  preserved real toy G2 packages. It includes both sites.
- Rows with parse kind "none" are not parametrisations; the invariant does not apply to them, and they are listed.
- Degree columns are omitted here and kept in the bundle (`dv15/dv15.json`) as harness values.
- Supplementary (report only): the same accounting over the 14 DV-12 / DV-16 case packages gives 222 rows, 222
  applicable, 0 violations (`dv15_supp_dv12_dv16/`).

{{DV15_TABLE}}

## 12. DV-17 (launchcover CG-5 (a)-(g); CC-8 (b), (d))

{{DV17_SECTION}}

- **Over all 360 calls:**
  - 0 other solver processes were seen before any launch;
  - the minimum spacing between one call's end and the next call's start was 2.006 s;
  - the total child wall time was 623.0 s (measured, a harness value);
  - the CG-3 log-visible SSF indicator was false in all 360;
  - 359 of 360 scratch outputs were byte-equal to the archived output (section 14).
- **Disclosed limit (CG-5 (e)).** A PASS says nothing about SSF events in callgrind children.

## 13. Child launches and their RLIMIT_AS read-backs (every capped child of this stage)

- Every msolve, valgrind, gp, builder and Sage child of this stage was launched by frozen code (`v2_solver.run_child`)
  or by the layer's configuration code. RLIMIT_AS 10737418240 was set in the child and read back with getrlimit.
- The table counts read-back RECORDS per scratch output directory (a child can be recorded in more than one file) and
  lists every distinct value seen.
- msolve always ran with `-t 1`. One memory-heavy process ran at a time, and every check ran detached or in sequence.
- Records under `dv6/` and `dv8/` are mostly byte copies of RUN-GFPN-ac4487's archived records, used by the R-2 /
  REG-1 cases; those children ran in the frozen v2 stage, not in this one.
- `dv11_extra/` and `dv15/` re-read package records.
- A null row is the row of a refused launch, which started no child.
- Every non-null value found is {soft 10737418240, hard 10737418240}.
- This stage's own capped children:
  - DV-1: one Sage probe child;
  - DV-2: two gp children (RC-5);
  - DV-7: the toy ladder gp children and the lineage children (562 + 2 msolve, 90 valgrind, 1 gp and 194 builders in
    attempt 5; section 8);
  - DV-12 and DV-16: the case children;
  - DV-17: 360 valgrind children.

  Each of them read back 10737418240 / 10737418240.

{{READBACKS}}

## 14. Deviations and implementation readings (disclosed)

RD-1 and RD-2 are written here for the first time. They were not written to this note before this section.

- **RD-1 (reading, VA-7).** The "site value" of VA-7 is a site-record field (census M-3). Derived tokens are
  disclosed, not treated as a STOP (section 6).
- **RD-2 (placement).** The development harnesses that must launch through frozen code live OUTSIDE
  `implementation-v2-r3/`, in `<scratchpad>/r3/dev/`, and are bundled. This keeps the r3 layer free of launch sites
  (CC-1 / DV-11). They are:
  - DV-17 (`dv17.py`);
  - the DV-7 continuations (`dv7_resume.py`, `dv7_resume5.py`);
  - the supplementary helpers `dv11_extra_g2.py` and `readbacks.py`;
  - the bundle builder `make_bundle.py`.
- **RD-3 (DV-6 attempt 1; implementation defect).** R-13 read `repair.<key>`, but the plans nest the ids at
  `repair.amendments.<key>`. Fixed; attempt 1 preserved.
- **RD-4 (DV-1 static attempt 1; harness).** `callgrind_annotate` prints its version on stderr. Preserved.
- **RD-5 (DV-7 attempt 1; harness).** Layer files were added during the lineage, and R-6 correctly refused. Preserved.
- **RD-6 (DV-7 attempt 2; harness reasons).** Two reasons: the toy G2 at 1039 was persistently SSF, which blocked the
  lineage at R-7; and a missing accounting directory crashed step (4).
  - The continuation reuses the RECORDED SE-5 packages; the probe was not re-run.
  - The live trace keeps attempt 2's steps (1)-(2) records only; its step-(3) records are in the preserved copy.
  - Toy G2 prime for the continuation, declared before launch: 65539 (the smallest prime >= 2^16 that is 1 mod 3).
- **RD-7 (stray byte-code; executor error).** An inspection command imported `r3_common` without `-B` and wrote
  `implementation-v2-r3/__pycache__/r3_common.cpython-311.pyc` at 11:28:50Z. It was inside the write scope and
  untracked.
  - R-6 correctly refused every launch of DV-7 attempt 3 because of it.
  - Removed at 11:35Z; every later inspection command uses `-B`.
  - Attempt 3 also crashed on a harness import-path defect.
- **RD-8 (DV-7 attempts 4-5).** At the declared 65539, every toy G2 msolve child crashed (SIGSEGV). By the declared
  rule, no further prime was tried. Attempt 5 continued the lineage on a SYNTHETIC toy G2 gate row (consequence in
  section 9).
- **RD-9 (DV-13 evaluation).** Attempt 4's raw `dv13_pass` counted refused launches, which have no driver and no
  package. Attempt 5 evaluates DV-13 over every toy package with a manifest, which is the text of DV-13 ("in every
  toy package").
- **RD-10 (DV-16 attempt 1; harness defect).** The shared case runner set the REG-1 reference id only in the child
  configuration; DV-12's G1 packages never evaluate REG-1.
  - The fix is in `r3_dv16.py` only, from sha256 b9b9667a…860e39 to the value in section 2.
  - `r3_dv12.py` is byte-unchanged, so DV-12's bound bytes stand. Attempt 1 preserved.
- **RD-11 (DV-17 attempt 1; harness defect).** The receipt path was wrong. The run stopped at start-up, before any
  child. Preserved.
- **RD-12 (DV-17 classification record).** DV-17 records the characterization classification of each scratch output
  as outcome, SSF flag, parse kind and byte-equality with the archived ac4487 output. It records no D, no degree and
  no count (outcome blindness).
- **RD-13 (bundle redaction; section 15).** In text members, three strings are replaced:
  - the scratchpad's absolute path -> `<scratchpad>`;
  - the git branch name -> `<branch>`;
  - the runtime-instructions filename that appears in byte copies of the frozen amendment texts ->
    `<runtime-instructions-file>`.

  Each redacted member's row carries both sha256 values. Binary members containing any of the three strings, and the
  frozen drivers' build caches, are not bundled; they are listed.
- **RD-14 (DV-15 table).** Degree columns are omitted from the note and kept in the bundle.
- **Observations (recorded, never evidence):**
  - msolve 0.6.5 crashed (SIGSEGV) on the toy fixture systems at p = 65539.
  - At p = 1039, the toy raw_u / S3_rescaled systems kept the SSF signature through K = 5.
  - The frozen `a1_check_run.py` lines 51-57 byte-sweep for the frozen v2 task id (frozen, V-4).
  - The DV-12 log prints toy D values; they are harness values of toy packages.
  - In DV-17, 359 of the 360 scratch outputs are byte-equal to the archived RUN-GFPN-ac4487 output. One is not: entry
    31 `fx_planted1_raw_u`, call 4. It was classified ok with no NSP signature. It is not a REG-1-compared field of
    DV-17, and CG-5 (e) anticipates ordinary clock-seed variation. It is recorded as a development observation.

## 15. Scratch files, DV-9 and the evidence bundle

{{SCRATCH_DV9_BUNDLE}}

## 16. Allocator and --check outputs (DV-10)

- The 42 ids were minted at 10:48:46Z with `tools/allocate_id.py --next run --area GFPN`, and each BARE id was checked
  with `--check` (rc 0, 0 occurrences) before any file named it.
- The verbatim outputs are in `<scratchpad>/r3/ids/` (`mint.log`, `check.log`, `ids.txt`) and in the bundle under
  `ids/`.
- The ids, in minting order, are `implementation-v2-r3/minted-run-ids.txt`.
- The retirement lists (124 = 29 v2 + 11 v2-a1 + 42 r1 + 42 r2) are in both plans' `retired_ids` and in
  `r3_common.RETIRED_ALL`.
