"""DV-7 continuation (attempt 3) -- a DEVELOPMENT harness kept OUTSIDE implementation-v2-r3/ (bundled under dv7/).

Why it exists (recorded harness reasons, see dv_attempts/dv7_attempt2_.../REASON.txt):
  (a) attempt 2 crashed in step (4): the accounting directory was never created (harness defect);
  (b) at the toy G2 prime 1039 the toy raw_u / S3_rescaled systems kept the SSF signature on all six SE-3 attempts, the
      frozen driver's AC-5 reading failed the toy G2, and R-7 refused the rest of the toy lineage.
What it does NOT redo: steps (1) and (2). The SE-5 probe ran ONCE, in attempt 2; its RECORDED packages (world A G1, world B G1)
and receipts are reused unchanged. The probe comparison and the perturbed-copy comparison are re-READ from those recorded
packages (no solve), and attempt 2's printed verdicts are recorded beside them.
Declared BEFORE launch: the toy G2 prime is the smallest prime p >= 2^16 with p = 1 (mod 3), i.e. 65539 (not 4111, 262151,
16777291 or 1073741831). If toy G2 fails again the outcome is recorded as is; no further prime is tried.
No layer file is edited; the synthetic phase-A receipt of attempt 2 still binds the layer as it is (checked at start).
"""
import contextlib
import datetime
import io
import json
import os
import sys

sys.dont_write_bytecode = True
LAYER = "/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2-r3"
sys.path.insert(0, LAYER)
import r3_common as R           # noqa: E402
import r3_dv7 as T              # noqa: E402

G2_PRIME = 65539
ATTEMPT2_VERDICTS = {"se5_probe": "PASS (printed by attempt 2: 'SE-5 probe: PASS []')",
                     "reg1_perturbed_copy": "FAIL (printed by attempt 2: 'REG-1 on a perturbed copy: FAIL')"}


def main(out):
    tdir = os.path.join(out, "toy")
    sys.path.insert(0, R.V2_DIR)              # attempt 4 fix: Toy.build() (skipped here) is where r3_dv7 puts these on sys.path
    sys.path.insert(0, R.A1_DIR)
    unbound = [os.path.join(dp, f) for dp, _d, fn in os.walk(LAYER) for f in fn
               if os.path.relpath(os.path.join(dp, f), R.REPO) not in R.load_json(T.Toy(tdir).load()["receipt_a"])["path_sha256"]]
    if unbound:
        raise SystemExit("REFUSING: files in the layer not bound by the synthetic receipt: %s" % unbound)
    toy = T.Toy(tdir)
    env = toy.load()
    # the layer is unchanged since attempt 2's synthetic phase-A receipt
    stale = [p for p, h in R.load_json(env["receipt_a"])["path_sha256"].items() if T.sha(os.path.join(R.REPO, p)) != h]
    if stale:
        raise SystemExit("REFUSING: layer changed since attempt 2's receipt: %s" % stale)
    report = {"attempt": 4, "kind": "continuation of attempt 2 from step (3) (attempt 3 preserved: R-6 refusals on a stray pyc, then a harness import defect)", "started": R.now(),
              "no_ladder_or_fixture_prime_solved": True, "attempt2_verdicts_as_printed": ATTEMPT2_VERDICTS,
              "toy_G2_prime_declared_before_launch": {"rule": "smallest prime p >= 2^16 with p = 1 (mod 3)", "p": G2_PRIME,
                                                      "attempt2_toy_G2_prime": T.TOY_FX3[1]}}
    # superset fixture data (1033 and 1039 entries byte-for-byte as attempt 2 wrote them) and a resumed toy plan
    fx3 = R.load_json(env["fx3"])
    fx3["primes"].append(T.toy_fixture_n3(G2_PRIME))
    fx3_r = os.path.join(tdir, "toy_fixture_n3_resume.json")
    T.dump(fx3_r, fx3)
    v2r3 = R.load_json(env["plan_v2r3"])
    by = {pk["order"]: pk for pk in v2r3["packages"]}
    by[2].update(driver_args=["fixture", "--p", str(G2_PRIME)], p=G2_PRIME)
    v2r3["toy_note"] += "; RESUME (DV-7 attempt 4): G2 -> fixture --p %d" % G2_PRIME
    plan_r = os.path.join(tdir, "toy-trial-plan-v2-r3-resume.json")
    T.dump(plan_r, v2r3)
    env = dict(env, fx3=fx3_r, plan_v2r3=plan_r)
    env["report"] = dict(env["report"], resume=report["toy_G2_prime_declared_before_launch"])
    T.dump(toy.state, env)                                   # attempt 2's env kept as toy-env-attempt2.json
    report["toy_primes"] = {"a1_role": T.TOY_A1_P, "v2_role": env["v2_role_prime"], "fixture_n3": [T.TOY_FX3[0], G2_PRIME], "fixture_n4": T.TOY_FX4_P}
    a1r3 = R.load_json(env["plan_a1r3"])
    G = v2r3["gate"]["blocking_packages"]
    os.environ["GFPN_V2_CACHE_DIR"] = os.path.join(tdir, "cache")
    worlds = {w: os.path.join(tdir, "world_%s" % w, "exp") for w in ("A", "B")}
    runsA, runsB = os.path.join(worlds["A"], "runs"), os.path.join(worlds["B"], "runs")
    rec_ref_A = os.path.join(tdir, "toy-reference-receipt-worldA-G1.json")
    rec_ref_B = os.path.join(tdir, "toy-reference-receipt-worldB-G1.json")
    rec_b = os.path.join(tdir, "toy-f1fb0e-post-run-receipt.json")
    trace = os.path.join(tdir, "trace.jsonl")
    shims = {n: os.path.join(tdir, "shims", n) for n in ("entry_toy.py", "check_toy.py")}
    import r3_run_wrapper as W
    import r3_check_run as K
    import r3_reg1 as REG
    real_git = W.git_tree_state
    W.git_tree_state = lambda paths: (env["r3files"], []) if paths == R.R3_PATHS_REL else real_git(paths)
    W.ENTRY_V2 = W.ENTRY_A1 = shims["entry_toy.py"]
    for k, v in {"PLAN_V2_R3": env["plan_v2r3"], "PLAN_A1_R3": env["plan_a1r3"], "PLAN_V2": env["plan_v2"], "RECEIPT_R3_PHASE_A": env["receipt_a"],
                 "RECEIPT_R3_PHASE_B": rec_b, "REG1_REFERENCE_RUN": G[0]}.items():
        setattr(R, k, v)
    # the two SE-5 rows, as attempt 2 recorded them
    pkgs = [x for x in R.load_json(os.path.join(out, "dv7-progress-attempt2.json"))["packages"] if x["run_id"] == G[0]]
    assert [x["world"] for x in pkgs] == ["A", "B"], pkgs

    def run(w, rid, entry_kind, seed, reg_runs, reg_receipt):
        os.environ["R3_TOY_CFG"] = T.cfg_for(tdir, env, worlds[w], reg_runs, reg_receipt, rec_b, trace)
        os.environ["R3_TOY_ENTRY"] = entry_kind
        os.environ["R3_TOY_PACKAGE"] = "%s/%s" % (w, rid)
        R.RUNS_DIR, R.RECEIPT_V2_PHASE_B = reg_runs, reg_receipt
        W.RUNS = os.path.join(worlds[w], "runs")
        W.DRIVER_PYTHONHASHSEED = seed
        t0 = datetime.datetime.now(datetime.timezone.utc)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = W.main([rid])
        t1 = datetime.datetime.now(datetime.timezone.utc)
        man = T.manifest_row(W.RUNS, rid)
        row = {"world": w, "run_id": rid, "entry": entry_kind, "PYTHONHASHSEED_set": seed, "wrapper_rc": rc, "wrapper_output": buf.getvalue().splitlines(),
               "run_dir": os.path.join(W.RUNS, rid), "started": t0.isoformat(), "finished": t1.isoformat(),
               "status": man and man["status"], "failure_class": man and man["failure_class"], "gate_pass": man and man["result"]["gate_pass"],
               "getrlimit": man and man["resources"]["child_rlimit_as_read_back_by_getrlimit"],
               "threads": man and man["resources"]["msolve_threads_executed"],
               "pari_stack_status": man and (man["resources"]["pari_stack"] or {}).get("status"),
               "hashseed_readback": man and ((man.get("environment") or {}).get("PYTHONHASHSEED_driver_readback") or {}).get("PYTHONHASHSEED_env"),
               "reg1_in_manifest": man and ((man.get("gate") or {}).get("regression_REG-1") or {}).get("verdict"),
               "solver_events_block": man and man.get("solver_events")}
        pkgs.append(row)
        T.dump(os.path.join(out, "dv7-progress.json"), dict(report, packages=pkgs))
        print("   world %s %s %-4s rc=%s status=%s gate_pass=%s REG-1=%s hashseed=%s (%.0fs)" % (
            w, rid, entry_kind, rc, row["status"], row["gate_pass"], row["reg1_in_manifest"], row["hashseed_readback"], (t1 - t0).total_seconds()), flush=True)
        return row
    # ---- (2') re-read of the recorded SE-5 packages (no solve)
    ga, gb = os.path.join(runsA, G[0]), os.path.join(runsB, G[0])
    probe = REG.compare(ga, gb, receipt=rec_ref_A)
    report["se5_probe"] = {"PYTHONHASHSEED": {"world_A": T.SEED_A, "world_B": T.SEED_B}, "reference": "world A G1", "candidate": "world B G1",
                           "run_once_in": "attempt 2", "verdict_reread": probe["verdict"], "failures": probe["failures"], "output": REG.render(probe),
                           "ssf_per_world": {x["world"]: (x["solver_events_block"] or {}).get("sites") for x in pkgs}}
    pr = REG.compare(ga, os.path.join(tdir, "perturbed", G[0]), receipt=rec_ref_A)
    report["reg1_perturbed_copy"] = {"perturbation": "world B G1 copy: planted_targets[0] first arm D + 1 (written by attempt 2)",
                                     "verdict_reread": pr["verdict"], "failures": pr["failures"]}
    print("(2') recorded SE-5 packages re-read: probe %s; perturbed copy %s" % (probe["verdict"], pr["verdict"]), flush=True)
    if probe["verdict"] != "PASS":
        report["STOP"] = "SE-5 re-read differs from attempt 2's printed PASS"
        T.dump(os.path.join(out, "dv7.json"), dict(report, packages=pkgs, **{"pass": False}))
        return 3
    # ---- (3) the rest of the lineage in world A, exactly as r3_dv7.dv7 step (3)
    print("(3) world A: G2 (fixture --p %d); G3, G4 SYNTHETIC; F-4; v2 build, cells, aggregate; the addendum packages" % G2_PRIME, flush=True)
    run("A", G[1], "v2", T.SEED_A, runsB, rec_ref_B)
    for g, why in ((G[2], "anchor-identity is not exercisable at toy scale (hard-coded p' = 16777291 and the Sage anchor system)"),
                   (G[3], "controls is not exercisable at toy scale (hard-coded fixture field at 4111 and ladder primes 4111, 262151, 16777291)")):
        T.synthetic_pkg(runsA, g, {"kind": "synthetic_gate", "run_status": "completed_valid", "gate_pass": True, "synthetic": T.SYN, "reason": why})
    for o in [5, 6, 7, 8, 9, 10, 11, 12]:
        run("A", by[o]["run_id"], "v2", T.SEED_A, runsB, rec_ref_B)
    T.synthetic_v2_cells(runsA, v2r3, skip_ids={by[o]["run_id"] for o in range(7, 13)})
    for o in (13, 20):
        T.synthetic_pkg(runsA, by[o]["run_id"], {"kind": "build", "run_status": "completed_valid", "synthetic": T.SYN,
                                                 "reason": "SYNTHETIC toy row: builds at 262151 / 16777291 are not run at toy scale"})
    run("A", by[27]["run_id"], "v2", T.SEED_A, runsB, rec_ref_B)
    v2_read = [by[o]["run_id"] for o in range(1, 28) if by[o]["kind"] in ("cells", "aggregate")]
    T.dump(rec_b, {"synthetic": T.SYN, "commit_sha": "dv7-synthetic-not-a-commit",
                   "path_sha256": {os.path.relpath(os.path.join(runsA, i, "raw-result.json"), R.REPO): T.sha(os.path.join(runsA, i, "raw-result.json"))
                                   for i in v2_read if os.path.exists(os.path.join(runsA, i, "raw-result.json"))}})
    ba = {pk["order"]: pk for pk in a1r3["packages"]}
    for o in range(1, 10):
        run("A", ba[o]["run_id"], "a1", T.SEED_A, runsB, rec_ref_B)
    agg_path = os.path.join(runsA, ba[9]["run_id"], "raw-result.json")
    agg = R.load_json(agg_path) if os.path.exists(agg_path) else {}
    report["rc8_aggregate_a1_phase_b_check"] = (agg.get("v2_bytes_phase_B_check") or {}).get("status")
    report["packages"] = pkgs
    # ---- (4) the r3 checker on every toy package that ran through the wrapper (accounting directory now created)
    print("(4) the r3 checker on every toy package that ran through the wrapper", flush=True)
    K.FROZEN_LAUNCHER = [sys.executable, "-B", shims["check_toy.py"]]
    os.makedirs(os.path.join(tdir, "accounting"), exist_ok=True)
    checks = []
    for x in pkgs:
        if x["status"] is None:
            continue
        os.environ["R3_TOY_CFG"] = T.cfg_for(tdir, env, worlds[x["world"]], runsB if x["world"] == "A" else runsA,
                                             rec_ref_B if x["world"] == "A" else rec_ref_A, rec_b, None)
        os.environ.pop("R3_TOY_PACKAGE", None)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = K.main(x["run_dir"], os.path.join(tdir, "accounting", "%s_%s.json" % (x["world"], x["run_id"])))
        lines = buf.getvalue().splitlines()
        checks.append({"world": x["world"], "run_id": x["run_id"], "rc": rc, "output": lines,
                       "failing_items": [l.strip()[2:] for l in lines if l.startswith("  - ")]})
        print("   check world %s %s rc=%s %s" % (x["world"], x["run_id"], rc, [l.strip()[2:] for l in lines if l.startswith("  - ")][:3]), flush=True)
    report["checker"] = checks
    # ---- (5) DV-13, DV-14, forbidden ids, DV-1 dynamic
    report["dv13"] = {"per_package": [{"world": x["world"], "run_id": x["run_id"], "set": x["PYTHONHASHSEED_set"], "driver_readback": x["hashseed_readback"]} for x in pkgs]}
    report["dv13"]["pass"] = all((x["hashseed_readback"] == T.SEED_A) if x["world"] == "A" else (x["hashseed_readback"] == T.SEED_B) for x in pkgs)
    gaps = []
    for x in pkgs:
        sp = os.path.join(x["run_dir"], "solver-events.json")
        if not os.path.exists(sp):
            continue
        doc = R.load_json(sp)
        for site in (R.SITE_S1, R.SITE_S2):
            for e in ((doc.get("sites") or {}).get(site) or {}).get("events") or []:
                a = e.get("attempts") or []
                for i in range(1, len(a)):
                    s = datetime.datetime.strptime(a[i]["start_utc"], "%Y-%m-%dT%H:%M:%S.%fZ")
                    en = datetime.datetime.strptime(a[i - 1]["end_utc"], "%Y-%m-%dT%H:%M:%S.%fZ")
                    gaps.append({"package": "%s/%s" % (x["world"], x["run_id"]), "site": site, "tag": e.get("tag"), "attempt": a[i]["attempt"],
                                 "gap_s": (s - en).total_seconds()})
    report["dv14"] = {"re_solve_gaps": gaps, "n_re_solves": len(gaps), "pass": all(g["gap_s"] >= R.SPACING_S for g in gaps)}
    bad = []
    for dp, _d, fn in os.walk(tdir):
        for f in fn:
            b = open(os.path.join(dp, f), "rb").read()
            for t in R.FORBIDDEN_TASK_IDS:
                if t.encode() in b:
                    bad.append({"file": os.path.relpath(os.path.join(dp, f), tdir), "id": t})
    report["forbidden_task_ids_in_toy_artifacts_report_only"] = bad
    tr = [json.loads(l) for l in open(trace)] if os.path.exists(trace) else []
    calls = [t for t in tr if t["event"] == "cypari2.Pari.__call__"]
    report["dv1_dynamic"] = {
        "trace_file": "dv7/toy/trace.jsonl (attempt 2 steps 1-2 records + attempt 4 records; attempt 2 step-3 records are in the preserved attempt)",
        "n_events": len(tr),
        "in_process_pari_calls": sorted({json.dumps([t.get("package"), t.get("p"), t.get("field_degree"), " <- ".join(reversed(t["stack"][-3:]))]) for t in calls}),
        "cypari2_constructions_by_caller": sorted({json.dumps([(t.get("package") or "").split("/")[0], t["stack"][-1] if t["stack"] else None]) for t in tr if t["event"] == "cypari2.Pari()"}),
        "children_by_launcher": sorted({json.dumps([t.get("launcher"), t.get("child_argv0")]) for t in tr if t["event"] == "child_end"}),
        "gp_children": [{"package": t.get("package"), "launcher": t.get("launcher"), "getrlimit": t.get("rlimit_as_child_getrlimit")} for t in tr
                        if t["event"] == "child_end" and t.get("child_argv0") == "gp"],
        "imports": sorted({json.dumps([(t.get("package") or "").split("/")[0], t["event"]]) for t in tr if t["event"].startswith("import:")})}

    # ---- (6) evaluation (as r3_dv7.dv7)
    def check_ok(c):
        if c["world"] == "B":
            return c["failing_items"] == ["SE-6: the driver process read back PYTHONHASHSEED '12345', not '0'"]
        return c["rc"] == 0
    exp_ok = {"all_run_packages_completed_valid": all(x["status"] == "completed_valid" for x in pkgs),
              "checker_passes_every_world_A_package": all(check_ok(c) for c in checks if c["world"] == "A"),
              "checker_on_world_B_G1_fails_only_on_the_declared_SE6_override": all(check_ok(c) for c in checks if c["world"] == "B"),
              "se5_probe_pass": probe["verdict"] == "PASS", "reg1_perturbed_copy_fails": pr["verdict"] == "FAIL",
              "rc8_phase_b_verified": report["rc8_aggregate_a1_phase_b_check"] == "verified",
              "dv13_pass": report["dv13"]["pass"], "dv14_pass": report["dv14"]["pass"],
              "getrlimit_all_10737418240": all(all(g == {"soft": R.CAP_BYTES, "hard": R.CAP_BYTES} for g in (x["getrlimit"] or [])) for x in pkgs),
              "threads_all_1": all((x["threads"] or [1]) == [1] for x in pkgs),
              "every_package_pari_stack_command_returned": all(x["pari_stack_status"] == "command_returned" for x in pkgs)}
    report["summary"] = exp_ok
    report["packages_run"] = len(pkgs)
    report["pass"] = all(exp_ok.values())
    report["not_exercised"] = {"anchor-identity": "hard-codes p' = 16777291 and runs the Sage comparator on the anchor system; exercising it solves an anchor system at a ladder prime (forbidden: R3S-9)",
                               "controls": "hard-codes fixture_n3(4111) and C.ladder_entry(4111 / 262151 / 16777291); every system it solves is at a fixture or ladder prime (forbidden: R3S-9); its in-process PARI point (4111, n = 3) is covered by DV-2",
                               "contingency launches": "not launched in the toy; every R-12 refusal is exercised by DV-6"}
    report["finished"] = R.now()
    T.dump(os.path.join(out, "dv7.json"), report)
    print(json.dumps(report["summary"], indent=1))
    print("DV-7:", "PASS" if report["pass"] else "FAIL", flush=True)
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
