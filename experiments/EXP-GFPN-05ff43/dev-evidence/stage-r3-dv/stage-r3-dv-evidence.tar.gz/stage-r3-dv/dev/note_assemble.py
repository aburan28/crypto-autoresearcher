"""Assemble implementation-v2-r3.md: header, progress-log additions, and the generated tables into note_body.md.
Usage: note_assemble.py <scratchpad/r3> <phase: pre|final>. Idempotent on the header / progress / body markers."""
import hashlib
import json
import os
import sys

S = sys.argv[1]
PHASE = sys.argv[2]
REPO = "/home/user/crypto-autoresearcher"
EXP = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43")
NOTE = os.path.join(EXP, "implementation-v2-r3.md")
L = os.path.join(EXP, "implementation-v2-r3")
R2 = os.path.join(EXP, "implementation-v2-r2")
SCR = os.path.dirname(S)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def red(t):
    return t.replace(SCR, "<scratchpad>")


ORIGIN = {"r3_accounting.py": "r2_accounting.py", "r3_check_run.py": "r2_check_run.py", "r3_common.py": "r2_common.py",
          "r3_devchecks.py": "r2_devchecks.py", "r3_devchecks_more.py": "r2_devchecks_more.py", "r3_dv12.py": "r2_dv12.py",
          "r3_dv6.py": "r2_dv6.py", "r3_entry_a1.py": "r2_entry_a1.py", "r3_entry_v2.py": "r2_entry_v2.py",
          "r3_make_plans.py": "r2_make_plans.py", "r3_reg1.py": "r2_reg1.py", "r3_resolve.py": "r2_resolve.py",
          "r3_run_wrapper.py": "r2_run_wrapper.py", "reg1-exclusion-list.json": "reg1-exclusion-list.json (byte copy)"}
NEWNOTE = {"r3_dv7.py": "new (its toy constructions follow `implementation-v2-r1/r1_toy.py`, sha256 e72582251725b9dcc355264521903b2ded2a2884d8c4b73a5243c29834fafc82, which is not imported)",
           "r3_dv16.py": "new (uses r3_dv12's case runner); changed once after DV-16 attempt 1 (RD-10; before: b9b9667ab4e1c8c642fba76708d9748a259353f1bfd112142ed5cc415f860e39)",
           "r3_inventory.py": "new (developed in `<scratchpad>/r3/dev/`, copied into the layer at 12:06Z, before DV-11)",
           "minted-run-ids.txt": "new (the 42 r3 ids, minting order)"}


def files_table():
    rows = ["| path | sha256 | started from |", "| --- | --- | --- |"]
    for f in sorted(os.listdir(L)):
        p = os.path.join(L, f)
        if f in ORIGIN:
            o = ORIGIN[f]
            op = os.path.join(R2, o.split(" ")[0])
            src = "`implementation-v2-r2/%s` %s" % (o, sha(op))
        else:
            src = NEWNOTE.get(f, "new")
        rows.append("| `implementation-v2-r3/%s` | %s | %s |" % (f, sha(p), src))
    for f, src in (("trial-plan-v2-r3.json", "written by `r3_make_plans.py --write` from the FROZEN `trial-plan-v2.json`"),
                   ("trial-plan-v2-a1-r3.json", "written by `r3_make_plans.py --write` from the FROZEN `trial-plan-v2-a1.json`")):
        rows.append("| `%s` | %s | %s |" % (f, sha(os.path.join(EXP, f)), src))
    rows.append("| `implementation-v2-r3.md` | (this file) | the stage note |")
    b = os.path.join(EXP, "dev-evidence", "stage-r3-dv", "stage-r3-dv-evidence.tar.gz")
    rows.append("| `dev-evidence/stage-r3-dv/stage-r3-dv-evidence.tar.gz` | %s | new (VA-5; section 15) |" % (sha(b) if os.path.exists(b) else "{{BUNDLE_SHA}}"))
    return "\n".join(rows)


def dv12_16():
    out = []
    for name, f in (("DV-12 (seedresolve SF-6; S-1; toy G1 at 1033; target `fx_reg1_S3`)", "dv12/dv12.json"),
                    ("DV-16 (healthresolve HR-9; S-2; toy prime 1021 declared in section 0; target `health_p1021_d222`)", "dv16/dv16.json")):
        d = json.load(open(os.path.join(S, f)))
        out.append("**%s:** all cases pass: %s; STOP: %s.\n" % (name, d["all_cases_pass"], d["STOP"]))
        out.append("| case | package status | failure class | pass | checks (all true unless listed) |")
        out.append("| --- | --- | --- | --- | --- |")
        for c, row in d["cases"].items():
            ev = d["evaluation"].get(c) or {}
            chk = ev.get("checks") or {}
            false = [k for k, v in chk.items() if v is not True]
            out.append("| %s | %s | %s | %s | %s |" % (c, row.get("status"), row.get("failure_class"), ev.get("pass", "reference (U)"),
                                                   (", ".join(sorted(chk)) + ("; FALSE: " + ", ".join(false) if false else "")) if chk else "the unforced reference"))
        out.append("")
    return "\n".join(out)


def dv15_table():
    d = json.load(open(os.path.join(S, "dv15", "dv15.json")))
    out = ["**(a) Set O (75 outputs).**", "",
           "| # | input key | output sha256 (first 12) | p | nvars | classifier outcome | parse | applicable | n_roots | n_den_zero | n_arity | n_points | n_distinct | invariant |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for i, r in enumerate(d["rows_a"], 1):
        out.append("| %d | `%s` | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            i, r["input_key"], r["output_sha256"][:12], r.get("p"), r.get("nvars"), r.get("classifier_outcome"), r.get("parse_kind"),
            r.get("applicable"), r.get("n_roots"), r.get("n_den_zero"), r.get("n_arity"), r.get("n_points"), r.get("n_distinct"), r.get("invariant_holds")))
    out += ["", "**(b) Toy lineage (596 ok-classified attempts; 22 package directories).**", "",
            "| # | package | site | tag | output sha256 (first 12) | parse | applicable | n_roots | n_den_zero | n_arity | n_points | n_distinct | invariant |",
            "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for i, r in enumerate(d["rows_b"], 1):
        rd = red(r["run_dir"])
        pk = rd.replace("<scratchpad>/r3/", "")
        out.append("| %d | `%s` | %s | `%s` | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            i, pk, r.get("site"), r.get("tag"), (r.get("output_sha256") or "")[:12], r.get("parse_kind"), r.get("applicable"),
            r.get("n_roots", "n/a"), r.get("n_den_zero", "n/a"), r.get("n_arity", "n/a"), r.get("n_points", "n/a"), r.get("n_distinct", "n/a"),
            r.get("invariant_holds", "n/a")))
    out.append("")
    out.append("Violations: %d. Integrity / location / classification agreement: all true (`dv15/dv15.json`)." % len(d["violations"]))
    return "\n".join(out)


def dv17_section():
    p = os.path.join(S, "dv17", "dv17.json")
    if not os.path.exists(p):
        return "{{DV17_SECTION}}", "{{DV17_OUTCOME}}", "{{DV17_TIME}}"
    d = json.load(open(p))
    rows = [json.loads(l) for l in open(os.path.join(S, "dv17", "dv17-calls.jsonl"))]
    by = {}
    for r in rows:
        by.setdefault((r["entry_index"], r["tag"]), []).append(r)
    ent = json.load(open(os.path.join(EXP, "dev-evidence", "launchcover-premise", "premise-check.json")))["LP2_callgrind_site_facts"]["vi_vii"]["entries"]
    out = ["- **Harness.** `<scratchpad>/r3/dev/dv17.py`, outside the layer (RD-2); attempt 1 was a harness defect before any child (RD-11).",
           "- **Settings (declared before any callgrind child).** R = %d (declared); cap 10737418240; timeout %s s (`%s`); calls spaced at least 2.0 s apart; one call at a time on a quiet machine." % (d["R"], d["timeout_s"], d["timeout_source"]),
           "- **Inputs.** %d inputs verified against the TASK-20260923-0fa03f post-run receipt and the archived entries, then copied to scratch. Prime(s): %s (the REG-1 reference prime; CG-5 (f))." % (d["inputs_verified"], d["input_primes"]),
           "- **Run.** Started %s; finished %s; %d calls." % (d["started"], d["finished"], d["calls_made"]),
           "- **Result.** Compared-field differences: %s. **DV-17: %s.**" % ("none" if not d.get("STOP") else json.dumps(d["STOP"], default=str), "PASS" if d["pass"] else "STOP"),
           "- **Bounds (CC-8 (d), derived and never measured).** Bound 1 is 1334.4 s; bound 2 is 648000 s. The measured wall span is in `dv17/dv17.json`.",
           "",
           "| # | entry tag | reference: method / label / child outcome / returncode / getrlimit / reason / f4_core_function / f4_core_note | calls | calls equal on every compared field | child outcomes | getrlimit read-backs | log-visible SSF indicator (CG-3) | scratch output byte-equal to archived ac4487 output (calls) | classification (development observation) |",
           "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
    for (ix, tag), rs in sorted(by.items()):
        ref = ent[ix]["reg1_compared_fields_verbatim"]
        rc = ref.get("child") or {}
        refs = "%s / %s / %s / %s / %s / %s / %s / %s" % (ref.get("method"), ref.get("label"), rc.get("outcome"), rc.get("returncode"),
                                                          json.dumps(rc.get("rlimit_as_child_getrlimit")), ref.get("reason", "(absent)"),
                                                          ref.get("f4_core_function", "(absent)"), ref.get("f4_core_note", "(absent)"))
        eq = sum(1 for r in rs if not r["compared_field_differences"])
        outs = sorted({(r["returned_record_verbatim"].get("child") or {}).get("outcome") for r in rs})
        gl = sorted({json.dumps((r["returned_record_verbatim"].get("child") or {}).get("rlimit_as_child_getrlimit")) for r in rs})
        ssf = sorted({str(r["cg3_fields"]["log_visible_ssf_indicator"]) for r in rs})
        beq = sum(1 for r in rs if r["classification_development_observation"]["output_bytes_equal_archived_ac4487_ms_out"])
        cls = sorted({"%s%s" % (r["classification_development_observation"]["classify_outcome"],
                                " (NSP)" if r["classification_development_observation"]["classify_reason_is_nsp_signature"] else "") for r in rs})
        out.append("| %d | `%s` | %s | %d | %d | %s | %s | %s | %d | %s |" % (ix, tag, refs, len(rs), eq, ", ".join(map(str, outs)), ", ".join(gl), ", ".join(ssf), beq, ", ".join(cls)))
    return "\n".join(out), ("PASS" if d["pass"] else "STOP"), "%s - %s" % (d["started"][11:19] + "Z", d["finished"][11:19] + "Z")


def readbacks():
    p = os.path.join(S, "dev", "readbacks.json")
    if not os.path.exists(p):
        return "{{READBACKS}}"
    d = json.load(open(p))
    out = ["| scratch directory | read-back records | distinct values |", "| --- | --- | --- |"]
    for k, v in sorted(d.items()):
        out.append("| `%s/` | %d | %s |" % (k, sum(v.values()), "; ".join("%s x%d" % (kk, vv) for kk, vv in sorted(v.items()))))
    return "\n".join(out)


def main():
    note = open(NOTE).read()
    body = open(os.path.join(S, "dev", "note_body.md")).read()
    prog = open(os.path.join(S, "dev", "note_progress_add.md")).read()
    # header
    if "(Work in progress" in note:
        old_hdr = note[note.index("(Work in progress"):note.index("## 0. Progress log")]
    else:
        old_hdr = None
    new_hdr = ("Stage note of the r3 successor stage (maximum_runs 0; no run package). Scratch outputs live in the session scratchpad, referred to\n"
               "only as `<scratchpad>`. Section 0 is the running progress log, and sections 1-16 follow the two RC-4 sections.\n\n")
    if old_hdr:
        note = note.replace(old_hdr, new_hdr)
    # progress additions (inserted once, before RC-4 (b))
    marker = "## RC-4 (b): declared metadata key paths"
    if "11:23:10Z DV-7 attempt 2" not in note:
        i = note.index(marker)
        note = note[:i].rstrip("\n") + "\n" + prog.rstrip("\n") + "\n\n" + note[i:]
    # body (replace anything after the id_map_a1 table)
    anchor = "| 11 | RUN-GFPN-6a7f35 | RUN-GFPN-3b498c | contingency a1-2 |\n"
    note = note[:note.index(anchor) + len(anchor)]
    dv17, dv17o, dv17t = dv17_section()
    subs = {"{{FILES_TABLE}}": files_table(), "{{DV12_16}}": dv12_16(), "{{DV15_TABLE}}": dv15_table(), "{{DV17_SECTION}}": dv17,
            "{{DV17_OUTCOME}}": dv17o, "{{DV17_TIME}}": dv17t, "{{READBACKS}}": readbacks()}
    extra = os.path.join(S, "dev", "note_subs.json")
    if os.path.exists(extra):
        subs.update(json.load(open(extra)))
    for k, v in subs.items():
        body = body.replace(k, v)
    note = note + body
    open(NOTE, "w").write(note)
    left = sorted({x for x in __import__("re").findall(r"\{\{[A-Z0-9_]+\}\}", note)})
    print("written; placeholders left:", left)


if __name__ == "__main__":
    main()
