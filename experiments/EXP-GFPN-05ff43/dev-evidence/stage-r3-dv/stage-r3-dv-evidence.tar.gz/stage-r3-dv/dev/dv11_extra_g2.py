"""DV-11 dynamic-count logic (r3_devchecks_more.dynamic_counts, unchanged) applied to the two PRESERVED real toy G2 packages
(attempt 2: p = 1039, with SSF re-solves; attempt 4: p = 65539, msolve SIGSEGV). Report only; supplementary to DV-11."""
import json, os, sys
sys.dont_write_bytecode = True
S = sys.argv[1]
sys.path.insert(0, "/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2-r3")
import r3_devchecks_more as MORE
out = {}
A2 = os.path.join(S, "dv_attempts", "dv7_attempt2_toyG2_persistent_ssf_at_1039_and_accounting_dir_crash", "dv7", "toy")
A4 = os.path.join(S, "dv_attempts", "dv7_attempt4_resume_toyG2_65539_msolve_segv")
cases = {"attempt2_toyG2_p1039": ([json.loads(l) for l in open(os.path.join(A2, "trace.jsonl"))], os.path.join(A2, "world_A", "exp", "runs", "RUN-GFPN-902222")),
         "attempt4_toyG2_p65539": ([json.loads(l) for l in open(os.path.join(A4, "trace-toyG2-p65539.jsonl"))], os.path.join(A4, "RUN-GFPN-902222-toyG2-p65539"))}
for name, (tr, rd) in cases.items():
    d = os.path.join(S, "dv11_extra", name)
    os.makedirs(os.path.join(d, "toy"), exist_ok=True)
    with open(os.path.join(d, "toy", "trace.jsonl"), "w") as fh:
        fh.write("".join(json.dumps(t) + "\n" for t in tr if t.get("package") == "A/RUN-GFPN-902222"))
    json.dump({"packages": [{"world": "A", "run_id": "RUN-GFPN-902222", "run_dir": rd}]}, open(os.path.join(d, "dv7.json"), "w"))
    out[name] = MORE.dynamic_counts(d)
json.dump(out, open(os.path.join(S, "dv11_extra", "dv11_extra_g2.json"), "w"), indent=1)
for k, v in out.items():
    print(k, v["all_equal"], json.dumps(v["per_package"]))
