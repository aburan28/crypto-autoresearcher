"""Collect every RLIMIT_AS getrlimit read-back record under each check directory of <scratchpad>/r3 (JSON, JSONL, YAML).
Counts are RECORDS (one child can be recorded in more than one file); the distinct values are what matters."""
import json, os, sys, collections
import yaml
S = sys.argv[1]
KEYS = {"rlimit_as_child_getrlimit", "child_rlimit_as_getrlimit", "getrlimit", "child_rlimit_as_read_back_by_getrlimit"}
def walk(o, acc):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in KEYS:
                vals = v if isinstance(v, list) else [v]
                for x in vals:
                    if isinstance(x, bool):
                        continue          # a check flag that shares the key name, not a read-back
                    acc["null (a refused launch: no child)" if x is None else json.dumps(x, sort_keys=True)] += 1
            else:
                walk(v, acc)
    elif isinstance(o, list):
        for v in o:
            walk(v, acc)
out = {}
for top in sorted(os.listdir(S)):
    p = os.path.join(S, top)
    if not os.path.isdir(p) or top in ("dev",):
        continue
    acc = collections.Counter()
    for dp, dn, fn in os.walk(p):
        dn[:] = [d for d in dn if d != "cache"]
        for f in fn:
            fp = os.path.join(dp, f)
            try:
                if f.endswith(".json"):
                    walk(json.load(open(fp)), acc)
                elif f.endswith(".jsonl"):
                    for l in open(fp):
                        walk(json.loads(l), acc)
                elif f.endswith(".yaml"):
                    walk(yaml.safe_load(open(fp)), acc)
            except Exception:
                pass
    if acc:
        out[top] = dict(acc)
json.dump(out, open(os.path.join(S, "dev", "readbacks.json"), "w"), indent=1)
for k, v in out.items():
    print(k, v)
