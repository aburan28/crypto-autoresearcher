"""DV-17 (launchcover CG-5 (a)-(g); consumercover CC-8 (b), (d)) -- a DEVELOPMENT harness kept OUTSIDE
implementation-v2-r3/ so that the r3 layer has no launch site of its own (CC-1 / DV-11). Bundled under dv17/.

(a) INPUTS: the 36 reference entries of dev-evidence/launchcover-premise/premise-check.json
    (LP2_callgrind_site_facts.vi_vii.entries; file sha256 caf24d66...f187, checked). Each input is RUN-GFPN-ac4487
    solver/<tag>.ms, verified against the TASK-20260923-0fa03f post-run receipt (path_sha256) and against the entry's
    archived retained sha256, then copied to scratch.
(b) PROCEDURE: per entry, R = 10 calls of the FROZEN v2_solver.callgrind_instructions (imported read-only; no bytecode
    written) with argv V.msolve_argv(<scratch input>, <scratch cg out>, threads=1) (gb_only false), cap_bytes 10737418240,
    timeout trial-plan-v2.json watchdogs callgrind_timeout_s.m3 (read: must be 1800). Each call starts at least 2.0 s after
    the previous call's recorded end. One call at a time. Every returned record verbatim, start / end UTC, the CG-3 fields
    of the call's logs, and the scratch output classified as the characterization classified (char_msolve.classify_files
    logic, frozen v2_solver functions) -- a development observation only.
(c) PASS iff for every entry and call each REG-1-compared field equals the reference entry's archived value: method, label;
    child.outcome, child.returncode, child.rlimit_as_child_getrlimit; presence and value of reason; f4_core_function;
    presence and value of f4_core_note. The first difference is a STOP: the harness halts, reporting entry, call, field,
    both values and the CG-3 fields.
(d) R = 10, fixed by declaration.
Outcome blindness: the classification record keeps outcome, reason, SSF flag and output byte-equality with the archived
ac4487 output; it records no D, no degree and no solution count.
"""
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
EXP = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43")
V2 = os.path.join(EXP, "implementation-v2")
sys.path.insert(0, V2)
import v2_solver as V           # noqa: E402  (frozen; imported read-only)

PREMISE = os.path.join(EXP, "dev-evidence", "launchcover-premise", "premise-check.json")
PREMISE_SHA = "caf24d6639b09eac26391bf38e4d0fcfe25cd620778a472ec623ef805778f187"
RECEIPT_B = os.path.join(REPO, "coordination", "goals", "GOAL-GFPN-380702", "archives", "TASK-20260923-0fa03f", "post-run-receipt.json")
REF_RUN = os.path.join(EXP, "runs", "RUN-GFPN-ac4487")
CAP = 10737418240
R_CALLS = 10
SPACING = 2.0
RANDOM_FORM = "[coefficients of linear form are randomly chosen]"
NSP_PREFIXES = ("eliminating polynomial is not square-free", "eliminating polynomial degree ", "msolve reports square-free part degree ")


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def utc(t):
    return datetime.datetime.fromtimestamp(t, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def read_text(p):
    return open(p, errors="replace").read() if os.path.exists(p) else None


def cg3_fields(workdir, tag, res):
    files, text, missing = {}, "", False
    for ext in (".callgrind.stdout", ".callgrind.stderr"):
        p = os.path.join(workdir, tag + ext)
        if os.path.exists(p):
            files[tag + ext] = {"sha256": sha(p), "bytes": os.path.getsize(p)}
            text += open(p, errors="replace").read() + "\n"
        else:
            files[tag + ext] = "absent"
            missing = True
    st = V.parse_msolve_log(text) if not missing else None
    dq = st["dimension_of_quotient"] if st is not None else "absent (a log file is absent)"
    sq = (st["fglm"]["squarefree_degree"] if "squarefree_degree" in st["fglm"] else "absent") if st is not None else "absent (a log file is absent)"
    pdr = st["positive_dimension_reported"] if st is not None else "absent (a log file is absent)"
    rf = (RANDOM_FORM in text) if not missing else "absent (a log file is absent)"
    return {"files": files, "dimension_of_quotient": dq, "fglm_squarefree_degree": sq, "positive_dimension_reported": pdr,
            "random_linear_form_string_in_log": rf,
            "log_visible_ssf_indicator": bool(rf is True or (isinstance(sq, int) and isinstance(dq, int) and sq != dq))}


def classify(out, log_text, p, nvars, child_outcome):
    """char_msolve.classify_files logic (frozen v2_solver functions, n_sub_fail = 0); records no D / degree / count."""
    st = V.parse_msolve_log(log_text)
    kind = payload = sinfo = None
    if child_outcome == "ok" and os.path.exists(out):
        kind, payload = V.parse_msolve_param(out)
        if kind == "param":
            _sols, sinfo = V.rational_solutions(payload, p, nvars)
    outcome, reason = V.classify_solve({"outcome": child_outcome}, st, kind, payload, sinfo, 0)
    nsp = outcome == "degenerate_parametrisation" and isinstance(reason, str) and (
        reason == NSP_PREFIXES[0] or reason.startswith(NSP_PREFIXES[1]) or reason.startswith(NSP_PREFIXES[2]))
    return {"parse_kind": kind, "classify_outcome": outcome, "classify_reason_is_nsp_signature": nsp,
            "classify_reason_recorded": None if nsp else reason}


def compare(ref, res):
    diffs = []
    for k in ("method", "label", "f4_core_function"):
        if res.get(k) != ref.get(k) or ((k in res) != (k in ref)):
            diffs.append((k, ref.get(k, "<absent>"), res.get(k, "<absent>")))
    for k in ("reason", "f4_core_note"):
        if (k in res) != (k in ref) or res.get(k) != ref.get(k):
            diffs.append((k, ref.get(k, "<absent>"), res.get(k, "<absent>")))
    rc, cc = ref.get("child") or {}, res.get("child") or {}
    for k in ("outcome", "returncode", "rlimit_as_child_getrlimit"):
        if cc.get(k) != rc.get(k) or ((k in cc) != (k in rc)):
            diffs.append(("child." + k, rc.get(k, "<absent>"), cc.get(k, "<absent>")))
    return diffs


def other_solvers():
    out = subprocess.run(["ps", "-eo", "pid,comm"], capture_output=True, text=True).stdout.split("\n")[1:]
    return [l.strip() for l in out if re.search(r"\b(msolve|valgrind|valgrind\.bin|gp|sage|magma)\b", l)]


def main(out):
    os.makedirs(out, exist_ok=True)
    rows_path = os.path.join(out, "dv17-calls.jsonl")
    if os.path.exists(rows_path):
        raise SystemExit("REFUSING: %s exists (DV-17 runs once; a re-run needs a recorded harness reason)" % rows_path)
    rep = {"started": utc(time.time()), "R": R_CALLS, "cap_bytes": CAP, "spacing_s": SPACING}
    assert sha(PREMISE) == PREMISE_SHA, "premise-check.json sha256 differs"
    entries = json.load(open(PREMISE))["LP2_callgrind_site_facts"]["vi_vii"]["entries"]
    assert len(entries) == 36, len(entries)
    plan = json.load(open(os.path.join(EXP, "trial-plan-v2.json")))
    timeout = plan["watchdogs"]["callgrind_timeout_s"]["m3"]
    assert timeout == 1800, timeout
    rep["timeout_s"] = timeout
    rep["timeout_source"] = "trial-plan-v2.json watchdogs.callgrind_timeout_s.m3"
    receipt = json.load(open(RECEIPT_B))["path_sha256"]
    inputs = []
    idir = os.path.join(out, "inputs")
    os.makedirs(idir, exist_ok=True)
    for e in entries:
        tag = e["tag"]
        src = os.path.join(REF_RUN, "solver", tag + ".ms")
        rel = os.path.relpath(src, REPO)
        h = sha(src)
        ok = (receipt.get(rel) == h) and (e["retained"]["solver/<tag>.ms"]["sha256"] == h)
        if not ok:
            rep["harness_failure"] = "input %s does not match the 0fa03f post-run receipt / the archived entry" % rel
            json.dump(rep, open(os.path.join(out, "dv17.json"), "w"), indent=1)
            return 2
        dst = os.path.join(idir, tag + ".ms")
        shutil.copyfile(src, dst)
        with open(dst) as fh:
            first = [fh.readline().strip(), fh.readline().strip()]
        nvars = len(first[0].split(","))
        p = int(first[1])
        archived_out = os.path.join(REF_RUN, "solver", tag + ".ms.out")
        inputs.append({"entry": e, "tag": tag, "scratch_input": dst, "input_sha256": h, "p": p, "nvars": nvars,
                       "archived_ms_out_sha256": receipt.get(os.path.relpath(archived_out, REPO))})
    rep["inputs_verified"] = len(inputs)
    rep["input_primes"] = sorted({x["p"] for x in inputs})
    print("DV-17: %d entries verified, R = %d, timeout %d s, cap %d" % (len(inputs), R_CALLS, timeout, CAP), flush=True)
    last_end = 0.0
    n = 0
    stop = None
    with open(rows_path, "a") as rows:
        for ix, x in enumerate(inputs):
            for r in range(1, R_CALLS + 1):
                wait = last_end + SPACING - time.time()
                if wait > 0:
                    time.sleep(wait)
                wd = os.path.join(out, "work", "%02d_%s" % (ix, x["tag"]), "call%02d" % r)
                os.makedirs(wd, exist_ok=True)
                cg_out = os.path.join(wd, x["tag"] + ".cg.ms.out")
                argv = V.msolve_argv(x["scratch_input"], cg_out, threads=1)
                others = other_solvers()
                t0 = time.time()
                res = V.callgrind_instructions(argv, wd, x["tag"], CAP, timeout)
                t1 = time.time()
                last_end = t1
                n += 1
                cg3 = cg3_fields(wd, x["tag"], res)
                txt = ""
                for ext in (".callgrind.stdout", ".callgrind.stderr"):
                    t = read_text(os.path.join(wd, x["tag"] + ext))
                    if t is not None:
                        txt += t + "\n"
                cls = classify(cg_out, txt, x["p"], x["nvars"], (res.get("child") or {}).get("outcome"))
                cls["output_sha256"] = sha(cg_out) if os.path.exists(cg_out) else None
                cls["output_bytes_equal_archived_ac4487_ms_out"] = cls["output_sha256"] == x["archived_ms_out_sha256"]
                diffs = compare(x["entry"]["reg1_compared_fields_verbatim"], res)
                row = {"entry_index": ix, "tag": x["tag"], "call": r, "start_utc": utc(t0), "end_utc": utc(t1),
                       "other_solver_processes_before_launch": others, "argv": argv, "returned_record_verbatim": res,
                       "cg3_fields": cg3, "classification_development_observation": cls, "compared_field_differences": diffs}
                rows.write(json.dumps(row, default=str) + "\n")
                rows.flush()
                print("  [%3d/360] %02d %-28s call %2d  %s  %s" % (n, ix, x["tag"], r, (res.get("child") or {}).get("outcome"),
                                                                   "OK" if not diffs else "DIFF %s" % diffs), flush=True)
                if diffs:
                    stop = {"entry_index": ix, "tag": x["tag"], "call": r, "differences": diffs, "cg3_fields": cg3}
                    break
            if stop:
                break
    rep["calls_made"] = n
    rep["finished"] = utc(time.time())
    rep["pass"] = stop is None and n == 36 * R_CALLS
    rep["STOP"] = stop
    json.dump(rep, open(os.path.join(out, "dv17.json"), "w"), indent=1, default=str)
    print("DV-17:", "PASS" if rep["pass"] else ("STOP %s" % json.dumps(stop, default=str) if stop else "INCOMPLETE"), flush=True)
    return 0 if rep["pass"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
