# Stage-R1 STOP diagnosis 2 (development only; scratch): same input, same argv shape, msolve environment varied.
import hashlib, json, os, sys
from collections import Counter
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2")
import v2_solver as V
d = os.path.dirname(os.path.abspath(__file__))
inp = os.path.join(d, "input.ms")
T = "<scratchpad>/stageR1/dv7/toy"
variants = {}
for w, seed in (("A", "0"), ("B", "12345")):
    variants["world%s_env_PYTHONHASHSEED=%s" % (w, seed)] = dict(os.environ, PYTHONHASHSEED=seed, GFPN_RUN_DIR=T + "/world_%s/exp/runs/RUN-GFPN-a61a10" % w,
        GFPN_V2_PACKAGE="RUN-GFPN-a61a10", GFPN_V2_REPLACES="", PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1",
        R1_TOY_CFG=T + "/toy-cfg-%s.json" % w, R1_TOY_ENTRY="v2", R1_TOY_TRACE=T + "/pari-trace.jsonl", GFPN_V2_CACHE_DIR=T + "/cache")
variants["no_PYTHONHASHSEED"] = {k: v for k, v in variants["worldB_env_PYTHONHASHSEED=12345"].items() if k != "PYTHONHASHSEED"}
res = {}
for name, env in variants.items():
    rows = []
    for i in range(10):
        od = os.path.join(d, "env_" + name.split("_")[0], "RUN-GFPN-a61a10", "solver")      # same path length pattern as the toy worlds
        os.makedirs(od, exist_ok=True)
        out = os.path.join(od, "fx_reg0_torsion_S3_norm.ms.out")
        argv = V.msolve_argv(inp, out, threads=1)
        rec = V.run_child(argv, out[:-4] + ".log.%d" % i, out[:-4] + ".err.%d" % i, cap_bytes=10737418240, timeout_s=1800, count_instructions=False, env=env)
        err = open(out[:-4] + ".err.%d" % i).read()
        rows.append({"outcome": rec["outcome"], "sha": hashlib.sha256(open(out, "rb").read()).hexdigest()[:16], "not_squarefree": "not squarefree" in err,
                     "getrlimit": rec.get("rlimit_as_child_getrlimit")})
    res[name] = rows
    print(name, "outputs", dict(Counter(r["sha"] for r in rows)), "not squarefree", sum(r["not_squarefree"] for r in rows), "outcomes", dict(Counter(r["outcome"] for r in rows)))
json.dump(res, open(os.path.join(d, "probe_env.json"), "w"), indent=1)
ra = hashlib.sha256(open(T + "/world_A/exp/runs/RUN-GFPN-a61a10/solver/fx_reg0_torsion_S3_norm.ms.out", "rb").read()).hexdigest()[:16]
rb = hashlib.sha256(open(T + "/world_B/exp/runs/RUN-GFPN-a61a10/solver/fx_reg0_torsion_S3_norm.ms.out", "rb").read()).hexdigest()[:16]
print("world A .ms.out", ra, "; world B .ms.out", rb)
