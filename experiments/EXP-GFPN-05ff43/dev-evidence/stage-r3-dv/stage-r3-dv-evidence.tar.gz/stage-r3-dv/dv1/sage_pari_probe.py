from sage.all import *
from sage.libs.pari import pari
print('R3PROBE parisize', int(pari.default('parisize')))
print('R3PROBE parisizemax', int(pari.default('parisizemax')))
print('R3PROBE stacksize', int(pari.stacksize()))
print('R3PROBE stacksizemax', int(pari.stacksizemax()))
import sage.version; print('R3PROBE sage_version', sage.version.version)
