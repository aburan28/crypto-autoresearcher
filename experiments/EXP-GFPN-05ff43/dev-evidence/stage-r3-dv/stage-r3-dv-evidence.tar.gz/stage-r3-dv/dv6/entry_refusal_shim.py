
# DV-6 development shim (never delivered): runs a delivered entry point with ONE simulated fault.
#   pari:     the configuring call does not reach PARI (configure() skips allocatemem) -> the RC-2 (a) start read-back
#             through fresh cypari2.Pari() handles must refuse;
#   redirect: an import-time hook re-redirects a module constant after the driver module is imported -> the RC-3 (d)
#             read-back must refuse;
#   se3_attr / hr3_attr: after install, the module attribute is rebound to the frozen function -> the read-back refuses;
#   se3_orig / hr3_orig: the wrapper's recorded original is replaced by a non-frozen function -> the read-back refuses;
#   hr3_H: after install, a1_driver.H is rebound to another module object -> the HR-3 read-back refuses;
#   v2_with_a1_health: a1_health is imported into the v2 entry process after v2_driver -> the HR-3 read-back refuses;
#   va7_redirect: the r3 run-card constant the v2 entry redirects v2_common.TASK_ID to is replaced by a forbidden id ->
#             check_redirections flags it and the pari-stack.json guard refuses to record it (nothing written).
import os, sys, runpy, types, importlib.abc, importlib.util
sys.dont_write_bytecode = True
sys.path.insert(0, '/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2-r3')
import r3_common as R
import r3_resolve as RS
mode, entry = os.environ["R3_DV6_MODE"], os.environ["R3_DV6_ENTRY"]
if mode == "se3_attr":
    _inst = RS.install
    def install(mod, rd):
        rec = _inst(mod, rd)
        mod.solve = RS.solve.__r3_original__
        return rec
    RS.install = install
elif mode == "se3_orig":
    _inst = RS.install
    def install(mod, rd):
        rec = _inst(mod, rd)
        def solve(*a, **k):
            return RS._STATE["original"](*a, **k)
        RS.solve.__r3_original__ = solve
        return rec
    RS.install = install
elif mode == "hr3_attr":
    _insth = RS.install_health
    def install_health(mod, rd):
        rec = _insth(mod, rd)
        mod.run_system = RS.run_system.__r3_original__
        return rec
    RS.install_health = install_health
elif mode == "hr3_orig":
    _insth = RS.install_health
    def install_health(mod, rd):
        rec = _insth(mod, rd)
        def run_system(*a, **k):
            return RS._STATE["health_original"](*a, **k)
        RS.run_system.__r3_original__ = run_system
        return rec
    RS.install_health = install_health
elif mode == "hr3_H":
    _insth = RS.install_health
    def install_health(mod, rd):
        rec = _insth(mod, rd)
        sys.modules["a1_driver"].H = types.ModuleType("a1_health_stand_in")
        return rec
    RS.install_health = install_health
elif mode == "va7_redirect":
    R.TASK_RUNS_V2 = R.FORBIDDEN_TASK_IDS[4]
elif mode == "pari":
    def configure(self):
        self.rec["configured_before_first_v2_or_a1_import"] = True
        self.rec["dv6_simulated_fault"] = "allocatemem not called"
        import cypari2
        cypari2.Pari()
        return self.rec
    R.PariStack.configure = configure
else:
    class Hook(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path, target=None):
            if name != ("a1_driver" if entry.endswith("r3_entry_a1.py") else "v2_driver"):
                return None
            sys.meta_path.remove(self)
            spec = importlib.util.find_spec(name)
            sys.meta_path.insert(0, self)
            orig = spec.loader.exec_module
            def exec_module(module, _o=orig, _n=name):
                _o(module)
                if mode == "v2_with_a1_health":
                    sys.path.insert(0, R.A1_DIR)
                    import a1_health
                elif _n == "v2_driver":
                    sys.modules["v2_common"].PLAN_PATH = os.path.join(R.EXP_DIR, "trial-plan-v2.json")
                else:
                    sys.modules["a1_common"].PROTOCOL_VERSION = "2-a1"
            spec.loader.exec_module = exec_module
            return spec
    sys.meta_path.insert(0, Hook())
sys.argv = [entry] + sys.argv[1:]
runpy.run_path(entry, run_name="__main__")
