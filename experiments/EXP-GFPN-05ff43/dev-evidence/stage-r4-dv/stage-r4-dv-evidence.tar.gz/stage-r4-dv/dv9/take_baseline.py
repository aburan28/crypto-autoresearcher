"""r4 stage DV-9 baseline (SC-6), taken BEFORE any repository write. Scratch harness; run by path.
Frozen roots are hashed file by file. Under runs/, only the six packages the card permits reading
(RUN-GFPN-ac4487, RUN-GFPN-3377f1 and the four r3 gate packages) are hashed; every other run package is
recorded by listing and lstat metadata only (size, mtime), never read (R4S-12)."""
import os, sys, json, hashlib, datetime, subprocess
REPO = "/home/user/crypto-autoresearcher"
EXP = os.path.join(REPO, "experiments/EXP-GFPN-05ff43")
FROZEN = ["specification.yaml", "amendments", "implementation", "implementation.md", "trial-plan.json",
          "implementation-v2", "implementation-v2.md", "trial-plan-v2.json",
          "implementation-v2-a1", "implementation-v2-a1.md", "trial-plan-v2-a1.json",
          "implementation-v2-r1", "implementation-v2-r1.md", "trial-plan-v2-r1.json", "trial-plan-v2-a1-r1.json",
          "implementation-v2-r2", "implementation-v2-r2.md", "trial-plan-v2-r2.json", "trial-plan-v2-a1-r2.json",
          "implementation-v2-r3", "implementation-v2-r3.md", "trial-plan-v2-r3.json", "trial-plan-v2-a1-r3.json",
          "execution-report-v2.yaml", "execution-report-v2-r3.yaml", "analysis.md", "corrections"]
READABLE_RUNS = ["RUN-GFPN-ac4487", "RUN-GFPN-3377f1", "RUN-GFPN-f6a21a", "RUN-GFPN-902222", "RUN-GFPN-f5412a", "RUN-GFPN-bfe956"]
DEV = sorted(d for d in os.listdir(os.path.join(EXP, "dev-evidence")) if d != "stage-r4-dv")
FROZEN += ["dev-evidence/" + d for d in DEV] + ["runs/" + r for r in READABLE_RUNS]
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()
files = {}
for f in FROZEN:
    p = os.path.join(EXP, f)
    if os.path.isfile(p):
        files[f] = {"sha256": sha(p), "bytes": os.path.getsize(p), "mtime": os.path.getmtime(p)}
    elif os.path.isdir(p):
        for dp, dn, fn in os.walk(p):
            for x in fn:
                q = os.path.join(dp, x)
                files[os.path.relpath(q, EXP)] = {"sha256": sha(q), "bytes": os.path.getsize(q), "mtime": os.path.getmtime(q)}
    else:
        files[f] = {"missing": True}
meta = {}
for r in sorted(os.listdir(os.path.join(EXP, "runs"))):
    if r in READABLE_RUNS:
        continue
    rp = os.path.join(EXP, "runs", r)
    if os.path.isdir(rp):
        for dp, dn, fn in os.walk(rp):
            for x in fn:
                q = os.path.join(dp, x)
                st = os.lstat(q)
                meta[os.path.relpath(q, EXP)] = {"bytes": st.st_size, "mtime": st.st_mtime}
    else:
        st = os.lstat(rp)
        meta["runs/" + r] = {"bytes": st.st_size, "mtime": st.st_mtime}
pyc = [{"path": os.path.relpath(os.path.join(dp, x), EXP), "bytes": os.path.getsize(os.path.join(dp, x)),
        "mtime_utc": datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(dp, x)), datetime.timezone.utc).isoformat()}
       for dp, dn, fn in os.walk(EXP) for x in fn if x.endswith((".pyc", ".pyo")) or "__pycache__" in dp]
runs = sorted(os.listdir(os.path.join(EXP, "runs")))
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
st = subprocess.run(["git", "-C", REPO, "status", "--porcelain", "--untracked-files=all"], capture_output=True, text=True, env=env).stdout
head = subprocess.run(["git", "-C", REPO, "rev-parse", "HEAD"], capture_output=True, text=True, env=env).stdout.strip()
out = {"taken_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "head": head, "git_status_porcelain": st.splitlines(),
       "git_argv": [["git", "-C", REPO, "status", "--porcelain", "--untracked-files=all"], ["git", "-C", REPO, "rev-parse", "HEAD"]],
       "git_env": "GIT_OPTIONAL_LOCKS=0",
       "frozen_roots": FROZEN, "n_files": len(files), "files": files, "runs_metadata_only": meta, "n_runs_metadata_files": len(meta),
       "byte_code_files": pyc, "runs_listing": runs, "n_runs_entries": len(runs)}
json.dump(out, open(sys.argv[1], "w"), indent=1)
print("baseline", out["taken_at_utc"], "files", len(files), "runs-metadata files", len(meta), "pyc", len(pyc),
      "runs entries", len(runs), "head", head, "status lines", len(st.splitlines()))
