
import os, sys, json, re, time, traceback, datetime, importlib.abc, importlib.util, runpy
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R4_TOY_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r4_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
import r4_resolve as RS
TRACE = CFG.get("trace")
PKG = os.environ.get("R4_TOY_PACKAGE")
DEPTH = [0]

def _stack():
    return traceback.extract_stack()[:-2]

def _launcher(st):
    names = [(os.path.basename(f.filename), f.name) for f in st]
    if ("a1_health.py", "run_system") in names:
        return "a1_health.run_system"
    if ("v2_solver.py", "callgrind_instructions") in names:
        return "v2_solver.callgrind_instructions"
    if ("v2_driver.py", "solve") in names:
        return "v2_driver.solve"
    if ("a1_pari.py", "curve_facts") in names:
        return "a1_pari.curve_facts"
    if ("v2_driver.py", "child_job") in names:
        return "v2_driver.child_job"
    return "other:" + ",".join("%s:%s" % n for n in names if n[0].startswith(("v2_", "a1_", "r4_")))[-160:]

def _log(ev, extra=None):
    if not TRACE:
        return
    st = _stack()
    rec = {"event": ev, "pid": os.getpid(), "package": PKG, "argv": sys.argv[1:4],
           "stack": ["%s:%d:%s" % (os.path.basename(f.filename), f.lineno, f.name) for f in st if "implementation-v2" in f.filename][-10:]}
    if extra:
        rec.update(extra)
    with open(TRACE, "a") as fh:
        fh.write(json.dumps(rec, default=str) + "\n")

sys.addaudithook(lambda ev, args: _log("import:" + args[0]) if ev == "import" and args and args[0] in ("cypari2", "sage.all", "sage") else None)
import cypari2
_Base = cypari2.Pari
class TracingPari(_Base):
    def __init__(self, *a, **k):
        _log("cypari2.Pari()")
        super().__init__(*a, **k)
    def __call__(self, s, *a, **k):
        m = re.search(r"ffgen\(Mod\(1, (\d+)\)\*\((.*?)\), 'w\)", str(s))
        ex = {"expr_head": str(s)[:160]}
        if m:
            ex["p"] = int(m.group(1))
            ex["field_degree"] = max(int(x) for x in re.findall(r"w\^(\d+)", m.group(2)))
        _log("cypari2.Pari.__call__", ex)
        return super().__call__(s, *a, **k)
cypari2.Pari = TracingPari

def _tag_of(argv):
    for i, x in enumerate(argv):
        if x == "-f" and i + 1 < len(argv):
            b = os.path.basename(argv[i + 1])
            return b[:-3] if b.endswith(".ms") else b
    return None

class Hook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"] and name != "v2_solver":
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"].get(_n, {}).items():
                setattr(module, k, v)
            if _n == "v2_solver" and TRACE:
                module.os = _OsProxy()
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())

class _OsProxy(object):
    """Development fork tracer (DV-7 / DV-11 only): delegates every attribute to the real os module; fork() calls the
    real os.fork (so every os.register_at_fork callback, the RG-1 observer included, runs as without the proxy) and, in
    the PARENT only, appends one trace line. It sits beneath the RL-1 recorder and replaces no function the RL-5
    read-back names."""
    def __getattr__(self, name):
        return getattr(os, name)
    def fork(self):
        pid = os.fork()
        if pid > 0:
            argv = None
            f = sys._getframe(1)
            while f is not None:
                if f.f_code.co_name == "_run_child_locked":
                    argv = f.f_locals.get("argv")
                    break
                f = f.f_back
            st = _stack()
            _log("fork", {"child_pid": pid, "t": time.time(), "child_argv0": os.path.basename(argv[0]) if argv else None,
                          "tag": _tag_of(argv) if argv else None, "launcher": _launcher(st),
                          "inside_wrapper_original_call": DEPTH[0] > 0,
                          "msolve_in_argv": bool(argv) and any(os.path.basename(x) == "msolve" for x in argv)})
        return pid

_orig_call_original = RS._call_original
def _traced_call_original(original, args, kwargs):
    site = R.SITE_S2 if getattr(original, "__name__", "") == "run_system" else R.SITE_S1
    tag = args[3] if len(args) > 3 else None
    t0 = time.time()
    DEPTH[0] += 1
    try:
        res = _orig_call_original(original, args, kwargs)
    finally:
        DEPTH[0] -= 1
    t1 = time.time()
    out = res.get("outcome") if site == R.SITE_S1 else res.get("v2_outcome_class")
    _log("original_call_end", {"site": site, "tag": tag, "t_start": t0, "t_end": t1, "gb_only": kwargs.get("gb_only"),
                                "callgrind_timeout": kwargs.get("callgrind_timeout"), "outcome": out,
                                "recorded_attempt_ok_with_callgrind_timeout": bool(site == R.SITE_S1 and kwargs.get("callgrind_timeout") and out == "ok"),
                                "has_instructions_callgrind": "instructions_callgrind" in res})
    return res
RS._call_original = _traced_call_original

import r4_check_run as K
mode, rd = sys.argv[1], sys.argv[2]
sys.exit(K.frozen_v2(rd) if mode == "frozen-v2" else K.frozen_a1(rd))
