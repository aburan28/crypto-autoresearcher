#!/bin/sh
# DV-18 development stand-in for the valgrind EXECUTABLE (RH-6 (i) (21)): writes its callgrind out file, exits 3.
for a in "$@"; do
  case "$a" in --callgrind-out-file=*) f="${a#--callgrind-out-file=}"; printf 'events: Ir\nsummary: 1\n' > "$f";; esac
done
echo "dv18 development valgrind stand-in: exiting 3 after writing the out file"
exit 3
