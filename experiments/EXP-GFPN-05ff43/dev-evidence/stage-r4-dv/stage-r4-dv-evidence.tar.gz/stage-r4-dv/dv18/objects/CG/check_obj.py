
import os, sys, json, runpy, importlib.abc, importlib.util
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R4_DV18_OBJ_CFG"]))
CFG["suffix"] = None   # the checker process: no stand-in
sys.path.insert(0, CFG["layer_dir"])
import r4_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
PARENT = os.getpid()
class _OsOpenProxy(object):
    """os as v2_solver sees it: open raises IN THE FORKED CHILD ONLY for names ending CFG['suffix']; every parent-side
    os.open call is logged (LKA-11 (c)); every other attribute is the real os."""
    def __getattr__(self, name):
        return getattr(os, name)
    def open(self, path, flags, mode=0o777, *a, **k):
        if os.getpid() != PARENT and str(path).endswith(CFG["suffix"]):
            raise OSError("dv18 development stand-in: os.open fails in the child for %s" % CFG["suffix"])
        if os.getpid() == PARENT:
            with open(CFG["parent_open_log"], "a") as fh:
                fh.write(json.dumps({"path": str(path), "targets_the_stand_in_suffix": str(path).endswith(CFG["suffix"])}) + "\n")
        return os.open(path, flags, mode, *a, **k)
class Hook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"] and not (name == "v2_solver" and CFG.get("suffix")):
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"].get(_n, {}).items():
                setattr(module, k, v)
            if _n == "v2_solver" and CFG.get("suffix"):
                module.os = _OsOpenProxy()
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())

import r4_check_run as K
mode, rd = sys.argv[1], sys.argv[2]
sys.exit(K.frozen_v2(rd) if mode == "frozen-v2" else K.frozen_a1(rd))
