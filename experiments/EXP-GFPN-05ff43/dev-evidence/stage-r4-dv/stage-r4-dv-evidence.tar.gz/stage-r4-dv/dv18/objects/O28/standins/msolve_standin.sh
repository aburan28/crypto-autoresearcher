#!/bin/sh
# DV-18 development stand-in for the msolve EXECUTABLE (the executable the frozen run_child launches; LKA-6).
STATE="<scratchpad>/r4/dv18/objects/O28/standins/state"
inp=""; out=""; prev=""
for a in "$@"; do
  if [ "$prev" = "-f" ]; then inp="$a"; fi
  if [ "$prev" = "-o" ]; then out="$a"; fi
  prev="$a"
done
tag=$(basename "$inp" .ms)
n=$(cat "$STATE/policy/$tag" 2>/dev/null || echo 0)
k=$(( $(cat "$STATE/count/$tag" 2>/dev/null || echo 0) + 1 ))
echo "$k" > "$STATE/count/$tag"
if [ "$k" -le "$n" ]; then
  echo "[coefficients of linear form are randomly chosen]"
  echo "dv18 development stand-in: positive-dimensional output for $tag (invocation $k of $n forced)"
  printf '[1]:\n' > "$out"
  exit 0
fi
exec /usr/bin/msolve "$@"
