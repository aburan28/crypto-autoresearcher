#!/usr/bin/env python3
"""DV-18 (g) INSTALL READ-BACK (readbackfull RL-6 (g)): a scratch copy of EACH delivered r4 entry with the RL-1
replacement line (`REC.install(V, run_dir)`) omitted must exit 2 before any command. SCRATCH harness.

The copy differs from the delivered entry in exactly two textual places, both recorded: the removed install line, and
`HERE` pointing at the delivered layer directory (so the copy imports the delivered r4 modules). Each copy is run once
in a scratch run directory with the argv `--help` (so that, were the refusal absent, argparse would print its usage and no computation could start), and
must exit 2, print the RL-5 read-back refusal, write pari-stack.json with status refused_before_any_command and write
nothing else (no command runs).

usage: python3 -B dv18_g.py DV18_OUT
"""
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
OUT = os.path.join(sys.argv[1], "g")
if os.path.exists(OUT):
    raise SystemExit("REFUSING: %s exists" % OUT)
os.makedirs(OUT)
rep = {"cases": [], "GFPN_V2_CAP_BYTES_in_environment": "GFPN_V2_CAP_BYTES" in os.environ}
for entry, args in (("r4_entry_v2.py", ["--help"]), ("r4_entry_a1.py", ["--help"])):
    src = open(os.path.join(LAYER, entry)).read()
    lines = src.splitlines(True)
    inst = [i for i, l in enumerate(lines) if l.strip().startswith("REC.install(V, run_dir)")]
    here = [i for i, l in enumerate(lines) if l.startswith("HERE = os.path.dirname(os.path.abspath(__file__))")]
    assert len(inst) == 1 and len(here) == 1, (entry, inst, here)
    removed = lines[inst[0]]
    lines[inst[0]] = ""
    lines[here[0]] = "HERE = %r   # DV-18 (g) copy: the delivered layer directory\n" % LAYER
    cp = os.path.join(OUT, entry.replace(".py", "_without_RL1_install.py"))
    open(cp, "w").write("".join(lines))
    rd = os.path.join(OUT, "run_" + entry.replace(".py", ""))
    os.makedirs(rd)
    argv = [sys.executable, "-B", cp] + args
    env = dict(os.environ, GFPN_RUN_DIR=rd, GFPN_V2_PACKAGE="DV18-g", PYTHONHASHSEED="0", PYTHONDONTWRITEBYTECODE="1")
    pr = subprocess.run(argv, capture_output=True, text=True, env=env, cwd=REPO, timeout=600)
    files = sorted(os.listdir(rd))
    ps = json.load(open(os.path.join(rd, "pari-stack.json"))) if "pari-stack.json" in files else None
    ok = (pr.returncode == 2 and "RL-5 install read-back" in pr.stderr and files == ["pari-stack.json"] and ps and ps.get("status") == "refused_before_any_command")
    rep["cases"].append({"entry": entry, "copy": cp, "removed_line": {"line_number": inst[0] + 1, "text": removed.rstrip("\n")},
                         "replaced_line": {"line_number": here[0] + 1, "text": lines[here[0]].rstrip("\n")}, "argv": argv, "rc": pr.returncode,
                         "stderr": pr.stderr.splitlines()[-12:], "files_in_run_dir": files, "pari_stack_status": ps and ps.get("status"),
                         "refusal_reasons": ps and ps.get("refusal_reasons"), "pass": ok})
    print("%s without the RL-1 install: rc=%s files=%s %s" % (entry, pr.returncode, files, "PASS" if ok else "FAIL"))
rep["pass"] = all(c["pass"] for c in rep["cases"])
json.dump(rep, open(os.path.join(OUT, "g.json"), "w"), indent=1)
print("DV-18 (g):", "PASS" if rep["pass"] else "STOP")
sys.exit(0 if rep["pass"] else 3)
