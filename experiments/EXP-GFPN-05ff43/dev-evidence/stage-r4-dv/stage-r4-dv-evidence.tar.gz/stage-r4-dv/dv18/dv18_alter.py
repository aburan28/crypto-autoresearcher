#!/usr/bin/env python3
"""DV-18 IN-PLACE OBJECT CHECKS: attcount RI-3 (19)-(27) as launchkind RJ-5 (a) reads them, and RJ-5 (c) (28)-(32), with
DEC-20260924-daf670 LKA-11 (b) (gap level AND verdict level, with RJ-1 / RJ-2 / RJ-3 enabled and disabled in THIS
SCRATCH EVALUATOR ONLY for (28), (29), (30)). SCRATCH harness; never a package; toy harness values only.

IN PLACE, NOT MOVED (RI-3): every object stays at its own recorded root. An alteration edits solver-events.json in
place after the driver has exited; the file's bytes are saved first and restored after the evaluation, and the restore
is verified by sha256. Expectations are stated at the GAP level; the verdict is recorded (the carried V-7 item FAILs on
an altered file by design, RJ-5 (a), and is not the discriminant). (32) is evaluated on every UNALTERED object BEFORE
any alteration of it.

usage: python3 -B dv18_alter.py DV18_OUT
"""
import contextlib
import copy
import hashlib
import io
import json
import os
import re
import sys

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402
sys.path.insert(0, R.V2_DIR)
sys.path.insert(0, R.A1_DIR)
import r4_gaps as GAPS                                   # noqa: E402
import r4_check_run as K                                 # noqa: E402

OUT = sys.argv[1]
EV = "solver-events.json"
RESULTS = {"method": __doc__, "positive_control_32": {}, "items": []}
STOPS = []


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


# ------------------------------------------------------------------ objects and their checker configuration
OBJS = {}
for o in ("S1", "S2", "CG", "O28", "O29b"):
    rep = json.load(open(os.path.join(OUT, "objects", "object-%s.json" % o)))
    OBJS[o] = {"rd": rep["run_dir"], "cfg": os.path.join(rep["world"], "cfg.json"), "check": os.path.join(rep["world"], "check_obj.py"),
               "cfg_env": "R4_DV18_OBJ_CFG", "policy": rep.get("declared_policy") or {}}
for it in ("a", "b", "e"):
    pk = json.load(open(os.path.join(OUT, "package-%s.json" % it)))
    w = pk["scratch_root"]
    cfg = json.load(open(os.path.join(w, "shims", "cfg.json")))
    OBJS["DV18-" + it] = {"rd": os.path.join(cfg["R"]["RUNS_DIR"], pk["label"]), "cfg": os.path.join(w, "shims", "cfg.json"),
                          "check": os.path.join(w, "shims", "check_dv18.py"), "cfg_env": "R4_DV18_CFG", "policy": {}}


def use(obj):
    o = OBJS[obj]
    cfg = json.load(open(o["cfg"]))
    for k, v in cfg["R"].items():
        setattr(R, k, v)
    os.environ[o["cfg_env"]] = o["cfg"]
    K.FROZEN_LAUNCHER = [sys.executable, "-B", o["check"]]
    return o["rd"]


def gaps(rd, ri1=True, rj1=True, rj2=True, rj3=True, rj4=True):
    g = GAPS._evaluate(rd, GAPS.NONLAUNCH_R4 if rj2 else GAPS.NONLAUNCH_BEFORE_RJ2, ri1, rj1, rj3, rj4)
    return {"named_gaps": [{k: v for k, v in x.items() if k in ("kind", "dir", "tag", "N", "Ncg", "count_read", "ordinals", "stdout_path",
                                                                    "comparator_launch_records", "key_present", "why")} for x in g["named_gaps"]],
            "named_kinds": sorted({x["kind"] for x in g["named_gaps"]}), "gap_files": g["gap_files"], "any_gap": g["any_gap"],
            "conditions": g["conditions"], "attribution": g["attribution"]}


def verdict(rd, **cond):
    """The delivered r4 checker, with -- in THIS scratch evaluator only -- the gap computation's named conditions off."""
    real = GAPS.recorder_gaps
    nl = GAPS.NONLAUNCH_R4 if cond.get("rj2", True) else GAPS.NONLAUNCH_BEFORE_RJ2
    GAPS.recorder_gaps = lambda r: GAPS._evaluate(r, nl, cond.get("ri1", True), cond.get("rj1", True), cond.get("rj3", True), cond.get("rj4", True))
    try:
        buf, v = io.StringIO(), {}
        with contextlib.redirect_stdout(buf):
            rc = K.main(rd, verdict_out=v)
    finally:
        GAPS.recorder_gaps = real
    return {"exit": rc, "verdict": v.get("verdict"), "stop_classes": v.get("stop_classes"), "r4_items": v.get("r4_errors"),
            "frozen_checker_exit": v.get("frozen_checker_exit")}


class InPlace(object):
    """Save solver-events.json bytes, yield the parsed document for an in-place edit, write it, and restore after."""
    def __init__(self, rd):
        self.p = os.path.join(rd, EV)

    def __enter__(self):
        self.orig = open(self.p, "rb").read()
        self.orig_sha = hashlib.sha256(self.orig).hexdigest()
        self.doc = json.loads(self.orig)
        return self

    def write(self):
        with open(self.p, "w") as fh:
            json.dump(self.doc, fh, indent=1)

    def __exit__(self, *a):
        with open(self.p, "wb") as fh:
            fh.write(self.orig)
        self.restored = sha(self.p) == self.orig_sha
        if not self.restored:
            STOPS.append("in-place restore failed for %s" % self.p)
        return False


def item(name, obj, alteration, expect, edit, conds=(), exp_by_cond=None):
    """Run one in-place alteration: gap level with every condition on (and each named condition off), verdict level
    for each; expectation predicates on the gap-level results."""
    rd = use(obj)
    row = {"item": name, "object": obj, "run_dir": rd, "alteration": alteration, "expectation_gap_level": expect}
    with InPlace(rd) as ip:
        detail = edit(ip.doc, rd)
        ip.write()
        row["alteration_detail"] = detail
        row["gap_level_all_on"] = gaps(rd)
        row["verdict_level_all_on"] = verdict(rd)
        for c in conds:
            row["gap_level_%s_disabled" % c] = gaps(rd, **{c: False})
            row["verdict_level_%s_disabled" % c] = verdict(rd, **{c: False})
    row["restored_sha256_equal"] = ip.restored
    ok = (exp_by_cond or {}).get("all_on", lambda g: True)(row["gap_level_all_on"])
    for c in conds:
        ok = ok and (exp_by_cond or {}).get(c, lambda g: True)(row["gap_level_%s_disabled" % c])
    row["pass"] = bool(ok) and ip.restored
    for k in list(row):
        if k.startswith("gap_level"):
            row[k] = {kk: vv for kk, vv in row[k].items() if kk != "attribution"}
    RESULTS["items"].append(row)
    print("  %-70s %s" % (name, "PASS" if row["pass"] else "FAIL"), flush=True)
    if not row["pass"]:
        STOPS.append("%s did not meet its expectation" % name)
    return row


def launch_idx(doc, pred):
    return [i for i, r in enumerate(doc["launch_records"]) if pred(r)]


def rel(r, rd):
    return str(r.get("stdout_path", ""))[len(rd) + 1:] if str(r.get("stdout_path", "")).startswith(rd + "/") else None


# ------------------------------------------------------------------ (32) / (26): every unaltered object, first
print("(32) positive control on every unaltered object (before any alteration)", flush=True)
for obj in OBJS:
    rd = use(obj)
    g = gaps(rd)
    v = verdict(rd)
    RESULTS["positive_control_32"][obj] = {"run_dir": rd, "named_gaps": g["named_gaps"], "gap_files": g["gap_files"], "verdict": v}
    ok = not g["any_gap"]
    RESULTS["positive_control_32"][obj]["pass"] = ok
    print("  %-10s any_gap=%s verdict=%s" % (obj, g["any_gap"], v["verdict"]), flush=True)
    if not ok:
        STOPS.append("(32) / (26): unaltered object %s yields a gap: %s" % (obj, g["named_kinds"] + [x["file"] for x in g["gap_files"]][:5]))
# attribution facts on unaltered objects: RH-1 (vi) renamed files (19), (20); RH-1 (iii) callgrind out (21)
att = {}
for obj, pat_ in (("S1", r"^solver/.*\.ssf-attempt\d+$"), ("S2", r"^health/.*\.ssf-attempt\d+$"), ("CG", r"^solver/.*\.callgrind\.out$")):
    rd = use(obj)
    g = GAPS.recorder_gaps(rd)
    att[obj] = {f: g["attribution"].get(f) for f in g["files"] if re.match(pat_, f)}
RESULTS["attribution_facts"] = att
f19 = {f: v for f, v in att["S1"].items()}
f20 = {f: v for f, v in att["S2"].items()}
f21 = {f: v for f, v in att["CG"].items()}
RESULTS["(19) renamed attempt files attributed by RH-1 (vi)"] = {"files": f19, "pass": bool(f19) and all(any(c == "vi" for _o, c in v) for v in f19.values())}
RESULTS["(20) renamed attempt files attributed by RH-1 (vi) at S-2"] = {"files": f20, "pass": bool(f20) and all(any(c == "vi" for _o, c in v) for v in f20.values())}
RESULTS["(21) callgrind out attributed by RH-1 (iii)"] = {"files": f21, "pass": bool(f21) and all(any(c == "iii" for _o, c in v) for v in f21.values())}
for k in ("(19) renamed attempt files attributed by RH-1 (vi)", "(20) renamed attempt files attributed by RH-1 (vi) at S-2", "(21) callgrind out attributed by RH-1 (iii)"):
    if not RESULTS[k]["pass"]:
        STOPS.append("%s: not attributed as required" % k)
    print("  %-70s %s" % (k, "PASS" if RESULTS[k]["pass"] else "FAIL"), flush=True)

has = lambda kind: (lambda g: kind in g["named_kinds"])                     # noqa: E731
nogap = lambda g: not g["any_gap"]                                           # noqa: E731
no_ri1 = lambda g: not any(k in ("COUNT GAP", "SITE COUNT GAP", "DUPLICATE-PATH GAP") for k in g["named_kinds"]) and not g["gap_files"]  # noqa: E731
pol = OBJS["S1"]["policy"]
tags_by_n = {n + 1: t for t, n in pol.items()}                              # N = n + 1 attempts
tA, tB, tC = tags_by_n[2], tags_by_n[3], tags_by_n[6]
RESULTS["S1_declared_tags"] = {"N=2": tA, "N=3": tB, "N=6": tC}
htag = list(OBJS["S2"]["policy"])[0]


def remove_kth_launch(tag, k, d="solver"):
    def edit(doc, rd):
        idx = launch_idx(doc, lambda r: rel(r, rd) == "%s/%s.ms.log" % (d, tag))
        rm = idx[k - 1]
        rec = doc["launch_records"].pop(rm)
        return {"removed_launch_record_ordinal": rec.get("ordinal"), "of_N": len(idx), "k": k}
    return edit


def remove_launches(tag, ks, d="solver"):
    def edit(doc, rd):
        idx = launch_idx(doc, lambda r: rel(r, rd) == "%s/%s.ms.log" % (d, tag))
        rms = sorted((idx[k - 1] for k in ks), reverse=True)
        ords = [doc["launch_records"].pop(i).get("ordinal") for i in rms]
        return {"removed_launch_record_ordinals": ords, "of_N": len(idx), "ks": list(ks)}
    return edit


def remove_renamed_entry(tag, site):
    def edit(doc, rd):
        ev = [e for e in doc["sites"][site]["events"] if e.get("tag") == tag][0]
        key = sorted(ev.get("renamed_files") or {})[0]
        ev["renamed_files"].pop(key)
        return {"removed_renamed_files_key": key}
    return edit


print("(19), (20), (24), (25), (27), (22), (31): S1 / S2 in place", flush=True)
item("(19) renamed_files entry removed (N=2 tag %s)" % tA, "S1", "the SE-3 event's renamed_files['attempt1'] removed", "a recorder gap and FAIL",
     remove_renamed_entry(tA, R.SITE_S1), exp_by_cond={"all_on": lambda g: bool(g["gap_files"]) or bool(g["named_gaps"])})
item("(19) one launch record of the tag removed (RI-1 reading: COUNT GAP)", "S1", "the last launch record of %s removed" % tA, "COUNT GAP and FAIL",
     remove_kth_launch(tA, 2), exp_by_cond={"all_on": has("COUNT GAP")})
item("(20) renamed_files entry removed at S-2 (%s)" % htag, "S2", "the HR-3 event's renamed_files['attempt1'] removed", "a recorder gap and FAIL",
     remove_renamed_entry(htag, R.SITE_S2), exp_by_cond={"all_on": lambda g: bool(g["gap_files"]) or bool(g["named_gaps"])})
item("(20) one launch record of the tag removed at S-2", "S2", "the last launch record of %s removed" % htag, "COUNT GAP and FAIL",
     remove_kth_launch(htag, 2, "health"), exp_by_cond={"all_on": has("COUNT GAP")})
for lr, tag, k, d, obj in (("LR-1 (two attempts, the final record removed)", tA, 2, "solver", "S1"),
                           ("LR-2 (attempt 1's record removed)", tA, 1, "solver", "S1"),
                           ("LR-3 (three attempts, attempt 2's record removed)", tB, 2, "solver", "S1"),
                           ("LR-5 (an HR-3 re-solve at S-2, the final record removed)", htag, 2, "health", obj if False else "S2")):
    item("(24) %s; (25) the same with RI-1 (a), (d) disabled" % lr, obj, "launch record %d of %s removed" % (k, tag),
         "RI-1 on: COUNT GAP and FAIL; RI-1 (a), (d) off (scratch evaluator): NO RI-1 named gap and NO recorder gap (else STOP: the check cannot see the repair)",
         remove_kth_launch(tag, k, d), conds=("ri1",), exp_by_cond={"all_on": has("COUNT GAP"), "ri1": no_ri1})
for tag, n in ((tA, 2), (tB, 3), (tC, 6)):
    for k in range(1, n + 1):
        item("(24) single removal: N=%d tag %s, record %d" % (n, tag, k), "S1", "launch record %d of %s removed" % (k, tag), "COUNT GAP and FAIL",
             remove_kth_launch(tag, k), exp_by_cond={"all_on": has("COUNT GAP")})
for ks in ((1, 2), (1, 3), (2, 3)):
    item("(24) LR-4 two removals of three: tag %s records %s" % (tB, ks), "S1", "launch records %s of %s removed" % (ks, tB), "COUNT GAP and FAIL",
         remove_launches(tB, ks), exp_by_cond={"all_on": has("COUNT GAP")})


def s1_single_tags(doc):
    ev = {e["tag"] for e in doc["sites"][R.SITE_S1]["events"]}
    return sorted({a["tag"] for a in doc["sites"][R.SITE_S1]["attempt_records"]} - ev - set(pol))


def e27a(doc, rd):
    t = s1_single_tags(doc)[0]
    i = [j for j, a in enumerate(doc["sites"][R.SITE_S1]["attempt_records"]) if a["tag"] == t][0]
    doc["sites"][R.SITE_S1]["attempt_records"].pop(i)
    return {"tag": t, "removed_attempt_record_index": i}


def e27b(doc, rd):
    t = s1_single_tags(doc)[0]
    i = launch_idx(doc, lambda r: rel(r, rd) == "solver/%s.ms.log" % t)[0]
    doc["launch_records"].insert(i + 1, copy.deepcopy(doc["launch_records"][i]))
    return {"tag": t, "duplicated_launch_record_index": i}


def e27c(doc, rd):
    doc["sites"][R.SITE_S1]["counters"]["attempts_total"] -= 1
    return {"counter": "attempts_total", "now": doc["sites"][R.SITE_S1]["counters"]["attempts_total"]}


def child_job_idx(doc, rd, job, to_cache=False):
    out = []
    for i, r in enumerate(doc["launch_records"]):
        p = rel(r, rd)
        if p and p.startswith("child/") and p.endswith(".stdout"):
            sp = os.path.join(rd, p[:-len(".stdout")] + ".spec.json")
            if os.path.exists(sp):
                s = json.load(open(sp))
                if s.get("job") == job and bool(s.get("to_cache")) == to_cache:
                    out.append(i)
    return out


def e27d(doc, rd):
    i = child_job_idx(doc, rd, "build_poly")[0]
    doc["launch_records"].insert(i + 1, copy.deepcopy(doc["launch_records"][i]))
    return {"duplicated_child_job_launch_record_index": i, "stdout_path": doc["launch_records"][i]["stdout_path"]}


item("(27) a non-event tag's RB-1 attempt record removed", "S1", "one S-1 attempt record removed", "COUNT GAP and FAIL", e27a, exp_by_cond={"all_on": has("COUNT GAP")})
item("(27) a launch record duplicated", "S1", "one S-1 msolve launch record duplicated", "COUNT GAP and FAIL", e27b, exp_by_cond={"all_on": has("COUNT GAP")})
item("(27) a site counter decremented", "S1", "S-1 attempts_total - 1", "SITE COUNT GAP and FAIL", e27c, exp_by_cond={"all_on": has("SITE COUNT GAP")})
item("(27) a child-job launch record duplicated", "S1", "one build_poly child-job launch record duplicated", "DUPLICATE-PATH GAP and FAIL", e27d,
     exp_by_cond={"all_on": has("DUPLICATE-PATH GAP")})


def e22(job, n_files):
    def edit(doc, rd):
        i = child_job_idx(doc, rd, job)[0]
        rec = doc["launch_records"].pop(i)
        tag = os.path.basename(rec["stdout_path"])[:-len(".stdout")]
        present = sorted(f for f in os.listdir(os.path.join(rd, "child")) if f.startswith(tag + "."))
        return {"removed_child_job": tag, "job": job, "files_of_the_job_present": present, "expected_n_files": n_files}
    return edit


def exp22(n, job):
    def f(g):
        files = [x["file"] for x in g["gap_files"]]
        return len([x for x in files if x.startswith("child/")]) == n
    return f


item("(22) an UNCACHED build_poly child-job launch record removed", "S1", "the record removed", ".spec.json, .stdout, .stderr, .npz, .meta.json are recorder gaps; FAIL",
     e22("build_poly", 5), exp_by_cond={"all_on": exp22(5, "build_poly")})
item("(22) a raw_grid child-job launch record removed", "S1", "the record removed", ".spec.json, .stdout, .stderr, .meta.json are recorder gaps (the .npz is removed at v2_driver.py 144); FAIL",
     e22("raw_grid", 4), exp_by_cond={"all_on": exp22(4, "raw_grid")})


def e31(doc, rd):
    rec = copy.deepcopy(doc["launch_records"][0])
    rec["ordinal"] = max(r["ordinal"] for r in doc["launch_records"]) + 1
    rec["stdout_path"] = rd + "/solver/dv18_unknown_kind.out"
    rec["stderr_path"] = rd + "/solver/dv18_unknown_kind.err"
    doc["launch_records"].append(rec)
    return {"appended_stdout_path": rec["stdout_path"]}


item("(31) a launch record appended whose stdout_path is of none of RJ-4 (a)'s forms", "S1", "one record appended", "UNKNOWN-KIND GAP and FAIL", e31,
     exp_by_cond={"all_on": has("UNKNOWN-KIND GAP")})
# ------------------------------------------------------------------ (28), (29), (30) with the detectors enabled / disabled


def e28(doc, rd):
    idx = [i for i, r in enumerate(doc["launch_records"]) if re.match(r"^solver/[^/]+\.callgrind\.stdout$", rel(r, rd) or "")]
    rec = doc["launch_records"].pop(idx[0])
    return {"removed_callgrind_launch_record": rec.get("stdout_path"), "n_callgrind_records_before": len(idx), "its_child_end": rec.get("child_end"),
            "its_class": K.launch_record_class(rec)}


print("(28), (29), (30): detectors enabled / disabled (scratch evaluator only)", flush=True)
item("(28) CX-A: a callgrind child whose stdout open failed (stand-in), its launch record removed in place", "O28", "one callgrind launch record removed",
     "RJ-1 off: NO named gap and NO recorder gap (else STOP); RJ-1 on: CALLGRIND COUNT GAP and FAIL", e28, conds=("rj1",),
     exp_by_cond={"all_on": has("CALLGRIND COUNT GAP"), "rj1": nogap})


def e29(doc, rd):
    idx = [i for i, r in enumerate(doc["launch_records"]) if re.match(r"^pari/[^/]+\.gp\.stdout$", rel(r, rd) or "")]
    rec = doc["launch_records"].pop(idx[0])
    tag = os.path.basename(rec["stdout_path"])[:-len(".gp.stdout")]
    return {"removed_gp_launch_record": rec.get("stdout_path"), "gp_script": "pari/%s.gp" % tag, "n_gp_records_before": len(idx),
            "pari_files_present": sorted(os.listdir(os.path.join(rd, "pari")))}


def gp_script_gap(g):
    return any(re.match(r"^pari/[^/]+\.gp$", x["file"]) for x in g["gap_files"])


item("(29) first object: the DV-18 (e) controls-a1 package, its gp launch record removed in place", "DV18-e", "one gp launch record removed",
     "RJ-2 on: pari/<tag>.gp a recorder gap, FAIL; RJ-2 off: pari/<tag>.gp is not a gap (recorded at the gap level)", e29, conds=("rj2",),
     exp_by_cond={"all_on": gp_script_gap, "rj2": lambda g: not gp_script_gap(g)})
item("(29) second object (LKA-5): the controls-a1-shaped object whose gp stdout open failed (stand-in), its gp launch record removed", "O29b",
     "one gp launch record removed", "RJ-2 on: pari/<tag>.gp a recorder gap, FAIL; RJ-2 off: NO named gap and NO recorder gap", e29, conds=("rj2",),
     exp_by_cond={"all_on": gp_script_gap, "rj2": nogap})


def e30(doc, rd):
    idx = [i for i, r in enumerate(doc["launch_records"]) if (rel(r, rd) or "") == "comparator/stdout.log"]
    rec = doc["launch_records"].pop(idx[0])
    return {"removed_comparator_launch_record": rec.get("stdout_path"), "comparator_files": sorted(os.listdir(os.path.join(rd, "comparator")))}


item("(30) the DV-18 (b) anchor-identity package, its comparator launch record removed in place", "DV18-b", "the comparator launch record removed",
     "RJ-3 on: COMPARATOR COUNT GAP, FAIL; RJ-3 off: recorded at the gap level", e30, conds=("rj3",),
     exp_by_cond={"all_on": has("COMPARATOR COUNT GAP"), "rj3": lambda g: "COMPARATOR COUNT GAP" not in g["named_kinds"]})
# ------------------------------------------------------------------ the unaltered state is back
after = {}
for obj in OBJS:
    rd = use(obj)
    g = gaps(rd)
    after[obj] = {"any_gap": g["any_gap"]}
    if g["any_gap"]:
        STOPS.append("after the in-place checks, object %s no longer evaluates gap-free (restore)" % obj)
RESULTS["after_restore_gap_free"] = after
RESULTS["STOPS"] = STOPS
RESULTS["pass"] = not STOPS
with open(os.path.join(OUT, "alter-results.json"), "w") as fh:
    json.dump(RESULTS, fh, indent=1, default=str)
print("DV-18 in-place object checks:", "PASS" if not STOPS else "STOP: %s" % STOPS)
sys.exit(0 if not STOPS else 3)
