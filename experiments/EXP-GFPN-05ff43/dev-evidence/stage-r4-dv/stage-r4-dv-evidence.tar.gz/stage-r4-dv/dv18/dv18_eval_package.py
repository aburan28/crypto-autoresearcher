#!/usr/bin/env python3
"""DV-18 (a) / (b) / (e) EVALUATION of a development package written by dv18_packages.py (SCRATCH harness; read-only
on the package): RB-5 (c) with RF-4 (c) / RG-3 (d) (the development reading of "the r4 checks pass"), RL-6 (c') and
(e), RG-3 (a) (recorded by the launcher), RG-3 (e) argv substitution, RH-3 (a) spec "out" substitution, RI-4 / RJ-6
path values as DEC-20260924-daf670 LKA-4 words them, RF-4 (d) label fields, and the r4 verdict recorded.

usage: python3 -B dv18_eval_package.py DV18_OUT ITEM     (ITEM in a, b, e)
"""
import contextlib
import glob
import io
import json
import os
import re
import sys

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402
import yaml                                              # noqa: E402

OUT, ITEM = sys.argv[1], sys.argv[2]
PK = json.load(open(os.path.join(OUT, "package-%s.json" % ITEM)))
LABEL, W0 = PK["label"], PK["scratch_root"]
CMD = PK["command"]
PLAN_RID = PK["development_plan_copies"]["package_under_test"]["plan_run_id"]
CFG = json.load(open(os.path.join(W0, "shims", "cfg.json")))
RUNS = CFG["R"]["RUNS_DIR"]
RD = os.path.join(RUNS, LABEL)
D = RD
P = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "runs", PLAN_RID)
SCRATCHPAD = os.path.dirname(os.path.dirname(os.path.dirname(OUT.rstrip("/")))) if False else None
CAP = R.CAP_BYTES
EV = {"item": ITEM, "command": CMD, "label": LABEL, "run_dir_development": D, "run_dir_plan_substitute": P, "scratch_root": W0}
STOPS = []

for k, v in CFG["R"].items():
    setattr(R, k, v)
os.environ["R4_DV18_CFG"] = os.path.join(W0, "shims", "cfg.json")
sys.path.insert(0, R.V2_DIR)
sys.path.insert(0, R.A1_DIR)
import r4_check_run as K                                 # noqa: E402
import r4_gaps as GAPS                                   # noqa: E402
K.FROZEN_LAUNCHER = [sys.executable, "-B", os.path.join(W0, "shims", "check_dv18.py")]

man = yaml.safe_load(open(os.path.join(RD, "manifest.yaml")))["run"]
raw = json.load(open(os.path.join(RD, "raw-result.json")))
doc = json.load(open(os.path.join(RD, "solver-events.json")))
recs = doc.get("launch_records") or []
EV["package"] = {"status": man.get("status"), "failure_class": man.get("failure_class"), "gate_pass": (man.get("result") or {}).get("gate_pass"),
                 "raw_result_writer": man.get("raw_result_writer"), "wall_seconds": (man.get("timing") or {}).get("wall_seconds"),
                 "n_launch_records": len(recs), "verdict_recorded_by_the_wrapper": man.get("verdict")}
# ------------------------------------------------------------------ the r4 checker, standalone (frozen checker in its own process)
buf = io.StringIO()
vout = {}
with contextlib.redirect_stdout(buf):
    rc = K.main(RD, os.path.join(W0, "sc4-accounting.json"), verdict_out=vout)
out = buf.getvalue()
items_r4 = list(vout.get("r4_errors") or [])
EXPECTED3 = ["gate.regression_REG-1 not recorded PASS: NOT_EVALUABLE",
             "gate.regression_REG-1 d_branch None != d-parsed",
             "gate.regression_REG-1 exclusion-list sha256 differs from the plan's"]
EV["r4_checker"] = {"exit": rc, "verdict": vout.get("verdict"), "stop_classes": vout.get("stop_classes"), "frozen_checker_exit": vout.get("frozen_checker_exit"),
                    "r4_items": items_r4, "output": out.splitlines()}
rg3d = {"frozen_checker_exit_0": vout.get("frozen_checker_exit") == 0,
        "r4_items_exactly_the_three_REG-1_items_with_their_texts": sorted(items_r4) == sorted(EXPECTED3)}
EV["RG-3 (d) expected checker items"] = rg3d
if not all(rg3d.values()):
    STOPS.append("RG-3 (d): the frozen checker did not exit 0, or the r4 items are not exactly the three REG-1 items: %s" % items_r4)
# ------------------------------------------------------------------ RB-5 (c), RL-6 (c'), (e)
acc = (man.get("resources") or {}).get("child_readback_accounting") or {}
created = [r for r in recs if r.get("child_created") is True]
pair_ok = [r for r in created if r.get("rlimit_as_child_getrlimit") == {"soft": CAP, "hard": CAP}]
gaps = GAPS.recorder_gaps(RD)
sc4 = K.sc4_accounting(RD)
ratt = K.recorded_attempts(RD)
ok_s1 = [(s, t) for (s, t), a in ratt.items() if s == R.SITE_S1 and (a.get("rb1") or {}).get("outcome_class") == "ok"
         and os.path.exists(os.path.join(RD, "solver", t + ".ms.out"))]
ok_s2 = [(s, t) for (s, t), a in ratt.items() if s == R.SITE_S2 and (a.get("rb1") or {}).get("outcome_class") == "ok"
         and os.path.exists(os.path.join(RD, "health", t + ".ms.out"))]
rows_s1 = [r for r in sc4["rows"] if r.get("applicable") and r["site"] == R.SITE_S1]
rows_s2 = [r for r in sc4["rows"] if r.get("applicable") and r["site"] == R.SITE_S2]
builders = [r for r in created if str(r.get("stdout_path", "")).startswith(RD + "/child/")]
solves = [r for r in created if re.match(re.escape(RD) + r"/solver/[^/]+\.ms\.log$", str(r.get("stdout_path", "")))]
c = {"frozen_checker_exit_0": vout.get("frozen_checker_exit") == 0,
     "r4_checks_pass_under_RF-4_(c)_RG-3_(d)": rg3d["r4_items_exactly_the_three_REG-1_items_with_their_texts"],
     "no_evidenced_child_without_a_read_back": acc.get("created_with_pair_absent") == [],
     "every_created_child_has_its_pair_before_dedup_in_launch_records": len(pair_ok) == len(created) and (acc.get("per_source_entries_before_dedup") or {}).get("d_launch_records", 0) >= len(created),
     "SC-4_row_for_every_recorded_ok_S-1_attempt_with_a_retained_output": sorted(t for _s, t in ok_s1) == sorted(r["tag"] for r in rows_s1)}
counts = {"capped_children_evidenced": len(created), "builders_child_jobs": len(builders), "msolve_S-1": len(solves),
          "sc4_rows_S-1": len(rows_s1), "sc4_rows_S-2": len(rows_s2), "recorded_ok_S-1_with_output": len(ok_s1), "recorded_ok_S-2_with_output": len(ok_s2)}
if CMD == "controls":
    counts["RB-5 (c) statement for RUN-GFPN-bfe956"] = {"capped_children": 19, "builders": 11, "solves": 8, "sc4_rows": 8}
    c["capped_children_19_builders_11_solves_8_as_RB-5_(c)_states"] = (len(created), len(builders), len(solves)) == (19, 11, 8)
    c["sc4_rows_8_as_RB-5_(c)_states"] = len(rows_s1) == 8
if CMD == "controls-a1":
    c["sc4_rows_S-1_2_(a1_driver.py:166)"] = len(rows_s1) == 2
    hr = K.health_records(RD)
    s2_att = [(a.get("tag")) for a in ((doc.get("sites") or {}).get(R.SITE_S2) or {}).get("attempt_records") or []]
    cov_s2 = [g for g in sc4.get("coverage_gaps_named") or [] if g["site"] == R.SITE_S2]
    c["every_S-2_attempt_the_health_report_records_is_accounted"] = not cov_s2 and sorted({h.get("tag") for h in hr}) <= sorted(set(s2_att))
    counts["health_report_systems"] = len(hr)
    counts["S-2_attempt_records"] = len(s2_att)
cprime = {"every_child_created_record_carries_a_pair_equal_to_the_cap": len(pair_ok) == len(created),
          "RL-3_no_recorder_gap": not gaps["named_gaps"] and not gaps["gap_files"]}
if CMD == "anchor-identity":
    pts = ((doc.get("sites") or {}).get(R.SITE_S1) or {}).get("passthrough_records") or []
    comp_pt = [p for p in pts if p.get("tag") == "anchor_comparator_random"]
    EV["anchor_comparator_passthrough_record"] = comp_pt
    cprime["the_anchor_comparator_system_passthrough_record_carries_the_pair_and_threads"] = (
        len(comp_pt) == 1 and (comp_pt[0].get("rb1") or {}).get("rlimit_as_child_getrlimit") == {"soft": CAP, "hard": CAP}
        and (comp_pt[0].get("rb1") or {}).get("threads_executed") == 1)
EV["RB-5 (c) / RL-6 (e) requirements"] = c
EV["RL-6 (c')"] = cprime
EV["counts"] = counts
EV["recorder_gaps"] = {"named_gaps": gaps["named_gaps"], "gap_files": gaps["gap_files"], "non_launch_files": gaps["non_launch_files"]}
if not all(c.values()):
    STOPS.append("RB-5 (c) / RL-6 (e): %s" % sorted(k for k, v in c.items() if not v))
if not all(cprime.values()):
    STOPS.append("RL-6 (c'): %s" % sorted(k for k, v in cprime.items() if not v))
# ------------------------------------------------------------------ RG-3 (e) argv by path substitution
ALLOWED_BIN = {"msolve": "/usr/bin/msolve", "valgrind": "/usr/bin/valgrind", "gp": "/usr/bin/gp"}
argv_rows = []
for r in recs:
    av = r.get("argv")
    if not isinstance(av, list):
        argv_rows.append({"ordinal": r.get("ordinal"), "argv": av, "note": "no argv list (raise path)"})
        continue
    sub = [x.replace(D, P) for x in av]
    bad_form = [x for x in av if D in x and not (x == D or x.startswith(D + "/") or x.startswith("--callgrind-out-file=" + D + "/"))]
    b0 = os.path.basename(av[0])
    thr = av[av.index("-t") + 1] if "-t" in av else None
    row = {"ordinal": r.get("ordinal"), "argv_as_run": av, "argv_substituted": sub, "binary": av[0],
           "label_in_substituted": any(LABEL in x for x in sub), "scratch_root_in_substituted": any(W0 in x for x in sub),
           "run_dir_in_another_form": bad_form, "threads": thr}
    if b0 == "msolve":
        row["binary_flags_threads_as_plan"] = av[0] == ALLOWED_BIN["msolve"] and av[1:5] == ["-v", "2", "-t", "1"]
    elif b0 == "valgrind":
        row["binary_flags_threads_as_plan"] = av[0] == ALLOWED_BIN["valgrind"] and av[1] == "--tool=callgrind" and av[3] == ALLOWED_BIN["msolve"] and av[4:8] == ["-v", "2", "-t", "1"]
    elif b0 == "gp":
        row["binary_flags_threads_as_plan"] = av[0] == ALLOWED_BIN["gp"]
    else:
        row["binary_flags_threads_as_plan"] = os.path.isabs(av[0])            # the driver's python (child jobs) or the Sage python (comparator)
    row["ok"] = (not row["label_in_substituted"] and not row["scratch_root_in_substituted"] and not bad_form and row["binary_flags_threads_as_plan"])
    argv_rows.append(row)
EV["RG-3 (e) argv substitution"] = argv_rows
if not all(r.get("ok", True) for r in argv_rows):
    STOPS.append("RG-3 (e): an argv differs after substitution: %s" % [r["ordinal"] for r in argv_rows if not r.get("ok", True)])
# ------------------------------------------------------------------ RH-3 (a) spec "out" by path substitution
spec_rows = []
for sp in sorted(glob.glob(os.path.join(RD, "child", "*.spec.json"))):
    s = json.load(open(sp))
    tag = os.path.basename(sp)[:-len(".spec.json")]
    out_sub = s["out"].replace(D, P)
    exp_out = s["out"] if s.get("to_cache") else os.path.join(P, "child", tag)
    others = {k: v for k, v in s.items() if k != "out"}
    others_txt = json.dumps(others, sort_keys=True)
    row = {"spec": os.path.relpath(sp, RD), "out_as_written": s["out"], "out_substituted": out_sub, "expected": exp_out, "to_cache": s.get("to_cache"),
           "other_keys_carry_no_development_path": D not in others_txt and W0 not in others_txt and LABEL not in others_txt}
    row["ok"] = out_sub == exp_out and row["other_keys_carry_no_development_path"]
    spec_rows.append(row)
EV["RH-3 (a) spec out substitution"] = spec_rows
if not all(r["ok"] for r in spec_rows):
    STOPS.append("RH-3 (a): a spec value differs after substitution")
# ------------------------------------------------------------------ LKA-4 value table (RI-4 as RJ-6 extends it)
DEVVALS = {}
for k, (o, v) in PK["RF-4 (a) (1) replacements (original, development)"].items():
    if isinstance(v, str) and v != o:
        DEVVALS[k] = v
for k, (o, v) in [(k, x) for k, x in PK["RF-4 (a) (2) replacements (original, development)"].items() if isinstance(x, list) and len(x) == 2]:
    if isinstance(v, str):
        DEVVALS[k] = v
    elif isinstance(v, list):
        DEVVALS[k] = v[-1]
for k, v in CFG["mods"]["v2_common"].items():
    DEVVALS["child: v2_common." + k] = v
for k, v in CFG["mods"]["a1_common"].items():
    DEVVALS["child: a1_common." + k] = v
DEVVALS["development shim configuration"] = os.path.join(W0, "shims", "cfg.json")
DEVVALS["dev inputs directory"] = os.path.join(W0, "dev-inputs")
DEVVALS["development exp directory"] = os.path.join(W0, "exp")
DEVVALS["development runs directory"] = RUNS
DEVVAL_FORMS = []
for k, v in DEVVALS.items():
    DEVVAL_FORMS.append((k, v))
    DEVVAL_FORMS.append((k + " (repository-relative form)", os.path.relpath(v, REPO)))
LISTED = [("spec out (RH-3 (a); LKA-4 (a))", lambda f, p: f.startswith("child/") and f.endswith(".spec.json") and p == "/out"),
          ("a1_pari.py 97 script / command", lambda f, p: f == "raw-result.json" and re.search(r"/(script|command)$", p) and "pari" in p.lower()),
          ("a1_health.py 148 input.path", lambda f, p: (f.startswith("health/") or f == "raw-result.json") and p.endswith("/input/path")),
          ("a1_health.py 149 command", lambda f, p: (f.startswith("health/") or f == "raw-result.json") and p.endswith("/command")),
          ("S-2 attempt record command (r4_resolve)", lambda f, p: f == "solver-events.json" and re.search(r"/sites/a1_health\.run_system/attempt_records/\d+/command$", p)),
          ("command.txt line 2", lambda f, p: f == "command.txt" and p == "line 2"),
          ("launch record stdout_path / stderr_path", lambda f, p: f == "solver-events.json" and re.search(r"^/launch_records/\d+/(stdout_path|stderr_path)$", p)),
          ("argv (launch records; _slim child records)", lambda f, p: re.search(r"/argv/\d+$", p) is not None),
          ("raw['build']['npz'] (RI-4)", lambda f, p: f == "raw-result.json" and p == "/build/npz")]
LABEL_FIELDS = [("RF-4 (d): the looked-up package copied into raw-result.json", lambda f, p: f == "raw-result.json" and p.startswith("/package/")),
                ("RF-4 (d): a certificate's run_id", lambda f, p: f.startswith("certificates/") and p == "/run_id"),
                ("the run directory's name: manifest run.id", lambda f, p: f == "manifest.yaml" and p == "/run/id"),
                ("the run directory's name: the wrapper's RUN-ID argument (command.txt line 5)", lambda f, p: f == "command.txt" and p == "line 5"),
                ("the run directory's name: the r4 checker's text (it prints the run directory's name)", lambda f, p: f == "manifest.yaml" and p.startswith("/run/verdict/"))]


def walk(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from walk(v, path + "/" + str(k))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from walk(v, path + "/%d" % i)
    elif isinstance(o, str):
        yield path, o


def classify(f, p, v):
    row = {"file": f, "path": p, "raw": v}
    has_d, has_l, has_w = D in v, LABEL in v, W0 in v
    listed = next((n for n, t in LISTED if t(f, p)), None)
    sub = v.replace(D, P)
    row["substituted"] = sub
    if has_d:
        elems = v.split()
        bad = [e for e in elems if D in e and not (e == D or e.startswith(D + "/") or e.startswith("--callgrind-out-file=" + D + "/")
                                                   or e.startswith("GFPN_RUN_DIR=" + D))]
        row["form"] = "the development run directory as a path prefix / whole element" if not bad else "OTHER FORM: %s" % bad[:3]
    else:
        bad = []
        row["form"] = "no run directory"
    rest = sub
    accepted = []
    for n, dv in sorted(DEVVAL_FORMS, key=lambda x: -len(x[1])):
        if dv and dv in rest:
            accepted.append(n)
            rest = rest.replace(dv, "<%s>" % n)
    lab = next((n for n, t in LABEL_FIELDS if t(f, p)), None)
    label_left = LABEL in rest
    w_left = W0 in rest
    row["class"] = ("LISTED: " + listed) if listed else ("unlisted (LKA-4 (b))" if has_d else ("RF-4 (a) development value: %s" % accepted if accepted else
                                                                                             ("label field: %s" % lab if lab else "label / scratch root occurrence")))
    row["label_left_after_substitution"] = label_left
    row["scratch_root_left_after_substitution"] = w_left
    row["label_field"] = lab
    row["ok"] = not bad and not w_left and (not label_left or lab is not None)
    return row


table, text_rows = [], []
for dp, _d, fn in os.walk(RD):
    for name in sorted(fn):
        fp = os.path.join(dp, name)
        f = os.path.relpath(fp, RD)
        try:
            txt = open(fp, errors="replace").read()
        except OSError:
            continue
        if not (D in txt or LABEL in txt or W0 in txt):
            continue
        vals = None
        if name.endswith(".json"):
            try:
                vals = list(walk(json.loads(txt)))
            except Exception:                            # noqa: BLE001
                vals = None
        elif name.endswith(".yaml"):
            try:
                vals = list(walk(yaml.safe_load(txt)))
            except Exception:                            # noqa: BLE001
                vals = None
        elif name == "command.txt":
            vals = [("line %d" % (i + 1), l) for i, l in enumerate(txt.splitlines())]
        if vals is None:
            for i, l in enumerate(txt.splitlines()):
                if D in l or LABEL in l or W0 in l:
                    r = classify(f, "text line %d" % (i + 1), l)
                    r["class"] = "TEXT LOG line (not a structured recorded value): " + r["class"]
                    text_rows.append(r)
            continue
        for p, v in vals:
            if D in v or LABEL in v or W0 in v:
                table.append(classify(f, p, v))
listed_fields = {"spec out": any(r["class"].startswith("LISTED: spec out") for r in table),
                 "a1_pari.py 97 script / command": any("a1_pari" in r["class"] for r in table),
                 "a1_health.py 148 input.path": any("148 input.path" in r["class"] for r in table),
                 "a1_health.py 149 command": any("149 command" in r["class"] for r in table),
                 "S-2 attempt record command": any("S-2 attempt record command" in r["class"] for r in table),
                 "command.txt line 2": any("command.txt line 2" in r["class"] for r in table),
                 "launch record stdout_path / stderr_path": any("stdout_path / stderr_path" in r["class"] for r in table),
                 "argv": any("argv" in r["class"] for r in table),
                 "raw['build']['npz']": any("npz" in r["class"] for r in table)}
EV["LKA-4 value table"] = {"rows": table, "n_rows": len(table), "listed_fields_carried_by_this_package": listed_fields,
                           "listed_fields_absent_recorded_absent_not_a_STOP (LKA-4 (c))": sorted(k for k, v in listed_fields.items() if not v),
                           "text_log_rows": text_rows, "development_values": DEVVALS}
bad_rows = [r for r in table if not r["ok"]]
if bad_rows:
    STOPS.append("LKA-4 / RJ-6 / RF-4 (d): %d recorded value(s) carry the development run directory, label or scratch root in another form: %s"
                 % (len(bad_rows), [(r["file"], r["path"]) for r in bad_rows][:10]))
EV["text_log_rows_not_ok"] = [r for r in text_rows if not r["ok"]]
# ------------------------------------------------------------------ computation values equal the plan package's (RF-4 (d))
wd = ((man.get("resources") or {}).get("watchdogs_declared") or {})
EV["RF-4 (d) computation values"] = {"cap_requested": (man.get("resources") or {}).get("child_rlimit_as_requested_bytes") == CAP,
                                     "threads_executed": (man.get("resources") or {}).get("msolve_threads_executed") in ([1], []),
                                     "watchdogs_equal_to_trial_plan_v2": wd.get("equal_to_trial_plan_v2") is True,
                                     "PYTHONHASHSEED_driver_readback_0": (((man.get("environment") or {}).get("PYTHONHASHSEED_driver_readback") or {}).get("PYTHONHASHSEED_env")) == "0",
                                     "seeds_recorded": raw.get("seeds")}
if not all(v for k, v in EV["RF-4 (d) computation values"].items() if k != "seeds_recorded"):
    STOPS.append("RF-4 (d): a computation value differs from the plan package's")
EV["STOPS"] = STOPS
EV["pass"] = not STOPS
with open(os.path.join(OUT, "eval-%s.json" % ITEM), "w") as fh:
    json.dump(EV, fh, indent=1, default=str)
print("DV-18 (%s) %s: %s" % (ITEM, CMD, "PASS" if not STOPS else "STOP: %s" % STOPS))
print(json.dumps({"RG-3 (d)": rg3d, "(c)": c, "(c')": cprime, "counts": counts}, indent=1))
sys.exit(0 if not STOPS else 3)
