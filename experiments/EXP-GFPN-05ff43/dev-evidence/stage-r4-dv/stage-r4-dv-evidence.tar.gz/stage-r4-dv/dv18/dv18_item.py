#!/usr/bin/env python3
"""DV-18 (f) RECORDER-PATH ITEM HARNESS (EXP-GFPN-05ff43 r4 stage, TASK-20260924-d91a96). SCRATCH development program:
lives OUTSIDE the delivered tree (so the LKA-7 load scan of implementation-v2-r4/ is not about it), is never imported by
any entry, wrapper or checker, and never runs in a package.

usage: python3 -B dv18_item.py ITEM OUTDIR

One item per process. The DELIVERED r4 launch recorder is installed over the frozen v2_solver.run_child in THIS
scratch process by the delivered installation function (r4_recorder.install) with a scratch run directory
OUTDIR/<item>/rundir (its launch records go to that directory's solver-events.json through the delivered single event
writer). Each call goes through the delivered recorder (r4_recorder.launch_recorder), which calls the captured frozen
function. Development STAND-INS, where an item names one, replace ONLY: a frozen CALLEE of the frozen function resolved
as a v2_solver module global at call time (v2_solver._perf_open_instructions, _perf_read, self_rss_bytes,
SolverLock.release), a process primitive AS v2_solver SEES IT (the module globals `os` and `resource` of v2_solver,
replaced by delegating proxies whose named function acts differently only where the item says), a primitive AS THE
RECORDER SEES IT (r4_recorder's module globals `os` and `_libc`, same method), or -- RL-6 (f) (iii)-(v) only -- the
recorder's captured original (a stand-in in place of the frozen function). No stand-in is ever at the recorder itself,
the SE-3 / HR-3 wrappers, or any other function of the r4 layer. Children run TRIVIAL development programs
(OUTDIR/progs/*.py); no solver runs. Every value here is a development observation, never evidence about D.
"""
import json
import os
import signal
import sys
import time
import traceback

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402
sys.path.insert(0, R.V2_DIR)
import v2_solver as V                                    # noqa: E402
import r4_resolve as RS                                  # noqa: E402
import r4_recorder as REC                                # noqa: E402
import r4_check_run as K                                 # noqa: E402  (record-level verdict functions only)

ITEM, OUT = sys.argv[1], sys.argv[2]
IDIR = os.path.join(OUT, ITEM)
RD = os.path.join(IDIR, "rundir")
PROGS = os.path.join(OUT, "progs")
os.makedirs(RD)                                          # an item runs once (the directory must not exist)
PARENT = os.getpid()
CAP = R.CAP_BYTES
PY = sys.executable
RESULT = {"item": ITEM, "parent_pid": PARENT, "stand_ins": [], "notes": [], "cap_bytes": CAP}


def prog(name, body):
    os.makedirs(PROGS, exist_ok=True)
    p = os.path.join(PROGS, name)
    if not os.path.exists(p):
        with open(p, "w") as fh:
            fh.write(body)
    return p


TRIVIAL = prog("trivial_ok.py", "import sys\nprint('dv18 trivial development child: exec reached')\nsys.exit(0)\n")
SLEEPER = prog("sleeper.py", "import time\ntime.sleep(60)\n")
EXIT3 = prog("exit3.py", "import sys\nprint('dv18 development child exits 3')\nsys.exit(3)\n")


def stand_in(target, process, what):
    RESULT["stand_ins"].append({"target": target, "process": process, "what": what})


class OsProxy(object):
    """A delegating proxy for the `os` module AS ONE MODULE SEES IT (installed as that module's global). Overrides are
    given per item; everything else is the real os."""
    def __init__(self, **over):
        self.__dict__["_over"] = over

    def __getattr__(self, name):
        o = self.__dict__["_over"]
        if name in o:
            return o[name]
        return getattr(os, name)


class ResProxy(object):
    def __init__(self, **over):
        self.__dict__["_over"] = over

    def __getattr__(self, name):
        o = self.__dict__["_over"]
        if name in o:
            return o[name]
        import resource
        return getattr(resource, name)


def in_child():
    return os.getpid() != PARENT


def caller_line():
    f = sys._getframe(2)
    return f.f_code.co_name, f.f_lineno


def install():
    RS._ensure_doc(RD)
    ident = REC.install(V, RD)
    rb, reasons = REC.readback(V)
    RESULT["install_identity"] = ident
    RESULT["install_readback"] = {"record": rb, "reasons": reasons}
    if reasons:
        raise SystemExit("RL-5 read-back failed in the scratch process: %s" % reasons)


def call(argv, name, **kw):
    """One call through the DELIVERED recorder. Returns (record or None, exception or None)."""
    so, se = os.path.join(IDIR, name + ".stdout"), os.path.join(IDIR, name + ".stderr")
    kw.setdefault("cap_bytes", CAP)
    try:
        res = REC.launch_recorder(argv, kw.pop("stdout_path", so), kw.pop("stderr_path", se), **kw)
        return res, None
    except BaseException as e:                           # noqa: BLE001
        if in_child():
            # a forked development child that left the frozen path: end it at once, never run the harness on
            os._exit(1)
        return None, e


def launch_records():
    try:
        return json.load(open(os.path.join(RD, "solver-events.json"))).get("launch_records") or []
    except Exception:                                    # noqa: BLE001
        return []


def record_level_verdict(doc_records):
    """The delivered r4 checker's record-level verdict functions on the launch records (RF-3 (a) with RG-1 (d);
    RF-0 (c)): FAIL if any finding."""
    errs = []
    doc = {"launch_records": doc_records}
    K.launch_class_check(doc, errs)
    K.undetermined_check({"raw_result_writer": "driver"}, doc, errs)
    return ("FAIL" if errs else "PASS"), errs, [K.launch_record_class(r) for r in doc_records]


def finish(checks, exc=None, same_exception=None):
    recs = launch_records()
    v, errs, classes = record_level_verdict(recs)
    RESULT["launch_records"] = recs
    RESULT["record_level_verdict"] = {"verdict": v, "findings": errs, "classes": classes}
    RESULT["foreign_files"] = sorted(f for f in os.listdir(RD) if f.startswith("recorder-foreign-"))
    RESULT["foreign_file_bodies"] = {f: open(os.path.join(RD, f)).read() for f in RESULT["foreign_files"]}
    RESULT["exception"] = None if exc is None else {"type": type(exc).__name__, "repr": repr(exc)[:300],
                                                    "re_raised_unchanged_same_object": same_exception}
    RESULT["events_doc_consistency_violation"] = (json.load(open(os.path.join(RD, "solver-events.json"))).get("consistency_violation")
                                                  if os.path.exists(os.path.join(RD, "solver-events.json")) else None)
    c = checks(recs, RESULT)
    RESULT["checks"] = c
    RESULT["pass"] = all(c.values())
    with open(os.path.join(IDIR, "result.json"), "w") as fh:
        json.dump(RESULT, fh, indent=1, default=str)
    print("%s: %s %s" % (ITEM, "PASS" if RESULT["pass"] else "FAIL", json.dumps(c)))
    sys.stdout.flush()
    os._exit(0 if RESULT["pass"] else 1)


def one(recs):
    return recs[0] if len(recs) == 1 else {}


PAIR = {"soft": CAP, "hard": CAP}
install()

# =========================================================================== (f) (xiv), (xv): FIRST on the r4 host
if ITEM == "xiv":
    res, e = call([PY, "-B", TRIVIAL], "xiv", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"one_record": len(recs) == 1, "child_created_true": one(recs).get("child_created") is True,
                            "pair_equal_cap": one(recs).get("rlimit_as_child_getrlimit") == PAIR,
                            "child_end_exec": one(recs).get("child_end") == "exec",
                            "time_enabled_ns_gt_0": isinstance((one(recs).get("child_end_observer") or {}).get("time_enabled_ns"), int)
                            and one(recs)["child_end_observer"]["time_enabled_ns"] > 0,
                            "returned_outcome_ok": (res or {}).get("outcome") == "ok", "class_B": K.launch_record_class(one(recs)) == "B"}, e)

if ITEM == "xv":
    def execv(path, args):
        if in_child():
            raise OSError("dv18 (xv) development stand-in: os.execv raises in the child only")
        return os.execv(path, args)
    V.os = OsProxy(execv=execv)
    stand_in("os.execv as v2_solver sees it (v2_solver module global os -> delegating proxy)", "the forked child only", "raises OSError")
    res, e = call([PY, "-B", TRIVIAL], "xv", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"one_record": len(recs) == 1, "returncode_99": one(recs).get("returncode") == 99,
                            "pair_read": one(recs).get("pair_read_by_parent") is True and one(recs).get("rlimit_as_child_getrlimit") == PAIR,
                            "child_end_frozen_pre_exec_exit": one(recs).get("child_end") == "frozen_pre_exec_exit",
                            "time_enabled_0_value_0": (one(recs).get("child_end_observer") or {}).get("time_enabled_ns") == 0
                            and (one(recs).get("child_end_observer") or {}).get("value") == 0,
                            "class_B": K.launch_record_class(one(recs)) == "B"}, e)

# =========================================================================== RL-6 (f) (i)-(v)
if ITEM == "i":
    res, e = call([PY, "-B", SLEEPER], "i", count_instructions=False, timeout_s=2)
    finish(lambda recs, r: {"returned_outcome_timeout": (res or {}).get("outcome") == "timeout",
                            "child_created_true": one(recs).get("child_created") is True, "pair_equal_cap": one(recs).get("rlimit_as_child_getrlimit") == PAIR}, e)
if ITEM == "ii":
    res, e = call([PY, "-B", EXIT3], "ii", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"returncode_3": (res or {}).get("returncode") == 3, "child_created_true": one(recs).get("child_created") is True,
                            "pair_equal_cap": one(recs).get("rlimit_as_child_getrlimit") == PAIR}, e)
if ITEM == "iii":
    def standin(argv, stdout_path, stderr_path, cap_bytes=None, timeout_s=None, count_instructions=True, cwd=None, env=None, lock=True):
        return {"argv": list(argv), "cap_bytes_requested": cap_bytes, "timeout_s": timeout_s, "outcome": "refused_to_start",
                "refusal_reason": "dv18 (iii) development stand-in: refusal before fork"}
    REC._ST["original"] = standin
    stand_in("the recorder's captured original (RL-6 (f): 'a development stand-in in place of the original')", "this process", "returns a refusal record without child_rlimit_report")
    res, e = call([PY, "-B", TRIVIAL], "iii", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"child_created_false": one(recs).get("child_created") is False, "no_child": one(recs).get("child_end") == "no_child",
                            "returned_unchanged": (res or {}).get("refusal_reason", "").startswith("dv18 (iii)")}, e)
if ITEM == "iv":
    def standin(argv, stdout_path, stderr_path, cap_bytes=None, timeout_s=None, count_instructions=True, cwd=None, env=None, lock=True):
        return {"argv": list(argv), "cap_bytes_requested": cap_bytes, "timeout_s": timeout_s, "child_rlimit_report": "ERR setrlimit (dv18 iv stand-in)",
                "outcome": "refused_to_start", "refusal_reason": "child could not set RLIMIT_AS: ERR setrlimit (dv18 iv stand-in)", "returncode": 97}
    REC._ST["original"] = standin
    stand_in("the recorder's captured original", "this process", "returns a record with the ERR setrlimit report and no pair")
    res, e = call([PY, "-B", TRIVIAL], "iv", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"pair_absent": one(recs).get("rlimit_as_child_getrlimit") == "absent",
                            "report_carried": one(recs).get("child_rlimit_report") == "ERR setrlimit (dv18 iv stand-in)",
                            "child_created_true": one(recs).get("child_created") is True}, e)
if ITEM == "v":
    marker = RuntimeError("dv18 (v) development stand-in raise")

    def standin(*a, **k):
        raise marker
    REC._ST["original"] = standin
    stand_in("the recorder's captured original", "this process", "raises RuntimeError")
    res, e = call([PY, "-B", TRIVIAL], "v", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"recorded": len(recs) == 1 and one(recs).get("raised") == "RuntimeError",
                            "re_raised_unchanged": e is marker}, e, e is marker)

# =========================================================================== RK-4 (c) (vi)-(ix)
if ITEM == "vi":
    def raiser(pid):
        raise RuntimeError("dv18 (vi) development stand-in: _perf_open_instructions raises")
    V._perf_open_instructions = raiser
    stand_in("v2_solver._perf_open_instructions (frozen callee, module global)", "this process (parent)", "raises at v2_solver.py 235")
    res, e = call([PY, "-B", TRIVIAL], "vi", count_instructions=True, timeout_s=120)
    RESULT["notes"].append("the frozen child is left waiting for the go byte (v2_solver.py 202); it is released when this development process exits (RKL-2) and then execs the trivial development program")
    finish(lambda recs, r: {"child_created_true": one(recs).get("child_created") is True, "pair_equal_cap": one(recs).get("rlimit_as_child_getrlimit") == PAIR,
                            "readback_from_raise_frame_record": one(recs).get("readback_from") == "raise_frame_record",
                            "raised_set": one(recs).get("raised") == "RuntimeError", "re_raised": isinstance(e, RuntimeError)}, e)
if ITEM == "vii":
    fake = {}

    def open_fake(pid):
        fd = os.open(os.devnull, os.O_RDONLY)
        fake["fd"] = fd
        return fd, None

    def raiser(fd):
        raise RuntimeError("dv18 (vii) development stand-in: _perf_read raises")
    # the host's hardware instruction counter is probed first; the stand-in for _perf_open_instructions is used ONLY
    # if the real one cannot open (recorded), so that _perf_read at v2_solver.py 281 is reached
    fd, why = V._perf_open_instructions(os.getpid())
    RESULT["host_hardware_instruction_counter"] = {"opened": fd is not None, "reason": why}
    if fd is not None:
        os.close(fd)
    else:
        V._perf_open_instructions = open_fake
        stand_in("v2_solver._perf_open_instructions (frozen callee)", "this process (parent)",
                 "returns an fd on /dev/null because the host's PERF_TYPE_HARDWARE counter does not open (%s); needed to reach 281" % why)
    V._perf_read = raiser
    stand_in("v2_solver._perf_read (frozen callee, module global)", "this process (parent)", "raises at v2_solver.py 281 (after the child is reaped)")
    res, e = call([PY, "-B", TRIVIAL], "vii", count_instructions=True, timeout_s=120)
    finish(lambda recs, r: {"child_created_true": one(recs).get("child_created") is True, "pair_equal_cap": one(recs).get("rlimit_as_child_getrlimit") == PAIR,
                            "readback_from_raise_frame_record": one(recs).get("readback_from") == "raise_frame_record",
                            "raised_set": one(recs).get("raised") == "RuntimeError", "re_raised": isinstance(e, RuntimeError)}, e)
if ITEM == "viii":
    def raiser():
        raise RuntimeError("dv18 (viii) development stand-in: self_rss_bytes raises")
    V.self_rss_bytes = raiser
    stand_in("v2_solver.self_rss_bytes (frozen callee, module global)", "this process", "raises before fork")
    res, e = call([PY, "-B", TRIVIAL], "viii", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"child_created_false": one(recs).get("child_created") is False, "raised_set": one(recs).get("raised") == "RuntimeError",
                            "no_child": one(recs).get("child_end") == "no_child"}, e)
if ITEM == "ix":
    res, e = call([PY, "-B", TRIVIAL], "ix", count_instructions=False, timeout_s=120,
                  stdout_path=os.path.join(IDIR, "no-such-directory", "ix.stdout"), stderr_path=os.path.join(IDIR, "ix.stderr"))
    finish(lambda recs, r: {"child_created_true": one(recs).get("child_created") is True, "pair_absent": one(recs).get("rlimit_as_child_getrlimit") == "absent",
                            "report_empty": one(recs).get("child_rlimit_report") == "", "class_C": K.launch_record_class(one(recs)) == "C",
                            "child_end_frozen_pre_exec_exit": one(recs).get("child_end") == "frozen_pre_exec_exit"}, e)

# =========================================================================== RF-6 (f) (x)-(xiii)
if ITEM == "x":
    def fork():
        pid = os.fork()
        if pid > 0:
            raise MemoryError("dv18 (x) development stand-in: os.fork raises in the parent after the real fork")
        return pid
    V.os = OsProxy(fork=fork)
    stand_in("os.fork as v2_solver sees it", "the parent only", "calls the real fork, then raises MemoryError in the parent")
    res, e = call([PY, "-B", TRIVIAL], "x", count_instructions=False, timeout_s=120)
    RESULT["notes"].append("the child left waiting for the go byte is released when this development process exits (RKL-2) and then execs the trivial development program")
    finish(lambda recs, r: {"child_created_undetermined": one(recs).get("child_created") == "undetermined",
                            "raised_set": one(recs).get("raised") == "MemoryError", "re_raised": isinstance(e, MemoryError)}, e)
if ITEM == "xi":
    def read(fd, n):
        fn, line = caller_line()
        if not in_child() and fn == "_run_child_locked" and line == 214:
            raise OSError("dv18 (xi) development stand-in: os.read raises at v2_solver.py 214")
        return os.read(fd, n)

    def release(self):
        raise RuntimeError("dv18 (xi) development stand-in: SolverLock.release raises")
    V.os = OsProxy(read=read)
    V.SolverLock.release = release
    stand_in("os.read as v2_solver sees it", "the parent only, at v2_solver.py 214", "raises OSError")
    stand_in("v2_solver.SolverLock.release (frozen callee)", "this process", "raises RuntimeError")
    res, e = call([PY, "-B", TRIVIAL], "xi", count_instructions=False, timeout_s=120)
    RESULT["notes"].append("the child waiting for the go byte is released at process exit (RKL-2); the host lock file handle stays open until exit")
    finish(lambda recs, r: {"child_created_true": one(recs).get("child_created") is True, "pid_from_context_traceback": isinstance(one(recs).get("pid"), int)
                            and one(recs).get("pid") > 0 and any(f.get("chain_index", 0) >= 1 and f.get("pid_bound") for f in (one(recs).get("chain") or {}).get("locked_frames") or []),
                            "raised_set": one(recs).get("raised") == "RuntimeError"}, e)
if ITEM == "xii":
    n = {"k": 0}

    def pipe():
        fn, line = caller_line()
        if fn == "_run_child_locked" and line == 178:
            raise OSError("dv18 (xii) development stand-in: os.pipe raises at v2_solver.py 178")
        return os.pipe()

    def release(self):
        raise RuntimeError("dv18 (xii) development stand-in: SolverLock.release raises")
    V.os = OsProxy(pipe=pipe)
    V.SolverLock.release = release
    stand_in("os.pipe as v2_solver sees it", "this process, at v2_solver.py 178", "raises OSError")
    stand_in("v2_solver.SolverLock.release (frozen callee)", "this process", "raises RuntimeError")
    res, e = call([PY, "-B", TRIVIAL], "xii", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"child_created_false": one(recs).get("child_created") is False, "raised_set": one(recs).get("raised") == "RuntimeError"}, e)
if ITEM == "xiii":
    def fork():
        pid = os.fork()
        if pid == 0:
            raise RuntimeError("dv18 (xiii) development stand-in: os.fork raises in the CHILD after the real fork")
        return pid
    V.os = OsProxy(fork=fork)
    stand_in("os.fork as v2_solver sees it", "the forked child only", "raises RuntimeError in the child, so a recorder call ends in the child")
    res, e = call([PY, "-B", TRIVIAL], "xiii", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"one_foreign_file": len(r["foreign_files"]) == 1,
                            "foreign_file_names_child": bool(r["foreign_files"]) and r["foreign_files"][0] != "recorder-foreign-%d.json" % PARENT,
                            "no_launch_record_from_the_child": len(recs) == 1 and one(recs).get("caller") is not None,
                            "parent_record_child_created_true": one(recs).get("child_created") is True}, e)

# =========================================================================== RG-7 (f) (xvi)-(xx), RH-6 (f) (xxi)
if ITEM == "xvi":
    def fork():
        pid = os.fork()
        if pid == 0:
            raise KeyboardInterrupt()
        return pid

    def rec_open(path, flags, mode=0o777):
        if in_child() and os.path.basename(path).startswith("recorder-foreign-"):
            raise OSError("dv18 (xvi) development stand-in: the foreign-file open fails in the child")
        return os.open(path, flags, mode)
    V.os = OsProxy(fork=fork)
    REC.os = OsProxy(open=rec_open)
    stand_in("os.fork as v2_solver sees it", "the forked child only", "raises KeyboardInterrupt in the child (variant C of FO-1)")
    stand_in("os.open as r4_recorder sees it", "the forked child only", "fails for recorder-foreign-* names (RF-1 (b)'s write made to fail)")
    res, e = call([PY, "-B", TRIVIAL], "xvi", count_instructions=False, timeout_s=120)
    RESULT["notes"].append("the child, having left the frozen path, is ended by the harness with os._exit(1)")
    finish(lambda recs, r: {"child_end_undetermined": one(recs).get("child_end") == "undetermined",
                            "returncode_not_99": one(recs).get("returncode") not in (99, None),
                            "no_exec": (one(recs).get("child_end_observer") or {}).get("time_enabled_ns") == 0,
                            "no_foreign_file": r["foreign_files"] == [], "verdict_FAIL": r["record_level_verdict"]["verdict"] == "FAIL"}, e)
if ITEM in ("xvii-a", "xvii-b"):
    def read(fd, n):
        fn, line = caller_line()
        if in_child() and fn == "_run_child_locked" and line == 202:
            raise OSError("dv18 (xvii) development stand-in: os.read raises at v2_solver.py 202 in the child")
        return os.read(fd, n)

    def _exit(code):
        if in_child() and code == 99:
            raise KeyboardInterrupt()
        return os._exit(code)
    V.os = OsProxy(read=read, _exit=_exit)
    stand_in("os.read as v2_solver sees it", "the forked child only, at v2_solver.py 202", "raises OSError")
    stand_in("os._exit as v2_solver sees it", "the forked child only, when called with 99", "raises KeyboardInterrupt (variant B of FO-1)")
    if ITEM == "xvii-a":
        def rec_open(path, flags, mode=0o777):
            if in_child() and os.path.basename(path).startswith("recorder-foreign-"):
                raise OSError("dv18 (xvii-a) development stand-in: the foreign-file open fails in the child")
            return os.open(path, flags, mode)
        REC.os = OsProxy(open=rec_open)
        stand_in("os.open as r4_recorder sees it", "the forked child only", "fails for recorder-foreign-* names")
    else:
        def rec_write(fd, data):
            if in_child():
                raise KeyboardInterrupt()
            return os.write(fd, data)
        REC.os = OsProxy(write=rec_write)
        stand_in("os.write as r4_recorder sees it", "the forked child only", "raises KeyboardInterrupt (the foreign-file write interrupted)")
    res, e = call([PY, "-B", TRIVIAL], ITEM, count_instructions=False, timeout_s=120)
    RESULT["notes"].append("the child, having left the frozen path, is ended by the harness with os._exit(1)")

    def chk(recs, r):
        rec = one(recs)
        r["what_every_r4_artifact_shows"] = {"launch_record": {k: rec.get(k) for k in ("child_created", "pair_read_by_parent", "rlimit_as_child_getrlimit", "returncode",
                                                                                       "outcome", "raised", "child_end", "child_end_observer", "readback_from")},
                                             "foreign_files": r["foreign_files"], "foreign_file_bodies": r["foreign_file_bodies"],
                                             "record_level_verdict": r["record_level_verdict"]}
        return {"pair_read": rec.get("pair_read_by_parent") is True or rec.get("rlimit_as_child_getrlimit") == PAIR,
                "child_end_undetermined": rec.get("child_end") == "undetermined", "verdict_FAIL": r["record_level_verdict"]["verdict"] == "FAIL"}
    finish(chk, e)
if ITEM == "xviii":
    class LibcStandIn(object):
        def syscall(self, *a):
            return -1
    REC._libc = LibcStandIn()
    stand_in("_libc.syscall as r4_recorder sees it (the recorder's own perf_event_open call)", "this process", "returns -1 (the counter open fails)")
    res, e = call([PY, "-B", TRIVIAL], "xviii", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"counter_not_opened": (one(recs).get("child_end_observer") or {}).get("opened") is False,
                            "child_end_undetermined": one(recs).get("child_end") == "undetermined", "verdict_FAIL": r["record_level_verdict"]["verdict"] == "FAIL"}, e)
if ITEM == "xix":
    res, e = call([PY, "-B", TRIVIAL], "xix", count_instructions=False, timeout_s=120, cap_bytes=0)
    RESULT["notes"].append("no stand-in: the frozen refusal before fork for an invalid cap (v2_solver.py 152-155); cap 0 is a development value")
    finish(lambda recs, r: {"callback_not_fired": one(recs).get("callback_fired") is False, "child_end_no_child": one(recs).get("child_end") == "no_child",
                            "child_created_false": one(recs).get("child_created") is False, "class_A": K.launch_record_class(one(recs)) == "A"}, e)
if ITEM == "xx":
    def getrlimit(which):
        import resource
        s, h = resource.getrlimit(which)
        if in_child():
            return s, h - 4096
        return s, h

    def _exit(code):
        if in_child() and code == 98:
            time.sleep(1.5)                                  # stay alive until the parent has written the go byte
        return os._exit(code)
    V.resource = ResProxy(getrlimit=getrlimit)
    V.os = OsProxy(_exit=_exit)
    stand_in("resource.getrlimit as v2_solver sees it", "the forked child only", "returns (soft, hard - 4096): a hard-limit mismatch")
    stand_in("os._exit as v2_solver sees it", "the forked child only, when called with 98", "waits 1.5 s, then the real os._exit(98)")
    res, e = call([PY, "-B", TRIVIAL], "xx", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"returncode_98": one(recs).get("returncode") == 98,
                            "child_end_frozen_pre_exec_exit": one(recs).get("child_end") == "frozen_pre_exec_exit",
                            "pair_read_hard_mismatch": one(recs).get("rlimit_as_child_getrlimit") == {"soft": CAP, "hard": CAP - 4096}}, e)
if ITEM == "xxi":
    def handler(signum, frame):
        raise KeyboardInterrupt()
    signal.signal(signal.SIGUSR1, handler)

    def rec_open(path, flags, mode=0o777):
        if REC._ST.get("in_call") and str(path).startswith("/proc/self/task/") and not in_child():
            os.kill(os.getpid(), signal.SIGUSR1)
        return os.open(path, flags, mode)
    REC.os = OsProxy(open=rec_open)
    stand_in("a signal handler (SIGUSR1 -> KeyboardInterrupt)", "this process", "installed for the item")
    stand_in("os.open as r4_recorder sees it", "this process, only while a recorder call is in progress (i.e. inside the RG-1 callback)",
             "sends SIGUSR1 to this process, then opens")
    res, e = call([PY, "-B", TRIVIAL], "xxi", count_instructions=False, timeout_s=120)
    finish(lambda recs, r: {"callback_marked": bool(one(recs).get("callback_marks")) and one(recs).get("callback_exception") == "KeyboardInterrupt",
                            "child_end_undetermined": one(recs).get("child_end") == "undetermined", "verdict_FAIL": r["record_level_verdict"]["verdict"] == "FAIL"}, e)

raise SystemExit("unknown item %s" % ITEM)
