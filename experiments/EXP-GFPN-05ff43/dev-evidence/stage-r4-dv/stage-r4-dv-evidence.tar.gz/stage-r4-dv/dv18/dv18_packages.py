#!/usr/bin/env python3
"""DV-18 (a) controls, (b) anchor-identity, (e) controls-a1 -- DEVELOPMENT PACKAGES through the DELIVERED r4 entry and
the DELIVERED r4 run wrapper's `preflight` then `launch`, one development process per command (failclosed RF-4 (a) as
childend RG-3 and gapattr RH-3 amend it). SCRATCH harness (outside the delivered tree); never a gate package, never a
result, never evidence about D.

usage: python3 -B dv18_packages.py DV18_OUT CMD      CMD in {controls, anchor-identity, controls-a1}

THE CLOSED DEVELOPMENT HARNESS (RF-4 (a) (1)-(3); each replacement recorded with original and development value):
  (1) in this (the wrapper) process: r4_run_wrapper.RUNS; r4_common.RUNS_DIR, PLAN_V2_R4, PLAN_A1_R4 (development
      COPIES of the r4 plans in which the package under test carries a development label as its run id and every other
      value equals the r4 plan's), RECEIPT_R4_PHASE_A (the synthetic receipt of (3)), REG1_REFERENCE_RUN (value
      unchanged, recorded), LADDER_PATH (a byte-identical development copy, RG-3 (a));
  (2) r4_run_wrapper.ENTRY_V2 / ENTRY_A1 and r4_check_run.FROZEN_LAUNCHER point at DEVELOPMENT SHIMS whose only actions
      are to set, in the child, the attributes of (1) and v2_common EXP_DIR, LADDER_PATH, FIXTURE_N3_JSON,
      FIXTURE_N4_JSON and a1_common EXP_DIR, RUNS_DIR, LADDER_PATH to the same development values (by the r3 method:
      an import hook that sets the attributes right after the named module's own code has run), and then to run the
      DELIVERED entry or checker unchanged. The shims wrap, replace or trace no function of any module (RG-3 (b));
  (3) r4_run_wrapper.git_tree_state (the r4 files reported tracked and clean) and a synthetic development phase-A
      receipt at a redirected path, commit_sha = `git rev-parse HEAD` (RH-3 (b)), where R-6 would otherwise refuse.
NOTHING ELSE: DRIVER_PYTHONHASHSEED stays "0"; no frozen function, cap, argv, watchdog, stream, seed, K, target or
health-check value is replaced; no flag, mode or argument is added to the r4 wrapper, entry or checker; no real plan
file changes. GFPN_V2_CACHE_DIR is not set (as in a package).
"""
import contextlib
import copy
import datetime
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402

OUT, CMD = sys.argv[1], sys.argv[2]
CMDS = {"controls": ("v2r4", "controls", "a"), "anchor-identity": ("v2r4", "anchor", "b"), "controls-a1": ("a1r4", "controls_a1", "e")}
PLAN_KEY, KIND, ITEM = CMDS[CMD]
LABEL = "DEV-DV18-%s-%s" % (ITEM, CMD)
W0 = os.path.join(OUT, "world_%s" % ITEM)
EXP = os.path.join(W0, "exp")
RUNS = os.path.join(EXP, "runs")
INP = os.path.join(W0, "dev-inputs")
SHIMS = os.path.join(W0, "shims")
RD = os.path.join(RUNS, LABEL)
REP = {"command": CMD, "item": "DV-18 (%s)" % ITEM, "label": LABEL, "scratch_root": W0, "started": datetime.datetime.now(datetime.timezone.utc).isoformat()}


def dump(p, o):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as fh:
        json.dump(o, fh, indent=1, default=str)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def git(*a):
    argv = ["git", "-C", REPO] + list(a)
    REP.setdefault("git_argv", []).append(argv)
    return subprocess.run(argv, capture_output=True, text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")).stdout.strip()


if os.path.exists(W0):
    raise SystemExit("REFUSING: %s exists (DV-18 runs once; a re-run needs a recorded harness reason)" % W0)
os.makedirs(RUNS)
os.makedirs(INP)
os.makedirs(SHIMS)
# ---------------------------------------------------------------- LKA-11 (d): GFPN_V2_CAP_BYTES unset before the package
REP["GFPN_V2_CAP_BYTES_in_wrapper_environment"] = R.cap_env_readback()
if "GFPN_V2_CAP_BYTES" in os.environ:
    REP["STOP"] = "LKA-11 (d): GFPN_V2_CAP_BYTES is set"
    dump(os.path.join(OUT, "package-%s.json" % ITEM), REP)
    raise SystemExit(3)
sys.path.insert(0, R.V2_DIR)
sys.path.insert(0, R.A1_DIR)
# ---------------------------------------------------------------- development inputs (RG-3 (a): byte-identical copies)
# the fixture paths are read from the frozen module's own constants (imported read-only; no v2 module runs a command here)
import v2_common as C0                                   # noqa: E402
real_fx3, real_fx4, real_ladder = C0.FIXTURE_N3_JSON, C0.FIXTURE_N4_JSON, R.LADDER_PATH
dev_ladder, dev_fx3, dev_fx4 = (os.path.join(INP, "ladder.json"), os.path.join(INP, os.path.basename(real_fx3)), os.path.join(INP, os.path.basename(real_fx4)))
for a, b in ((real_ladder, dev_ladder), (real_fx3, dev_fx3), (real_fx4, dev_fx4)):
    shutil.copyfile(a, b)
REP["RG-3 (a) development input copies (sha256 side by side)"] = [
    {"real": os.path.relpath(a, REPO), "real_sha256": sha(a), "copy": b, "copy_sha256": sha(b), "equal": sha(a) == sha(b)}
    for a, b in ((real_ladder, dev_ladder), (real_fx3, dev_fx3), (real_fx4, dev_fx4))]
if not all(x["equal"] for x in REP["RG-3 (a) development input copies (sha256 side by side)"]):
    REP["STOP"] = "RG-3 (a): a development copy differs from the real file"
    dump(os.path.join(OUT, "package-%s.json" % ITEM), REP)
    raise SystemExit(3)
# ---------------------------------------------------------------- development plan copies (only the run id changes)
v2r4, a1r4 = R.load_json(R.PLAN_V2_R4), R.load_json(R.PLAN_A1_R4)
dv2, da1 = copy.deepcopy(v2r4), copy.deepcopy(a1r4)
target_plan = dv2 if PLAN_KEY == "v2r4" else da1
pk = [p for p in target_plan["packages"] if p["kind"] == KIND]
assert len(pk) == 1, (KIND, len(pk))
PLAN_RID = pk[0]["run_id"]
pk[0]["run_id"] = LABEL
dev_v2, dev_a1 = os.path.join(INP, "trial-plan-v2-r4.dev.json"), os.path.join(INP, "trial-plan-v2-a1-r4.dev.json")
dump(dev_v2, dv2)
dump(dev_a1, da1)


def diff_paths(a, b, path=""):
    out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            out += diff_paths(a.get(k), b.get(k), path + "/" + str(k))
    elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)):
            out += diff_paths(x, y, path + "/%d" % i)
    elif a != b:
        out.append({"path": path, "r4_plan": a, "development_copy": b})
    return out


REP["development_plan_copies"] = {"package_under_test": {"plan": PLAN_KEY, "plan_run_id": PLAN_RID, "development_label": LABEL, "kind": KIND},
                                  "differences_from_the_r4_plans": {"v2": diff_paths(v2r4, dv2), "a1": diff_paths(a1r4, da1)}}
# ---------------------------------------------------------------- (3) synthetic phase-A receipt, git stub
head = git("rev-parse", "HEAD")
r4files = sorted(os.path.relpath(os.path.join(dp, f), REPO) for dp, _d, fn in os.walk(os.path.join(REPO, R.R4_PATHS_REL[0])) for f in fn) + R.R4_PATHS_REL[1:]
rec_a = os.path.join(INP, "synthetic-4a47e5-phase-a-receipt.json")
dump(rec_a, {"synthetic": "DV-18 development only; never a receipt", "commit_sha": head,
             "path_sha256": {p: sha(os.path.join(REPO, p)) for p in r4files}})
REP["synthetic_phase_a_receipt"] = {"path": rec_a, "commit_sha": head, "git_rev_parse_HEAD_argv": ["git", "-C", REPO, "rev-parse", "HEAD"], "n_paths": len(r4files)}
import r4_run_wrapper as W                               # noqa: E402
import r4_check_run as K                                 # noqa: E402
real_git = W.git_tree_state
W.git_tree_state = lambda paths: (r4files, []) if paths == R.R4_PATHS_REL else real_git(paths)
# ---------------------------------------------------------------- (1) wrapper-process replacements
REPL1 = {"r4_run_wrapper.RUNS": (W.RUNS, RUNS), "r4_common.RUNS_DIR": (R.RUNS_DIR, RUNS), "r4_common.PLAN_V2_R4": (R.PLAN_V2_R4, dev_v2),
         "r4_common.PLAN_A1_R4": (R.PLAN_A1_R4, dev_a1), "r4_common.RECEIPT_R4_PHASE_A": (R.RECEIPT_R4_PHASE_A, rec_a),
         "r4_common.REG1_REFERENCE_RUN": (R.REG1_REFERENCE_RUN, R.REG1_REFERENCE_RUN), "r4_common.LADDER_PATH": (R.LADDER_PATH, dev_ladder)}
W.RUNS = RUNS
for k, (_o, v) in REPL1.items():
    if k.startswith("r4_common."):
        setattr(R, k.split(".", 1)[1], v)
REP["RF-4 (a) (1) replacements (original, development)"] = REPL1
REP["RF-4 (a) (3) replacements"] = {"r4_run_wrapper.git_tree_state": "stub: R4_PATHS_REL reported tracked and clean (%d files); every other tree read from git" % len(r4files),
                                    "r4_common.RECEIPT_R4_PHASE_A": rec_a}
# ---------------------------------------------------------------- (2) shims
CFG = {"layer_dir": LAYER,
       "R": {"RUNS_DIR": RUNS, "PLAN_V2_R4": dev_v2, "PLAN_A1_R4": dev_a1, "RECEIPT_R4_PHASE_A": rec_a, "REG1_REFERENCE_RUN": R.REG1_REFERENCE_RUN,
             "LADDER_PATH": dev_ladder},
       "mods": {"v2_common": {"EXP_DIR": EXP, "LADDER_PATH": dev_ladder, "FIXTURE_N3_JSON": dev_fx3, "FIXTURE_N4_JSON": dev_fx4},
                "a1_common": {"EXP_DIR": EXP, "RUNS_DIR": RUNS, "LADDER_PATH": dev_ladder}},
       "entry": {"v2": os.path.join(LAYER, "r4_entry_v2.py"), "a1": os.path.join(LAYER, "r4_entry_a1.py")}}
cfg_path = os.path.join(SHIMS, "cfg.json")
dump(cfg_path, CFG)
COMMON = r'''
import os, sys, json, runpy, importlib.abc, importlib.util
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R4_DV18_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r4_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
class Hook(importlib.abc.MetaPathFinder):
    """Sets the configured module attributes right after the named module's own code has run (attribute setting only)."""
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"]:
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"][_n].items():
                setattr(module, k, v)
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())
'''
ENTRY_SHIM = COMMON + r'''
entry = CFG["entry"][os.environ["R4_DV18_ENTRY"]]
sys.argv = [entry] + sys.argv[1:]
runpy.run_path(entry, run_name="__main__")
'''
CHECK_SHIM = COMMON + r'''
import r4_check_run as K
mode, rd = sys.argv[1], sys.argv[2]
sys.exit(K.frozen_v2(rd) if mode == "frozen-v2" else K.frozen_a1(rd))
'''
entry_shim, check_shim = os.path.join(SHIMS, "entry_dv18.py"), os.path.join(SHIMS, "check_dv18.py")
open(entry_shim, "w").write(ENTRY_SHIM)
open(check_shim, "w").write(CHECK_SHIM)
os.environ["R4_DV18_CFG"] = cfg_path
os.environ["R4_DV18_ENTRY"] = "v2" if PLAN_KEY == "v2r4" else "a1"
REPL2 = {"r4_run_wrapper.ENTRY_V2": (W.ENTRY_V2, entry_shim), "r4_run_wrapper.ENTRY_A1": (W.ENTRY_A1, entry_shim),
         "r4_check_run.FROZEN_LAUNCHER": (K.FROZEN_LAUNCHER, [sys.executable, "-B", check_shim]),
         "child: r4_common attributes": {k: v for k, v in CFG["R"].items()}, "child: v2_common / a1_common attributes": CFG["mods"]}
W.ENTRY_V2 = W.ENTRY_A1 = entry_shim
K.FROZEN_LAUNCHER = [sys.executable, "-B", check_shim]
REP["RF-4 (a) (2) replacements (original, development)"] = REPL2
REP["shim_sources"] = {"entry": ENTRY_SHIM, "check": CHECK_SHIM, "cfg": CFG}
REP["DRIVER_PYTHONHASHSEED"] = W.DRIVER_PYTHONHASHSEED
REP["GFPN_V2_CACHE_DIR_set"] = "GFPN_V2_CACHE_DIR" in os.environ
# ---------------------------------------------------------------- preflight (RF-4 (b)); R-10 retried after a quiet host
EXPECTED = (r"^R-7 repaired gate package RUN-GFPN-[0-9a-f]{6} has not run$",
            r"^R-7 REG-1 did not pass \(NOT_EVALUABLE\): G1 RUN-GFPN-[0-9a-f]{6} has not run$",
            r"^R-8 required earlier package RUN-GFPN-[0-9a-f]{6} \(.*\) has no manifest$",
            r"^R-8 \(RL-4\) read package RUN-GFPN-[0-9a-f]{6} \(.*\) has no manifest$",
            r"^R-7 controls_a1 image RUN-GFPN-[0-9a-f]{6} has not run$")
attempts = []
for k in range(3):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        refusals, info = W.preflight(LABEL)
    exp = [r for r in refusals if any(re.match(p, r) for p in EXPECTED)]
    r10 = [r for r in refusals if r.startswith("R-10 ")]
    other = [r for r in refusals if r not in exp and r not in r10]
    attempts.append({"attempt": k + 1, "at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "refusals_verbatim": refusals,
                     "expected": exp, "R-10": r10, "unexpected": other})
    if not r10:
        break
    if k < 2:
        time.sleep(600)
REP["preflight_attempts"] = attempts
last = attempts[-1]
if last["R-10"]:
    REP["STOP"] = "RF-4 (b): R-10 refusal on the third preflight attempt: an infrastructure stop of the stage, never a finding"
if last["unexpected"]:
    REP["STOP"] = "RF-4 (b): an unexpected preflight refusal: %s" % last["unexpected"]
if REP.get("STOP"):
    dump(os.path.join(OUT, "package-%s.json" % ITEM), REP)
    print("DV-18 (%s): STOP %s" % (ITEM, REP["STOP"]))
    raise SystemExit(3)
# ---------------------------------------------------------------- launch (the wrapper's execution path, in this process)
t0 = time.time()
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    rc = W.launch(LABEL, None, info)
REP["launch"] = {"rc": rc, "wrapper_stdout": buf.getvalue().splitlines(), "wall_seconds_harness": round(time.time() - t0, 1)}
dump(os.path.join(OUT, "package-%s.json" % ITEM), REP)
print("DV-18 (%s) %s launched: %s" % (ITEM, CMD, buf.getvalue().strip()[-300:]))
sys.stdout.flush()
