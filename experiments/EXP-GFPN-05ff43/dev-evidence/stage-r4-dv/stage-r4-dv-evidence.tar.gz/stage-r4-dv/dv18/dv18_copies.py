#!/usr/bin/env python3
"""DV-18 (i) THE r4 VERDICT ON DEVELOPMENT COPIES: readbackclose RK-4 (e) (1)-(6), failclosed RF-6 (i) (7)-(13), childend
RG-7 (i) (14), (15), gapattr RH-6 (i) (23). SCRATCH harness (never a package). Each copy is a COHERENT development copy
of a DV-7 (final) toy package, placed in its own copy world, edited as the item states, with the manifest's
solver_events block and child_readback_accounting recomputed by the delivered wrapper functions after the edit (so that
the carried V-7 integrity item holds and the item's own condition is what the verdict sees). The verdict is the
delivered r4 checker's (frozen checker in its own process through the toy check shim); dependant refusals are the
delivered r4 wrapper's preflight in the copy world (its other refusals -- the toy lineage's failed G2 and synthetic G3 /
G4 -- are recorded and are not the item). Toy harness values only; never evidence about D.

usage: python3 -B dv18_copies.py DV18_OUT DV7_OUT
"""
import contextlib
import copy
import io
import json
import os
import re
import shutil
import sys

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402
import r4_dv7 as T                                       # noqa: E402
import yaml                                              # noqa: E402

OUT, DV7 = sys.argv[1], sys.argv[2]
TDIR = os.path.join(DV7, "toy")
env = T.Toy(TDIR).load()
sys.path.insert(0, R.V2_DIR)
sys.path.insert(0, R.A1_DIR)
import r4_run_wrapper as W                               # noqa: E402
import r4_check_run as K                                 # noqa: E402
v2p = R.load_json(env["plan_v2r4"])
by = {p["order"]: p for p in v2p["packages"]}
G = v2p["gate"]["blocking_packages"]
WA = os.path.join(TDIR, "world_A", "exp", "runs")
RUNSB = os.path.join(TDIR, "world_B", "exp", "runs")
REC_B = os.path.join(TDIR, "toy-reference-receipt-worldB-G1.json")
REC_POST = os.path.join(TDIR, "toy-4a47e5-post-run-receipt.json")
for k, v in {"PLAN_V2_R4": env["plan_v2r4"], "PLAN_A1_R4": env["plan_a1r4"], "PLAN_V2": env["plan_v2"], "RECEIPT_R4_PHASE_A": env["receipt_a"],
             "RECEIPT_R4_PHASE_B": REC_POST, "REG1_REFERENCE_RUN": G[0], "RUNS_DIR": RUNSB, "RECEIPT_V2_PHASE_B": REC_B}.items():
    setattr(R, k, v)
K.FROZEN_LAUNCHER = [sys.executable, "-B", os.path.join(TDIR, "shims", "check_toy.py")]
real_git = W.git_tree_state
W.git_tree_state = lambda paths: (env["r4files"], []) if paths == R.R4_PATHS_REL else real_git(paths)
CAP = R.CAP_BYTES
RES = {"method": __doc__, "items": {}}
STOPS = []
CELLS, CELLS_DEP, F4, BUILD = by[7]["run_id"], by[10]["run_id"], by[5]["run_id"], by[6]["run_id"]
RES["toy_packages_used"] = {"cells (m=3 role, ZL-eligible kind)": CELLS, "its dependant (m=2 role, --prior-run, X-08)": CELLS_DEP, "F-4": F4,
                            "build (requires F-4)": BUILD, "G1": G[0], "G2 (requires / reads G1)": G[1]}


def world(name, ids):
    exp = os.path.join(OUT, "copies", name, "exp")
    runs = os.path.join(exp, "runs")
    if os.path.exists(os.path.dirname(exp)):
        raise SystemExit("REFUSING: %s exists" % os.path.dirname(exp))
    os.makedirs(runs)
    for i in ids:
        shutil.copytree(os.path.join(WA, i), os.path.join(runs, i))
    os.environ["R4_TOY_CFG"] = T.cfg_for(os.path.join(OUT, "copies", name), env, exp, RUNSB, REC_B, REC_POST, None)
    os.environ.pop("R4_TOY_PACKAGE", None)
    W.RUNS = runs
    return runs


def load(rd):
    man = yaml.safe_load(open(os.path.join(rd, "manifest.yaml")))
    doc = json.load(open(os.path.join(rd, "solver-events.json")))
    raw = json.load(open(os.path.join(rd, "raw-result.json")))
    return man, doc, raw


def save(rd, man, doc, raw=None):
    with open(os.path.join(rd, "solver-events.json"), "w") as fh:
        json.dump(doc, fh, indent=1)
    if raw is not None:
        with open(os.path.join(rd, "raw-result.json"), "w") as fh:
            json.dump(raw, fh, indent=1)
    raw = raw if raw is not None else json.load(open(os.path.join(rd, "raw-result.json")))
    run = man["run"]
    run["solver_events"] = W.solver_events_block(rd, raw)               # recomputed by the delivered wrapper function
    acc, _src = W.child_readback_accounting(rd, raw, doc)
    run["resources"]["child_readback_accounting"] = acc
    with open(os.path.join(rd, "manifest.yaml"), "w") as fh:
        yaml.safe_dump(man, fh, sort_keys=False, width=110)


def zl_transform(rd):
    """Empty launch records, attempt / pass-through records, events and counters; no file under child/, solver/,
    health/, comparator/, pari/; the manifest's read-back list and threads emptied (the frozen ZL item fires)."""
    man, doc, raw = load(rd)
    doc["launch_records"] = []
    for site, sec in doc["sites"].items():
        for k in ("events", "attempt_records", "passthrough_records", "records"):
            if k in sec:
                sec[k] = []
        for k, v in sec.get("counters", {}).items():
            sec["counters"][k] = {x: 0 for x in v} if isinstance(v, dict) else 0
    for d in ("child", "solver", "health", "comparator", "pari"):
        p = os.path.join(rd, d)
        if os.path.isdir(p):
            for f in os.listdir(p):
                os.remove(os.path.join(p, f))
    man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"] = []
    man["run"]["resources"]["msolve_threads_executed"] = []
    save(rd, man, doc)
    return man, doc


def verdict(rd):
    buf, v = io.StringIO(), {}
    with contextlib.redirect_stdout(buf):
        rc = K.main(rd, verdict_out=v)
    return {"exit": rc, "verdict": v.get("verdict"), "stop_classes": v.get("stop_classes"), "outcome_labels": v.get("outcome_labels"),
            "frozen_checker_exit": v.get("frozen_checker_exit"), "r4_items": v.get("r4_errors"),
            "frozen_items": K.frozen_items("\n".join(l for l in buf.getvalue().splitlines()))}


def dependant(rid):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        refusals, _info = W.preflight(rid)
    return refusals


def rec_item(name, expect, obs, ok):
    RES["items"][name] = {"expectation": expect, "observed": obs, "pass": bool(ok)}
    print("  %-78s %s" % (name, "PASS" if ok else "FAIL"), flush=True)
    if not ok:
        STOPS.append("DV-18 (i) %s did not meet its expectation" % name)


def first_ms_record(doc, rd_rec):
    return [i for i, r in enumerate(doc["launch_records"]) if re.match(r"^solver/[^/]+\.ms\.log$", str(r.get("stdout_path", ""))[len(rd_rec) + 1:])][0]


def rd_rec_of(rd):
    for l in open(os.path.join(rd, "command.txt")):
        if l.startswith("# GFPN_RUN_DIR="):
            return l.strip()[len("# GFPN_RUN_DIR="):]


# (1) PASS_ZL
runs = world("i01", [CELLS])
rd = os.path.join(runs, CELLS)
zl_transform(rd)
v = verdict(rd)
rec_item("(1) empty launch_records, no child file, the frozen checker's single ZL line -> PASS_ZL", "PASS_ZL", v,
         v["verdict"] == "PASS_ZL" and v["frozen_items"] == [K.ZL_ITEM])
# (2) the same with one launch record of any class -> FAIL
runs = world("i02", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc = zl_transform(rd)
src_rec = json.load(open(os.path.join(WA, CELLS, "solver-events.json")))["launch_records"][0]
doc["launch_records"] = [copy.deepcopy(src_rec)]
save(rd, man, doc)
v = verdict(rd)
rec_item("(2) the same with one launch record (a class (B) record copied from the toy package) -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (3) the ZL line plus any other failing item -> FAIL
runs = world("i03", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc = zl_transform(rd)
man["run"]["resources"]["host_mem_total_kB"] = None
save(rd, man, doc)
v = verdict(rd)
rec_item("(3) the ZL line plus another failing item (host RAM not recorded) -> FAIL", "FAIL", v, v["verdict"] == "FAIL" and K.ZL_ITEM in v["frozen_items"] and len(v["frozen_items"]) >= 2)
# (4) a gate-package copy with empty launch_records -> FAIL
runs = world("i04", [G[0]])
rd = os.path.join(runs, G[0])
zl_transform(rd)
v = verdict(rd)
rec_item("(4) a gate-package (G1) copy with empty launch_records -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (5) a failing F-4 copy does not refuse the next package; a failing copy of any other required package does
runs = world("i05", [G[0], G[1], F4] + [G[2], G[3]])
man, doc, raw = load(os.path.join(runs, F4))
man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"] = []
save(os.path.join(runs, F4), man, doc)
vf4 = verdict(os.path.join(runs, F4))
refs_f4 = dependant(BUILD)
naming_f4 = [r for r in refs_f4 if F4 in r and "RL-4" in r]
zl_transform(os.path.join(runs, G[0]))
vg1 = verdict(os.path.join(runs, G[0]))
refs_g1 = dependant(BUILD)
naming_g1 = [r for r in refs_g1 if ("read package %s" % G[0]) in r and "r4 verdict FAIL" in r]
rec_item("(5) a failing F-4 copy does not refuse the next package (build); a failing G1 copy (required, read) does", "no refusal naming F-4; a refusal naming G1",
         {"F-4 copy verdict": vf4, "build preflight refusals (F-4 failing)": refs_f4, "G1 copy verdict": vg1, "build preflight refusals (G1 failing too)": refs_g1},
         vf4["verdict"] == "FAIL" and not naming_f4 and vg1["verdict"] == "FAIL" and bool(naming_g1))
# (6) a FAIL package with an infrastructure launch stops the dependant with the RK-3 (c) / RF-3 (b) record
runs = world("i06", [G[0], G[2], G[3]])
rd = os.path.join(runs, G[0])
man, doc, raw = load(rd)
i = first_ms_record(doc, rd_rec_of(rd))
doc["launch_records"][i].update(child_created=False, pair_read_by_parent=False, raised="OSError", readback_from="raise_frame_record",
                                rlimit_as_child_getrlimit="absent", child_end="no_child")
save(rd, man, doc)
v = verdict(rd)
refs = dependant(G[1])
hit = [r for r in refs if ("read package %s" % G[0]) in r and "an infrastructure launch" in r]
rec_item("(6) a FAIL package with an infrastructure launch stops the dependant (G2) with the RK-3 (c) / RF-3 (b) record", "FAIL; dependant refused naming 'an infrastructure launch'",
         {"verdict": v, "dependant_refusals": refs}, v["verdict"] == "FAIL" and bool(hit))
# (7) a launch record whose child_created is undetermined -> FAIL
runs = world("i07", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
i = first_ms_record(doc, rd_rec_of(rd))
doc["launch_records"][i]["child_created"] = "undetermined"
save(rd, man, doc)
v = verdict(rd)
rec_item("(7) a launch record with child_created undetermined -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (8) raw_result_writer "wrapper" with empty launch_records -> FAIL (not PASS_ZL) and stops the dependant
runs = world("i08", [CELLS, G[0], G[1], G[2], G[3], BUILD])
rd = os.path.join(runs, CELLS)
man, doc = zl_transform(rd)
man["run"]["raw_result_writer"] = "wrapper"
save(rd, man, doc)
v = verdict(rd)
refs = dependant(CELLS_DEP)
hit = [r for r in refs if ("read package %s" % CELLS) in r and "r4 verdict FAIL" in r]
rec_item("(8) raw_result_writer 'wrapper' and empty launch_records -> FAIL, not PASS_ZL; the dependant (X-08) is refused", "FAIL; dependant refused",
         {"verdict": v, "dependant_refusals": refs}, v["verdict"] == "FAIL" and bool(hit))
# (9) a recorder-foreign file -> FAIL
runs = world("i09", [CELLS])
rd = os.path.join(runs, CELLS)
with open(os.path.join(rd, "recorder-foreign-4242.json"), "w") as fh:
    json.dump({"installing_pid": 1, "pid": 4242, "raised": None, "development_copy": "DV-18 (i) (9)"}, fh)
v = verdict(rd)
rec_item("(9) a recorder-foreign file -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (10) an "OK" report and no pair -> FAIL
runs = world("i10", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
i = first_ms_record(doc, rd_rec_of(rd))
doc["launch_records"][i].update(child_rlimit_report="OK %d %d" % (CAP, CAP), child_rlimit_report_carried=True, rlimit_as_child_getrlimit="absent",
                                pair_read_by_parent=False)
save(rd, man, doc)
v = verdict(rd)
rec_item("(10) an 'OK' report and no pair -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (11) the only no-pair launch is class (C), all else passing -> PASS
runs = world("i11", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
i = first_ms_record(doc, rd_rec_of(rd))
doc["launch_records"][i].update(child_rlimit_report="", child_rlimit_report_carried=True, rlimit_as_child_getrlimit="absent", pair_read_by_parent=False,
                                returncode=99, child_end="frozen_pre_exec_exit", outcome="refused_to_start")
save(rd, man, doc)
v = verdict(rd)
rec_item("(11) the only no-pair launch is class (C), all else passing -> PASS", "PASS", {"verdict": v, "class": K.launch_record_class(doc["launch_records"][i])},
         v["verdict"] == "PASS" and K.launch_record_class(doc["launch_records"][i]) == "C")
# (12) a class (A) record, all else passing -> PASS
runs = world("i12", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
i = first_ms_record(doc, rd_rec_of(rd))
r = doc["launch_records"][i]
for k in ("child_rlimit_report", "returncode"):
    r.pop(k, None)
r.update(child_rlimit_report_carried=False, child_created=False, pair_read_by_parent=False, rlimit_as_child_getrlimit="absent", child_end="no_child",
         callback_fired=False, outcome="refused_to_start", refusal_reason="DV-18 (i) (12) development copy: a refusal before fork")
save(rd, man, doc)
v = verdict(rd)
rec_item("(12) a class (A) record, all else passing -> PASS", "PASS", {"verdict": v, "class": K.launch_record_class(r)},
         v["verdict"] == "PASS" and K.launch_record_class(r) == "A")
# (13) raw_result_writer "wrapper" whose only launch record is a raise-frame record carrying a pair equal to the cap -> FAIL
runs = world("i13", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc = zl_transform(rd)
rr = copy.deepcopy(src_rec)
rr.update(readback_from="raise_frame_record", raised="RuntimeError", child_created=True, pair_read_by_parent=True,
          rlimit_as_child_getrlimit={"soft": CAP, "hard": CAP}, child_end="undetermined", argv="absent (raise path: RK-1 (b) copies no argv)")
doc["launch_records"] = [rr]
man["run"]["raw_result_writer"] = "wrapper"
man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"] = [{"soft": CAP, "hard": CAP}]
save(rd, man, doc)
v = verdict(rd)
rec_item("(13) raw_result_writer 'wrapper', only a raise-frame record with a pair equal to the cap -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (14) a class (B) record whose child_end is undetermined -> FAIL
runs = world("i14", [CELLS])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
i = first_ms_record(doc, rd_rec_of(rd))
doc["launch_records"][i]["child_end"] = "undetermined"
save(rd, man, doc)
v = verdict(rd)
rec_item("(14) a class (B) record whose child_end is undetermined -> FAIL", "FAIL", v, v["verdict"] == "FAIL")
# (15) an infrastructure-stop outcome (RG-2) -> FAIL, stop class 'an infrastructure launch', dependant refused
runs = world("i15", [CELLS, G[0], G[1], G[2], G[3], BUILD])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
for r in doc["launch_records"]:
    r.update(pair_read_by_parent=False, rlimit_as_child_getrlimit="absent", child_rlimit_report="", child_rlimit_report_carried=True,
             returncode=99, child_end="frozen_pre_exec_exit", outcome="refused_to_start")
man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"] = []
save(rd, man, doc)
v = verdict(rd)
refs = dependant(CELLS_DEP)
hit = [r for r in refs if ("read package %s" % CELLS) in r and "an infrastructure launch" in r]
rec_item("(15) an infrastructure-stop outcome (RG-2) -> FAIL with stop class 'an infrastructure launch'; the dependant refused", "FAIL; label RG-2; dependant refused",
         {"verdict": v, "dependant_refusals": refs},
         v["verdict"] == "FAIL" and any(s.startswith("an infrastructure launch") for s in v["stop_classes"] or [])
         and "infrastructure-stop outcome (RG-2)" in (v["outcome_labels"] or []) and bool(hit))
# (23) a cap-mismatch stop outcome (RH-2) -> FAIL with stop class 'a cap read-back mismatch'; the dependant refused
runs = world("i23", [CELLS, G[0], G[1], G[2], G[3], BUILD])
rd = os.path.join(runs, CELLS)
man, doc, raw = load(rd)
man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"] = [{"soft": CAP, "hard": CAP - 4096}]
save(rd, man, doc)
v = verdict(rd)
refs = dependant(CELLS_DEP)
hit = [r for r in refs if ("read package %s" % CELLS) in r and "a cap read-back mismatch" in r]
rec_item("(23) a cap-mismatch stop outcome (RH-2) -> FAIL with stop class 'a cap read-back mismatch'; the dependant refused", "FAIL; label RH-2; dependant refused",
         {"verdict": v, "dependant_refusals": refs},
         v["verdict"] == "FAIL" and any(s.startswith("a cap read-back mismatch") for s in v["stop_classes"] or [])
         and "cap-mismatch stop outcome (RH-2)" in (v["outcome_labels"] or []) and bool(hit))
RES["STOPS"] = STOPS
RES["pass"] = not STOPS
with open(os.path.join(OUT, "copies-results.json"), "w") as fh:
    json.dump(RES, fh, indent=1, default=str)
print("DV-18 (i) copies:", "PASS" if not STOPS else "STOP: %s" % STOPS)
sys.exit(0 if not STOPS else 3)
