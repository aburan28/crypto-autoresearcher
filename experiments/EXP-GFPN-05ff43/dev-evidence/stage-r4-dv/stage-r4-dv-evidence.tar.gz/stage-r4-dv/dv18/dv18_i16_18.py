#!/usr/bin/env python3
"""DV-18 (i) (16), (17), (18) on the DV-18 (a), (b), (e) development packages (SCRATCH; read-only): (16) the RG-3 (e)
substitution on (a) (read from eval-a.json); (17) the RG-4 attribution on (e) and (b): no recorder gap; (18) the RH-1
attribution: every child/*.npz, *.meta.json, *.spec.json, *.stdout, *.stderr and every comparator/ file attributed,
with the clause(s), and no recorder gap.  usage: python3 -B dv18_i16_18.py DV18_OUT"""
import json, os, re, sys
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2-r4")
import r4_gaps as GAPS
OUT = sys.argv[1]
rep, ok = {}, True
ea = json.load(open(os.path.join(OUT, "eval-a.json")))
rows = ea["RG-3 (e) argv substitution"]
rep["(16)"] = {"n_launches": len(rows), "every_substituted_argv_carries_neither_label_nor_scratch_root": all(not r.get("label_in_substituted") and not r.get("scratch_root_in_substituted") for r in rows if "argv_as_run" in r)}
ok &= rep["(16)"]["every_substituted_argv_carries_neither_label_nor_scratch_root"]
for it in ("a", "b", "e"):
    pk = json.load(open(os.path.join(OUT, "package-%s.json" % it)))
    cfg = json.load(open(os.path.join(pk["scratch_root"], "shims", "cfg.json")))
    rd = os.path.join(cfg["R"]["RUNS_DIR"], pk["label"])
    g = GAPS.recorder_gaps(rd)
    want = [f for f in g["files"] if re.match(r"^child/.*\.(npz|meta\.json|spec\.json|stdout|stderr)$", f) or f.startswith("comparator/")]
    att = {f: sorted({c for _o, c in g["attribution"].get(f) or []}) for f in want}
    r = {"files_checked": len(want), "attribution_clauses": att, "every_file_attributed": all(att[f] for f in want),
         "no_recorder_gap": not g["any_gap"]}
    rep["(18) %s" % it] = r
    ok &= r["every_file_attributed"] and r["no_recorder_gap"]
    if it in ("b", "e"):
        rep["(17) %s" % it] = {"no_recorder_gap": not g["any_gap"]}
        ok &= not g["any_gap"]
rep["pass"] = bool(ok)
json.dump(rep, open(os.path.join(OUT, "i16_18.json"), "w"), indent=1)
print(json.dumps({k: ({kk: vv for kk, vv in v.items() if kk != "attribution_clauses"} if isinstance(v, dict) else v) for k, v in rep.items()}, indent=1))
