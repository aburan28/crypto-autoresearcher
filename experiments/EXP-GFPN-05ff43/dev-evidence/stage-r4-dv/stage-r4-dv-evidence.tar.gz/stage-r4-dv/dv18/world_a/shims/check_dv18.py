
import os, sys, json, runpy, importlib.abc, importlib.util
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R4_DV18_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r4_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
class Hook(importlib.abc.MetaPathFinder):
    """Sets the configured module attributes right after the named module's own code has run (attribute setting only)."""
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"]:
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"][_n].items():
                setattr(module, k, v)
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())

import r4_check_run as K
mode, rd = sys.argv[1], sys.argv[2]
sys.exit(K.frozen_v2(rd) if mode == "frozen-v2" else K.frozen_a1(rd))
