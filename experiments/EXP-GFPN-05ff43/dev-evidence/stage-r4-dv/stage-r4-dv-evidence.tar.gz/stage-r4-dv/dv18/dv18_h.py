#!/usr/bin/env python3
"""DV-18 (h) CLOSURE SCAN on the DELIVERED r4 code and the frozen trees (readbackclose RK-4 (d) with RKR-2; childend
RGL-2; gapattr RH-5 (a)-(c); launchkind RJ-4 (c) read with DEC-20260924-daf670 LKA-7). Static (ast + modulefinder);
reads source only; runs no command. SCRATCH harness.

usage: python3 -B dv18_h.py DV18_OUT
"""
import ast
import importlib.metadata
import json
import modulefinder
import os
import sys

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
EXPD = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43")
LAYER = os.path.join(EXPD, "implementation-v2-r4")
V2 = os.path.join(EXPD, "implementation-v2")
A1 = os.path.join(EXPD, "implementation-v2-a1")
OUT = os.path.join(sys.argv[1], "h")
os.makedirs(OUT, exist_ok=True)
REP, STOPS = {}, []
LAUNCHERS = ("run_child", "Popen", "system", "popen", "fork", "forkpty", "spawnv", "spawnve", "spawnl", "posix_spawn", "posix_spawnp",
             "execv", "execve", "execvp", "execvpe", "execl", "execle", "execlp", "execlpe", "run", "call", "check_call", "check_output")
EXEC_FAMILY = ("execv", "execve", "execvp", "execvpe", "execl", "execle", "execlp", "execlpe", "posix_spawn", "posix_spawnp", "system", "popen",
               "fork", "forkpty", "spawnv", "spawnve", "spawnl")


def rel(p):
    return os.path.relpath(p, REPO)


# ------------------------------------------------------------------ (1) the delivered r4 entries' import closure
closure = {}
for entry in ("r4_entry_v2.py", "r4_entry_a1.py"):
    mf = modulefinder.ModuleFinder(path=[LAYER, V2, A1] + sys.path)
    mf.run_script(os.path.join(LAYER, entry))
    mods = {name: getattr(m, "__file__", None) for name, m in mf.modules.items()}
    closure[entry] = mods
repo_files = sorted({f for mods in closure.values() for f in mods.values() if f and os.path.abspath(f).startswith(EXPD + os.sep)})
third = {}
for mods in closure.values():
    for name, f in mods.items():
        if f and ("site-packages" in f or "dist-packages" in f):
            third.setdefault(name.split(".")[0], set()).add(f)
dists = {}
for top in sorted(third):
    try:
        cand = importlib.metadata.packages_distributions().get(top) or [top]
        dists[top] = {d: importlib.metadata.version(d) for d in cand}
    except Exception as e:                               # noqa: BLE001
        dists[top] = "version not determinable: %s" % type(e).__name__
REP["import_closure"] = {"method": "modulefinder.ModuleFinder(path=[r4 layer, implementation-v2, implementation-v2-a1] + sys.path).run_script(<entry>) "
                                   "(static; dynamic imports are not seen)",
                         "repository_files": [rel(f) for f in repo_files],
                         "n_modules": {e: len(m) for e, m in closure.items()}}
REP["RH-5 (c) third-party modules the r4 entries import (name, installed distribution versions)"] = {
    "modules": dists, "statement": "their code on an unwinding path was NOT scanned by this stage (only repository files are scanned); "
                                   "RGL-6 records the review's reading, not this scan"}


def parse(f):
    return ast.parse(open(f).read(), filename=f)


def funcs(tree):
    out = []

    def visit(node, prefix, top):
        for ch in ast.iter_child_nodes(node):
            if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)):
                out.append((prefix + ch.name, ch))
                visit(ch, prefix + ch.name + ".", False)
            elif isinstance(ch, ast.ClassDef):
                visit(ch, prefix + ch.name + ".", top)
            else:
                visit(ch, prefix, top)
    visit(tree, "", True)
    return out


def enclosing(tree, lineno):
    best = None
    for q, fn in funcs(tree):
        if fn.lineno <= lineno <= (fn.end_lineno or fn.lineno):
            if best is None or fn.lineno >= best[1].lineno:
                best = (q, fn)
    return best[0] if best else "<module>"


def callee(n):
    f = n.func
    if isinstance(f, ast.Attribute):
        return f.attr, (f.value.id if isinstance(f.value, ast.Name) else ast.unparse(f.value))
    if isinstance(f, ast.Name):
        return f.id, None
    return None, None


# ------------------------------------------------------------------ (2) RK-4 (d) / RLR-2 capture scan on the closure's repository files
cap = {"non_call_references_to_run_child_or__run_child_locked": [], "from_v2_solver_import": [], "module_level_launches": [],
       "other_modules_defining_v2_solver": [], "sys_modules_v2_solver_assignments": []}
for f in repo_files:
    tree = parse(f)
    src_lines = open(f).read().splitlines()
    call_funcs = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Call):
            call_funcs.add(id(n.func))
    for n in ast.walk(tree):
        if isinstance(n, (ast.Name, ast.Attribute)):
            name = n.id if isinstance(n, ast.Name) else n.attr
            if name in ("run_child", "_run_child_locked") and id(n) not in call_funcs:
                if isinstance(n, ast.Name) and isinstance(getattr(n, "ctx", None), ast.Store):
                    kind = "store"
                else:
                    kind = "store" if isinstance(getattr(n, "ctx", None), ast.Store) else "load"
                cap["non_call_references_to_run_child_or__run_child_locked"].append(
                    {"file": rel(f), "line": n.lineno, "function": enclosing(tree, n.lineno), "kind": kind, "text": src_lines[n.lineno - 1].strip()[:160]})
        if isinstance(n, ast.FunctionDef) and n.name in ("run_child", "_run_child_locked"):
            cap.setdefault("definitions", []).append({"file": rel(f), "name": n.name, "first_line": n.lineno})
        if isinstance(n, ast.ImportFrom) and n.module == "v2_solver":
            cap["from_v2_solver_import"].append({"file": rel(f), "line": n.lineno})
        if isinstance(n, ast.Subscript) and isinstance(n.value, ast.Attribute) and n.value.attr == "modules" and isinstance(n.slice, ast.Constant) \
                and n.slice.value == "v2_solver" and isinstance(getattr(n, "ctx", None), ast.Store):
            cap["sys_modules_v2_solver_assignments"].append({"file": rel(f), "line": n.lineno})
    for st in tree.body:
        for n in ast.walk(st):
            if isinstance(n, ast.Call) and (callee(n)[0] == "run_child" or callee(n)[1] == "subprocess" or (callee(n)[1] == "os" and callee(n)[0] in EXEC_FAMILY)) \
                    and not isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                cap["module_level_launches"].append({"file": rel(f), "line": n.lineno, "callee": callee(n)[0]})
    if os.path.basename(f) == "v2_solver.py" and os.path.abspath(f) != os.path.join(V2, "v2_solver.py"):
        cap["other_modules_defining_v2_solver"].append(rel(f))
allowed_refs = []
bad_refs = []
for r in cap["non_call_references_to_run_child_or__run_child_locked"]:
    if r["file"].endswith("implementation-v2-r4/r4_recorder.py") and r["function"] in ("install", "readback"):
        allowed_refs.append(r)
    elif r["file"].endswith("implementation-v2/v2_solver.py") and r["function"] == "run_child" and "_run_child_locked" in r["text"]:
        allowed_refs.append(r)
    else:
        bad_refs.append(r)
cap["classification"] = {"inside_the_RL-1_installation_or_its_read-back_or_the_frozen_definition": allowed_refs, "other": bad_refs}
defs = cap.get("definitions", [])
cap["RKR-2 (b) exactly one definition each, first lines 149 / 177"] = sorted((d["name"], d["first_line"], d["file"]) for d in defs) == sorted(
    [("_run_child_locked", 177, rel(os.path.join(V2, "v2_solver.py"))), ("run_child", 149, rel(os.path.join(V2, "v2_solver.py")))])
REP["RK-4 (d) capture scan (RLR-2 search) on the entries' closure"] = cap
if bad_refs or cap["from_v2_solver_import"] or cap["module_level_launches"] or cap["other_modules_defining_v2_solver"] or cap["sys_modules_v2_solver_assignments"] \
        or not cap["RKR-2 (b) exactly one definition each, first lines 149 / 177"]:
    STOPS.append("RK-4 (d): a capture, a module-level launch, a second v2_solver or a definition count differs")
# ------------------------------------------------------------------ (3) RJ-4 (c) / LKA-7 (a): production call sites of run_child
sites = []
for d in (V2, A1):
    for fn in sorted(os.listdir(d)):
        if not fn.endswith(".py"):
            continue
        f = os.path.join(d, fn)
        tree = parse(f)
        for n in ast.walk(tree):
            if isinstance(n, ast.Call):
                c, base = callee(n)
                if c == "run_child" and (base in ("V", "v2_solver") or base is None):
                    sites.append({"file": rel(f), "line": n.lineno, "function": enclosing(tree, n.lineno), "through": ("%s.run_child" % base) if base else "module global run_child",
                                  "in_the_entries_production_closure": os.path.abspath(f) in {os.path.abspath(x) for x in repo_files}})
prod = sorted((os.path.basename(s["file"]), s["line"]) for s in sites if s["in_the_entries_production_closure"])
SIX = sorted([("v2_driver.py", 101), ("v2_driver.py", 166), ("v2_driver.py", 650), ("v2_solver.py", 517), ("a1_health.py", 147), ("a1_pari.py", 96)])
REP["RJ-4 (c) / LKA-7 (a) run_child call sites (ast)"] = {"all_calls_found_in_the_frozen_trees": sites, "production_sites": prod, "expected_six": SIX,
                                                          "equal": prod == SIX}
if prod != SIX:
    STOPS.append("RJ-4 (c): the production call sites of run_child are not exactly the six")
# ------------------------------------------------------------------ (4) LKA-7 (b), (c): every LOAD of the frozen function object in the r4 tree
loads, calls_r4, orig_uses = [], [], []
for fn in sorted(os.listdir(LAYER)):
    if not fn.endswith(".py"):
        continue
    f = os.path.join(LAYER, fn)
    tree = parse(f)
    lines = open(f).read().splitlines()
    call_funcs = {id(n.func) for n in ast.walk(tree) if isinstance(n, ast.Call)}
    for n in ast.walk(tree):
        form = None
        if isinstance(n, ast.Attribute) and n.attr == "run_child" and isinstance(n.ctx, ast.Load):
            form = "attribute load %s.run_child" % ast.unparse(n.value)
        elif isinstance(n, ast.Name) and n.id == "run_child" and isinstance(n.ctx, ast.Load):
            form = "global-name load run_child"
        elif isinstance(n, ast.ImportFrom) and any(a.name == "run_child" for a in n.names):
            form = "from-import run_child"
        elif isinstance(n, ast.Call) and callee(n)[0] in ("getattr", "attrgetter") and any(isinstance(a, ast.Constant) and a.value == "run_child" for a in n.args):
            form = "%s(..., 'run_child')" % callee(n)[0]
        elif isinstance(n, (ast.FunctionDef, ast.Lambda)):
            for dflt in list(n.args.defaults) + [x for x in n.args.kw_defaults if x is not None]:
                if any((isinstance(m, ast.Attribute) and m.attr == "run_child") or (isinstance(m, ast.Name) and m.id == "run_child") for m in ast.walk(dflt)):
                    form = "default argument naming run_child"
        if form:
            loads.append({"file": rel(f), "line": n.lineno, "function": enclosing(tree, n.lineno), "form": form, "text": lines[n.lineno - 1].strip()[:160],
                          "is_the_callee_of_a_call": id(n) in call_funcs})
        if isinstance(n, ast.Call) and callee(n)[0] == "run_child":
            calls_r4.append({"file": rel(f), "line": n.lineno, "function": enclosing(tree, n.lineno)})
        if isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Constant) and n.slice.value == "original" and isinstance(n.value, ast.Name) and n.value.id == "_ST":
            orig_uses.append({"file": rel(f), "line": n.lineno, "function": enclosing(tree, n.lineno), "ctx": type(n.ctx).__name__, "text": lines[n.lineno - 1].strip()[:160]})
rec_file = rel(os.path.join(LAYER, "r4_recorder.py"))
loads_ok = all(l["file"] == rec_file and l["function"] in ("install", "readback") and not l["is_the_callee_of_a_call"] for l in loads)
rtree = parse(os.path.join(LAYER, "r4_recorder.py"))
orig_calls = []
for q, fnode in funcs(rtree):
    for n in ast.walk(fnode):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("original", "orig"):
            orig_calls.append({"function": q, "line": n.lineno, "callee_name": n.func.id})
orig_ok = (all(u["function"] in ("install", "readback", "launch_recorder") for u in orig_uses)
           and all(c["function"] == "launch_recorder" and c["callee_name"] == "original" for c in orig_calls) and bool(orig_calls))
REP["LKA-7 (b), (c) loads of the frozen run_child in the delivered r4 tree"] = {
    "method": "ast over every .py of implementation-v2-r4/: attribute loads *.run_child, global-name loads run_child, from-imports, getattr / attrgetter "
              "with 'run_child', default arguments naming run_child; plus every call of run_child and every use of the captured reference _ST['original']",
    "loads": loads, "calls_of_run_child_in_the_r4_tree": calls_r4, "captured_reference_uses": orig_uses, "calls_of_the_captured_reference": orig_calls,
    "every_load_is_in_the_RL-1_installation_or_its_RL-5_read-back": loads_ok,
    "captured_reference_stored_only_in_recorder_state_and_called_only_in_launch_recorder": orig_ok,
    "no_r4_function_calls_run_child": not calls_r4}
if not (loads_ok and orig_ok and not calls_r4):
    STOPS.append("LKA-7 (b): a load, store or call of the frozen run_child outside the RL-1 recorder / installation")
# ------------------------------------------------------------------ (5) RGL-2: SystemExit(97 | 98 | 99) on an unwinding path
sx = []
for f in repo_files + [os.path.join(LAYER, x) for x in os.listdir(LAYER) if x.endswith(".py")]:
    tree = parse(f)
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and (callee(n)[0] in ("SystemExit", "exit") and (callee(n)[1] in (None, "sys"))) and n.args:
            a0 = n.args[0]
            val = a0.value if isinstance(a0, ast.Constant) else ast.unparse(a0)
            sx.append({"file": rel(f), "line": n.lineno, "function": enclosing(tree, n.lineno), "form": ast.unparse(n)[:120], "arg": val})
bad_sx = [x for x in sx if x["arg"] in (97, 98, 99)]
REP["RGL-2 SystemExit(97/98/99) scan"] = {"every_SystemExit_or_sys_exit_with_an_argument": sx, "with_97_98_99": bad_sx}
if bad_sx:
    STOPS.append("RGL-2: SystemExit(97/98/99) found")
# ------------------------------------------------------------------ (6) RH-5 (a), (b): exec half and live children in the r4 closure
r4_closure = [f for f in repo_files if os.path.dirname(os.path.abspath(f)) == LAYER]
ex = []
for f in r4_closure:
    tree = parse(f)
    for q, fnode in funcs(tree):
        for n in ast.walk(fnode):
            if isinstance(n, ast.Call):
                c, base = callee(n)
                if (base == "os" and c in EXEC_FAMILY) or base in ("subprocess", "multiprocessing") or c in ("Popen",):
                    ex.append({"file": rel(f), "function": q, "line": n.lineno, "call": ast.unparse(n.func)})
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            names = [a.name for a in n.names] + ([n.module] if isinstance(n, ast.ImportFrom) and n.module else [])
            if any(x in ("subprocess", "multiprocessing") for x in names):
                ex.append({"file": rel(f), "function": "<import>", "line": n.lineno, "call": "import %s" % names})
REP["RH-5 (a), (b) process creation / exec in the r4 modules of the entries' closure"] = {
    "r4_modules_in_the_closure": [rel(f) for f in r4_closure], "findings": ex,
    "note": "any finding here is a STOP (RH-5 (a) exec half; (b) live children): the r4 code of the entries' closure creates no process and "
            "execs nothing; the only child creation on those paths is the frozen run_child (v2_solver.py 181); the RG-1 callback runs in the "
            "installing process only and does nothing in the child"}
if ex:
    STOPS.append("RH-5 (a) / (b): an r4 module of the entries' closure calls a process-creating or exec function: %s" % ex)
REP["STOPS"] = STOPS
REP["pass"] = not STOPS
json.dump(REP, open(os.path.join(OUT, "h.json"), "w"), indent=1, default=str)
print("DV-18 (h):", "PASS" if not STOPS else "STOP: %s" % STOPS)
print(json.dumps({"production_sites": prod, "loads": [(l["file"].split("/")[-1], l["line"], l["function"], l["form"]) for l in loads],
                  "orig_calls": orig_calls, "third_party": dists, "rgl2": bad_sx, "exec": ex}, indent=1, default=str))
sys.exit(0 if not STOPS else 3)
