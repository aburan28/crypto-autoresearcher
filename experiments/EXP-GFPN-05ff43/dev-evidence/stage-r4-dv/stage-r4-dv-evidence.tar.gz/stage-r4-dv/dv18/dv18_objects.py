#!/usr/bin/env python3
"""DV-18 DEVELOPMENT OBJECTS for attcount RI-3 (19)-(27) and launchkind RJ-5 (c) (28), (29) second object, (31), built
at TOY primes in the DV-7 toy environment through the DELIVERED r4 wrapper (preflight, then launch) and the DELIVERED
r4 entries (SCRATCH harness; never a package; values are toy harness values, never evidence about D).

usage: python3 -B dv18_objects.py DV18_OUT TOY_DIR OBJ      OBJ in {S1, S2, CG, O28, O29b}

STAND-INS (RJ-5 (b) read with DEC-20260924-daf670 LKA-6: only BENEATH the SE-3 / HR-3 wrappers -- the executable the
frozen run_child launches, or a process primitive as v2_solver sees it -- never at solve, run_system, run_child, the RL-1
recorder, the SE-3 / HR-3 wrappers or any r4 function), set in the entry child by an attribute-setting import hook:
  S1   v2_solver.MSOLVE -> a development msolve stand-in executable (a /bin/sh script): for the DECLARED tags it prints
       the random-linear-form line and writes a positive-dimensional output ("[1]:") on the first n attempts of the tag
       (the SSF signature, clause v), and otherwise execs the real /usr/bin/msolve with the same arguments. Toy package:
       the toy G1 (fixture --p 1033). Declared tags and n: chosen below from the DV-7 toy G1 BEFORE launch.
  S2   the same stand-in for the declared health tag of the toy controls-a1 (--p 1021) -> an HR-3 re-solve at S-2.
  CG   v2_solver.VALGRIND -> a development valgrind stand-in (/bin/sh) that writes its --callgrind-out-file and exits 3
       (a callgrind child whose outcome is not ok; RH-6 (i) (21)). Toy G1.
  O28  v2_solver.os -> a delegating proxy whose `open` raises, IN THE FORKED CHILD ONLY, for names ending
       ".callgrind.stdout" (RJ-5 (c) (28)); every parent-side os.open call through the proxy is logged (LKA-11 (c)). Toy G1.
  O29b v2_solver.os -> the same proxy for names ending ".gp.stdout", in the gp child only (LKA-5: a separate
       controls-a1-shaped development object, NOT a DV-18 (e) package). Toy controls-a1 (--p 1021).
The r4 wrapper, entries, recorder, resolve layer and checker run UNCHANGED; RB-1 records, events, site counters and
launch records are written by the delivered r4 code (LKA-6).
"""
import contextlib
import datetime
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402
import r4_dv7 as T                                       # noqa: E402  (toy environment loader only)

OUT, TOY, OBJ = sys.argv[1], sys.argv[2], sys.argv[3]
W0 = os.path.join(OUT, "objects", OBJ)
EXP = os.path.join(W0, "exp")
RUNS = os.path.join(EXP, "runs")
if os.path.exists(W0):
    raise SystemExit("REFUSING: %s exists (an object is built once)" % W0)
os.makedirs(RUNS)
os.makedirs(os.path.join(W0, "standins", "state", "count"))
os.makedirs(os.path.join(W0, "standins", "state", "policy"))
REP = {"object": OBJ, "world": W0, "started": datetime.datetime.now(datetime.timezone.utc).isoformat(), "stand_ins": []}
sys.path.insert(0, R.V2_DIR)
sys.path.insert(0, R.A1_DIR)
env = T.Toy(os.path.join(TOY, "toy")).load()
v2p, a1p = R.load_json(env["plan_v2r4"]), R.load_json(env["plan_a1r4"])
G = v2p["gate"]["blocking_packages"]
CTL = a1p["gate"]["addendum_blocking_package"]
RID = CTL if OBJ in ("S2", "O29b") else G[0]
ENTRY_KIND = "a1" if OBJ in ("S2", "O29b") else "v2"
REP["package"] = {"run_id": RID, "entry": ENTRY_KIND, "toy_plan": env["plan_v2r4"] if ENTRY_KIND == "v2" else env["plan_a1r4"],
                  "command": [p for p in (v2p["packages"] + a1p["packages"]) if p["run_id"] == RID][0]["driver_args"]}


def dump(p, o):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as fh:
        json.dump(o, fh, indent=1, default=str)


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


# ---------------------------------------------------------------- declared stand-in policies (before launch)
STATE = os.path.join(W0, "standins", "state")
MS = os.path.join(W0, "standins", "msolve_standin.sh")
VG = os.path.join(W0, "standins", "valgrind_standin.sh")
open(MS, "w").write('''#!/bin/sh
# DV-18 development stand-in for the msolve EXECUTABLE (the executable the frozen run_child launches; LKA-6).
STATE="%s"
inp=""; out=""; prev=""
for a in "$@"; do
  if [ "$prev" = "-f" ]; then inp="$a"; fi
  if [ "$prev" = "-o" ]; then out="$a"; fi
  prev="$a"
done
tag=$(basename "$inp" .ms)
n=$(cat "$STATE/policy/$tag" 2>/dev/null || echo 0)
k=$(( $(cat "$STATE/count/$tag" 2>/dev/null || echo 0) + 1 ))
echo "$k" > "$STATE/count/$tag"
if [ "$k" -le "$n" ]; then
  echo "[coefficients of linear form are randomly chosen]"
  echo "dv18 development stand-in: positive-dimensional output for $tag (invocation $k of $n forced)"
  printf '[1]:\\n' > "$out"
  exit 0
fi
exec /usr/bin/msolve "$@"
''' % STATE)
open(VG, "w").write('''#!/bin/sh
# DV-18 development stand-in for the valgrind EXECUTABLE (RH-6 (i) (21)): writes its callgrind out file, exits 3.
for a in "$@"; do
  case "$a" in --callgrind-out-file=*) f="${a#--callgrind-out-file=}"; printf 'events: Ir\\nsummary: 1\\n' > "$f";; esac
done
echo "dv18 development valgrind stand-in: exiting 3 after writing the out file"
exit 3
''')
os.chmod(MS, 0o755)
os.chmod(VG, 0o755)
policy = {}
if OBJ == "S1":
    # declared from the DV-7 toy G1 (world A): three S-1 tags solved once with outcome ok and not gb_only, alphabetical
    g1 = os.path.join(TOY, "toy", "world_A", "exp", "runs", G[0])
    d = json.load(open(os.path.join(g1, "solver-events.json")))
    cand = sorted({a["tag"] for a in d["sites"][R.SITE_S1]["attempt_records"] if (a.get("rb1") or {}).get("outcome_class") == "ok"})
    evt = {e["tag"] for e in d["sites"][R.SITE_S1]["events"]}
    cand = [t for t in cand if t not in evt and "_S3" in t]
    policy = {cand[0]: 1, cand[1]: 2, cand[2]: 5}
    REP["declared_policy_rule"] = ("the first three tags, alphabetically, among the DV-7 toy G1's S-1 tags containing '_S3' whose recorded "
                                   "attempt was ok and that had no SSF event: SSF forced on the first 1, 2 and 5 invocations -> N = 2, 3, 6")
elif OBJ == "S2":
    policy = {"health_p1021_d222": 1}
    REP["declared_policy_rule"] = "the DV-16 declared health tag health_p1021_d222: SSF forced on its first invocation -> N = 2 at S-2"
for t, n in policy.items():
    open(os.path.join(STATE, "policy", t), "w").write("%d\n" % n)
REP["declared_policy"] = policy
# ---------------------------------------------------------------- shim (attribute setting; stand-ins beneath)
mods = {"v2_common": {"EXP_DIR": EXP, "LADDER_PATH": env["ladder"], "FIXTURE_N3_JSON": env["fx3"], "FIXTURE_N4_JSON": env["fx4"]},
        "a1_common": {"EXP_DIR": EXP, "RUNS_DIR": RUNS, "LADDER_PATH": env["ladder"]}}
if OBJ in ("S1", "S2"):
    mods["v2_solver"] = {"MSOLVE": MS}
    REP["stand_ins"].append({"target": "v2_solver.MSOLVE (the msolve executable the frozen run_child launches)", "process": "the entry child (driver); the stand-in runs as the launched child",
                             "what": MS, "LKA-6_level": "the executable the frozen run_child launches"})
if OBJ == "CG":
    mods["v2_solver"] = {"VALGRIND": VG}
    REP["stand_ins"].append({"target": "v2_solver.VALGRIND (the valgrind executable the frozen run_child launches)", "process": "the launched callgrind child",
                             "what": VG, "LKA-6_level": "the executable the frozen run_child launches"})
suffix = {"O28": ".callgrind.stdout", "O29b": ".gp.stdout"}.get(OBJ)
if suffix:
    REP["stand_ins"].append({"target": "os.open as v2_solver sees it (v2_solver module global os -> delegating proxy)", "process": "the forked child only",
                             "what": "raises OSError for names ending %s" % suffix, "LKA-6_level": "a process primitive as v2_solver sees it (os.open in the child; admitted by LKA-6)"})
head = subprocess.run(["git", "-C", REPO, "rev-parse", "HEAD"], capture_output=True, text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")).stdout.strip()
r4files = sorted(os.path.relpath(os.path.join(dp, f), REPO) for dp, _d, fn in os.walk(os.path.join(REPO, R.R4_PATHS_REL[0])) for f in fn) + R.R4_PATHS_REL[1:]
rec_a = os.path.join(W0, "synthetic-4a47e5-phase-a-receipt.json")
dump(rec_a, {"synthetic": "DV-18 objects only; never a receipt", "commit_sha": head, "path_sha256": {p: sha(os.path.join(REPO, p)) for p in r4files}})
CFG = {"layer_dir": LAYER, "suffix": suffix, "parent_open_log": os.path.join(W0, "parent-os-open.jsonl"),
       "R": {"PLAN_V2_R4": env["plan_v2r4"], "PLAN_A1_R4": env["plan_a1r4"], "PLAN_V2": env["plan_v2"], "RECEIPT_R4_PHASE_A": rec_a,
             "RUNS_DIR": RUNS, "REG1_REFERENCE_RUN": G[0], "LADDER_PATH": env["ladder"]},
       "mods": mods, "entry": {"v2": os.path.join(LAYER, "r4_entry_v2.py"), "a1": os.path.join(LAYER, "r4_entry_a1.py")}}
cfgp = os.path.join(W0, "cfg.json")
dump(cfgp, CFG)
COMMON = r'''
import os, sys, json, runpy, importlib.abc, importlib.util
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R4_DV18_OBJ_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r4_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
PARENT = os.getpid()
class _OsOpenProxy(object):
    """os as v2_solver sees it: open raises IN THE FORKED CHILD ONLY for names ending CFG['suffix']; every parent-side
    os.open call is logged (LKA-11 (c)); every other attribute is the real os."""
    def __getattr__(self, name):
        return getattr(os, name)
    def open(self, path, flags, mode=0o777, *a, **k):
        if os.getpid() != PARENT and str(path).endswith(CFG["suffix"]):
            raise OSError("dv18 development stand-in: os.open fails in the child for %s" % CFG["suffix"])
        if os.getpid() == PARENT:
            with open(CFG["parent_open_log"], "a") as fh:
                fh.write(json.dumps({"path": str(path), "targets_the_stand_in_suffix": str(path).endswith(CFG["suffix"])}) + "\n")
        return os.open(path, flags, mode, *a, **k)
class Hook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"] and not (name == "v2_solver" and CFG.get("suffix")):
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"].get(_n, {}).items():
                setattr(module, k, v)
            if _n == "v2_solver" and CFG.get("suffix"):
                module.os = _OsOpenProxy()
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())
'''
ENTRY_SHIM = COMMON + r'''
entry = CFG["entry"][os.environ["R4_DV18_OBJ_ENTRY"]]
sys.argv = [entry] + sys.argv[1:]
runpy.run_path(entry, run_name="__main__")
'''
CHECK_SHIM = COMMON + r'''
import r4_check_run as K
mode, rd = sys.argv[1], sys.argv[2]
sys.exit(K.frozen_v2(rd) if mode == "frozen-v2" else K.frozen_a1(rd))
'''
entry_shim, check_shim = os.path.join(W0, "entry_obj.py"), os.path.join(W0, "check_obj.py")
open(entry_shim, "w").write(ENTRY_SHIM)
open(check_shim, "w").write(CHECK_SHIM.replace('CFG = json.load(open(os.environ["R4_DV18_OBJ_CFG"]))',
                                               'CFG = json.load(open(os.environ["R4_DV18_OBJ_CFG"]))\nCFG["suffix"] = None   # the checker process: no stand-in'))
os.environ["R4_DV18_OBJ_CFG"] = cfgp
os.environ["R4_DV18_OBJ_ENTRY"] = ENTRY_KIND
os.environ["GFPN_V2_CACHE_DIR"] = os.path.join(W0, "cache")          # toy objects: a fresh scratch cache (uncached builds)
import r4_run_wrapper as W                               # noqa: E402
import r4_check_run as K                                 # noqa: E402
real_git = W.git_tree_state
W.git_tree_state = lambda paths: (r4files, []) if paths == R.R4_PATHS_REL else real_git(paths)
W.ENTRY_V2 = W.ENTRY_A1 = entry_shim
K.FROZEN_LAUNCHER = [sys.executable, "-B", check_shim]
W.RUNS = RUNS
for k, v in CFG["R"].items():
    setattr(R, k, v)
EXPECTED = (r"^R-7 repaired gate package RUN-GFPN-[0-9a-f]{6} has not run$",
            r"^R-7 REG-1 did not pass \(NOT_EVALUABLE\): G1 RUN-GFPN-[0-9a-f]{6} has not run$",
            r"^R-8 required earlier package RUN-GFPN-[0-9a-f]{6} \(.*\) has no manifest$",
            r"^R-8 \(RL-4\) read package RUN-GFPN-[0-9a-f]{6} \(.*\) has no manifest$",
            r"^R-7 controls_a1 image RUN-GFPN-[0-9a-f]{6} has not run$")
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    refusals, info = W.preflight(RID)
exp = [r for r in refusals if any(re.match(p, r) for p in EXPECTED)]
unexp = [r for r in refusals if r not in exp]
REP["preflight"] = {"refusals_verbatim": refusals, "expected": exp, "unexpected": unexp}
if unexp:
    REP["STOP_or_harness"] = "an unexpected preflight refusal: %s" % unexp
    dump(os.path.join(OUT, "objects", "object-%s.json" % OBJ), REP)
    raise SystemExit(3)
t0 = time.time()
with contextlib.redirect_stdout(buf):
    rc = W.launch(RID, None, info)
REP["launch"] = {"rc": rc, "wall_seconds_harness": round(time.time() - t0, 1), "wrapper_stdout": buf.getvalue().splitlines()[-5:]}
rd = os.path.join(RUNS, RID)
REP["run_dir"] = rd
REP["stand_in_invocation_counts"] = {t: open(os.path.join(STATE, "count", t)).read().strip() for t in sorted(os.listdir(os.path.join(STATE, "count")))}
if suffix:
    lines = [json.loads(l) for l in open(CFG["parent_open_log"])] if os.path.exists(CFG["parent_open_log"]) else []
    REP["LKA-11 (c)"] = {"parent_os_open_calls_through_the_proxy": len(lines),
                         "parent_os_open_calls_naming_the_stand_in_suffix": [l for l in lines if l["targets_the_stand_in_suffix"]],
                         "parent_reads_unchanged": "the proxy passes every parent-side call to the real os unchanged (it acts only when os.getpid() differs from the installing driver's pid); the parent's reads of the child's files (open(), os.path.exists, os.read on pipes) are therefore as without the stand-in (behaviour B-4)"}
dump(os.path.join(OUT, "objects", "object-%s.json" % OBJ), REP)
print("object %s: %s" % (OBJ, buf.getvalue().strip().splitlines()[-1] if buf.getvalue().strip() else rc))
