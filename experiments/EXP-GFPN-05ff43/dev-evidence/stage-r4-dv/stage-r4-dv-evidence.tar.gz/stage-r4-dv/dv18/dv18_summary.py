#!/usr/bin/env python3
"""DV-18 SUMMARY (SCRATCH; read-only): collects every DV-18 output into dv18-summary.json, item by item, in run order,
with the STOP evaluation. usage: python3 -B dv18_summary.py DV18_OUT"""
import json
import os
import sys

OUT = sys.argv[1]


def j(*p):
    q = os.path.join(OUT, *p)
    return json.load(open(q)) if os.path.exists(q) else None


first, rest = j("f", "run-first.json"), j("f", "run-rest.json")
S = {"order": ["(f) (xiv), (xv) FIRST", "(f) (i)-(xiii), (xvi)-(xxi)", "(a) controls", "(b) anchor-identity (attempt 2)", "(e) controls-a1", "(h)",
               "(d) (attempt 3)", "objects", "(19)-(32) in place", "(i) (1)-(15), (23) copies", "(i) (16)-(18)", "(g)"]}
S["(f) first"] = {k: {"pass": v["pass"], "checks": v["checks"], "argv": v["argv"]} for k, v in first["items"].items()}
S["(f) rest"] = {k: {"pass": v["pass"], "checks": v["checks"], "stand_ins": v["stand_ins"]} for k, v in rest["items"].items()}
S["(f) (ix) note"] = ("RK-4 (c) (ix) states child_created true, the pair 'absent' and child_rlimit_report ''; all three hold. The harness's two "
                      "additional checks (class (C); child_end frozen_pre_exec_exit) did not hold: child_end 'undetermined' because the RG-1 counter "
                      "open returned ESRCH (the child had exited at its failed stdout open before the after-fork callback ran). Recorded; not re-run.")
for it in ("a", "b", "e"):
    ev = j("eval-%s.json" % it)
    pk = j("package-%s.json" % it)
    S["(%s)" % it] = {"label": pk["label"], "preflight_attempts": pk["preflight_attempts"], "launch": pk["launch"],
                      "RG-3 (a) input copies": pk["RG-3 (a) development input copies (sha256 side by side)"],
                      "RF-4 (a) (1)": pk["RF-4 (a) (1) replacements (original, development)"], "RF-4 (a) (2)": pk["RF-4 (a) (2) replacements (original, development)"],
                      "RF-4 (a) (3)": pk["RF-4 (a) (3) replacements"], "development_plan_copies": pk["development_plan_copies"],
                      "GFPN_V2_CAP_BYTES_in_wrapper_environment": pk["GFPN_V2_CAP_BYTES_in_wrapper_environment"],
                      "RG-3 (d)": ev["RG-3 (d) expected checker items"], "(c)": ev["RB-5 (c) / RL-6 (e) requirements"], "(c')": ev["RL-6 (c')"],
                      "counts": ev["counts"], "r4_checker": {k: ev["r4_checker"][k] for k in ("exit", "verdict", "stop_classes", "frozen_checker_exit", "r4_items")},
                      "LKA-4 rows": ev["LKA-4 value table"]["n_rows"], "LKA-4 absent listed fields": ev["LKA-4 value table"]["listed_fields_absent_recorded_absent_not_a_STOP (LKA-4 (c))"],
                      "STOPS": ev["STOPS"], "pass": ev["pass"]}
S["(d)"] = j("d", "d.json")
S["(h)"] = {k: v for k, v in (j("h", "h.json") or {}).items()}
S["(g)"] = j("g", "g.json")
S["objects"] = {o: j("objects", "object-%s.json" % o) for o in ("S1", "S2", "CG", "O28", "O29b")}
alt = j("alter-results.json")
S["in_place"] = {"positive_control_32": alt["positive_control_32"], "items": [{k: v for k, v in r.items() if k not in ("run_dir",)} for r in alt["items"]],
                 "attribution": {k: alt[k] for k in alt if k.startswith("(")}, "S1_declared_tags": alt["S1_declared_tags"], "STOPS": alt["STOPS"], "pass": alt["pass"]}
S["(i) copies"] = j("copies-results.json")
S["(i) (16)-(18)"] = j("i16_18.json")
stops = []
if not all(v["pass"] for v in first["items"].values()):
    stops.append("(f) (xiv) / (xv)")
for k, v in rest["items"].items():
    if not v["pass"] and k != "ix":
        stops.append("(f) (%s)" % k)
for it in ("a", "b", "e"):
    if not S["(%s)" % it]["pass"]:
        stops.append("(%s)" % it)
if not S["(h)"].get("pass"):
    stops.append("(h)")
if not S["(g)"]["pass"]:
    stops.append("(g)")
if not alt["pass"]:
    stops.append("in-place items")
if not S["(i) copies"]["pass"] or not S["(i) (16)-(18)"]["pass"]:
    stops.append("(i)")
if not S["(d)"]["pass_under_the_literal_reading"]:
    stops.append("RB-5 (d) AS LITERALLY WORDED: 'with the original, it admits' is not met (the three REG-1 items fail on every development "
                 "package, so RB-4 (b) refuses with the original copy too); met under the RF-4 (c) / RG-3 (d) development reading")
S["STOP_conditions"] = stops
json.dump(S, open(os.path.join(OUT, "dv18-summary.json"), "w"), indent=1, default=str)
print(json.dumps({"STOP_conditions": stops}, indent=1))
