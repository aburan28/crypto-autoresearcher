#!/usr/bin/env python3
"""Scratch runner for DV-18 (f) items (EXP-GFPN-05ff43 r4 stage). Runs each named item of dv18_item.py in its OWN
process, sequentially, recording the exact argv, exit status, stdout / stderr and the item's result.json. Before the
first item it checks and records that GFPN_V2_CAP_BYTES is unset (LKA-11 (d)) and that no other solver-like process
runs (v2_solver.other_solver_processes).

usage: python3 -B dv18_run_items.py OUT LABEL ITEM [ITEM ...]
"""
import datetime
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
REPO = "/home/user/crypto-autoresearcher"
sys.path.insert(0, os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4"))
import r4_common as R                                    # noqa: E402
sys.path.insert(0, R.V2_DIR)
import v2_solver as V                                    # noqa: E402  (other_solver_processes only)

out, label, items = sys.argv[1], sys.argv[2], sys.argv[3:]
os.makedirs(out, exist_ok=True)
rep = {"label": label, "started": datetime.datetime.now(datetime.timezone.utc).isoformat(),
       "GFPN_V2_CAP_BYTES_in_environment": "GFPN_V2_CAP_BYTES" in os.environ, "other_solver_processes_before": V.other_solver_processes(),
       "items": {}}
if rep["GFPN_V2_CAP_BYTES_in_environment"]:
    rep["STOP"] = "LKA-11 (d): GFPN_V2_CAP_BYTES is set"
    json.dump(rep, open(os.path.join(out, "run-%s.json" % label), "w"), indent=1)
    print("STOP: GFPN_V2_CAP_BYTES is set")
    sys.exit(3)
for it in items:
    argv = [sys.executable, "-B", os.path.join(HERE, "dv18_item.py"), it, out]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    t0 = datetime.datetime.now(datetime.timezone.utc)
    pr = subprocess.run(argv, capture_output=True, text=True, env=env, timeout=900)
    t1 = datetime.datetime.now(datetime.timezone.utc)
    rp = os.path.join(out, it, "result.json")
    res = json.load(open(rp)) if os.path.exists(rp) else None
    rep["items"][it] = {"argv": argv, "rc": pr.returncode, "stdout": pr.stdout.splitlines()[-20:], "stderr": pr.stderr.splitlines()[-30:],
                        "started": t0.isoformat(), "finished": t1.isoformat(), "pass": bool(res and res.get("pass")),
                        "checks": res and res.get("checks"), "stand_ins": res and res.get("stand_ins")}
    print("%-8s rc=%s %s %s" % (it, pr.returncode, "PASS" if rep["items"][it]["pass"] else "FAIL", pr.stdout.strip().splitlines()[-1:] if pr.stdout.strip() else pr.stderr.strip().splitlines()[-3:]))
    sys.stdout.flush()
rep["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
rep["all_pass"] = all(v["pass"] for v in rep["items"].values())
json.dump(rep, open(os.path.join(out, "run-%s.json" % label), "w"), indent=1)
print("%s: %s" % (label, "ALL PASS" if rep["all_pass"] else "FAILURES: %s" % sorted(k for k, v in rep["items"].items() if not v["pass"])))
sys.exit(0 if rep["all_pass"] else 1)
