#!/usr/bin/env python3
"""DV-18 (d) (readbackcover RB-5 (d)): RB-4 exercised on COPIES of the DV-18 (a) world. Two copies of the (a) world's
runs directory: (1) unchanged; (2) the copy of the (a) package with its manifest read-back list
(resources.child_rlimit_as_read_back_by_getrlimit) emptied. In each, the delivered wrapper's preflight is run for a
LATER package that requires the repaired gate (the F-4 package of the development plan copy, in which the (a)
package is the G4 image under its development label). Recorded: every refusal verbatim; the RB-4 (b) refusal naming
the (a) package, with the r4 checker's exit status, verdict and stop classes. SCRATCH harness.

READING RECORDED (not a rule change): in the development world REG-1 is NOT_EVALUABLE (G1 absent; RF-4 (b)), so the
three REG-1 checker items fail on EVERY development package (RG-3 (d)) and the r4 checker's verdict on the (a) package is
FAIL with or without the edit. RB-5 (d)'s "with the original, it admits" is therefore evaluated as RF-4 (c) / RG-3 (d)
word the development reading of "the r4 checks pass": with the original copy, the RB-4 (b) finding on the (a) package
carries NO item other than those three and the frozen checker exits 0; with the emptied copy, the frozen checker exits
1 on its item "no child RLIMIT_AS read-back recorded" and the RB-4 (b) refusal carries it. Both outcomes are reported
verbatim for the Coordinator.

usage: python3 -B dv18_d.py DV18_OUT
"""
import contextlib
import io
import json
import os
import shutil
import sys

sys.dont_write_bytecode = True
REPO = "/home/user/crypto-autoresearcher"
LAYER = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43", "implementation-v2-r4")
sys.path.insert(0, LAYER)
import r4_common as R                                    # noqa: E402
import yaml                                              # noqa: E402

OUT = sys.argv[1]
PK = json.load(open(os.path.join(OUT, "package-a.json")))
W0, LABEL = PK["scratch_root"], PK["label"]
CFGP = os.path.join(W0, "shims", "cfg.json")
CFG = json.load(open(CFGP))
for k, v in CFG["R"].items():
    setattr(R, k, v)
os.environ["R4_DV18_CFG"] = CFGP
sys.path.insert(0, R.V2_DIR)
sys.path.insert(0, R.A1_DIR)
import r4_run_wrapper as W                               # noqa: E402
import r4_check_run as K                                 # noqa: E402
K.FROZEN_LAUNCHER = [sys.executable, "-B", os.path.join(W0, "shims", "check_dv18.py")]
r4files = sorted(os.path.relpath(os.path.join(dp, f), REPO) for dp, _d, fn in os.walk(os.path.join(REPO, R.R4_PATHS_REL[0])) for f in fn) + R.R4_PATHS_REL[1:]
real_git = W.git_tree_state
W.git_tree_state = lambda paths: (r4files, []) if paths == R.R4_PATHS_REL else real_git(paths)
D = os.path.join(OUT, "d")
if os.path.exists(D):
    raise SystemExit("REFUSING: %s exists" % D)
os.makedirs(D)
PLAN_RID = PK["development_plan_copies"]["package_under_test"]["plan_run_id"]
dplans = {}
for key, attr in (("v2", "PLAN_V2_R4"), ("a1", "PLAN_A1_R4")):
    pl = R.load_json(getattr(R, attr))
    changed = []
    for gk in ("blocking_packages", "v2_blocking_packages"):
        lst = (pl.get("gate") or {}).get(gk)
        if isinstance(lst, list) and PLAN_RID in lst:
            pl["gate"][gk] = [LABEL if x == PLAN_RID else x for x in lst]
            changed.append("/gate/%s" % gk)
    for i, pk_ in enumerate(pl["packages"]):
        if PLAN_RID in (pk_.get("requires") or []):
            pk_["requires"] = [LABEL if x == PLAN_RID else x for x in pk_["requires"]]
            changed.append("/packages/%d/requires" % i)
    dp = os.path.join(D, "trial-plan-%s-r4.dev-d.json" % key)
    json.dump(pl, open(dp, "w"), indent=1)
    dplans[key] = {"path": dp, "paths_where_the_G4_plan_run_id_was_replaced_by_the_label": changed}
    setattr(R, attr, dp)
dplan = R.load_json(R.PLAN_V2_R4)
F4 = [p for p in dplan["packages"] if p["kind"] == "fixture4"][0]["run_id"]
rep = {"development_label_of_the_(a)_package": LABEL, "later_package": F4, "copies": {},
       "d_specific_plan_copies": dplans, "gate_blocking_packages_in_the_d_copy": dplan["gate"]["blocking_packages"]}
for name in ("original", "readback_list_emptied"):
    runs = os.path.join(D, "world_a_copy_%s" % name, "runs")
    os.makedirs(os.path.dirname(runs))
    CFG2 = json.load(open(CFGP))
    CFG2["R"].update(PLAN_V2_R4=R.PLAN_V2_R4, PLAN_A1_R4=R.PLAN_A1_R4, RUNS_DIR=runs)
    cfg2 = os.path.join(os.path.dirname(runs), "cfg-d.json")
    json.dump(CFG2, open(cfg2, "w"), indent=1)
    os.environ["R4_DV18_CFG"] = cfg2
    shutil.copytree(CFG["R"]["RUNS_DIR"], runs)
    rd = os.path.join(runs, LABEL)
    if name == "readback_list_emptied":
        mp = os.path.join(rd, "manifest.yaml")
        man = yaml.safe_load(open(mp))
        before = man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"]
        man["run"]["resources"]["child_rlimit_as_read_back_by_getrlimit"] = []
        with open(mp, "w") as fh:
            yaml.safe_dump(man, fh, sort_keys=False, width=110)
        rep["copies"][name] = {"edit": "resources.child_rlimit_as_read_back_by_getrlimit emptied (was %d entries)" % len(before)}
    else:
        rep["copies"][name] = {"edit": None}
    W.RUNS = runs
    R.RUNS_DIR = runs
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        refusals, info = W.preflight(F4)
    rb4 = [r for r in refusals if r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package %s" % LABEL)]
    ra = [r for r in refusals if r.startswith("R-7 repaired gate package %s" % LABEL)]
    gpc = info.get("gate_package_checker", {}).get(LABEL) or {}
    rep["copies"][name].update({"refusals_verbatim": refusals, "RB-4 (a) refusals naming the (a) package": ra, "RB-4 (b) refusals naming the (a) package": rb4,
                                "r4_checker_on_the_(a)_package": {k: gpc.get(k) for k in ("exit_status", "verdict", "stop_classes", "frozen_checker_exit")},
                                "r4_checker_output": (gpc.get("output") or "").splitlines()})
EXPECTED3 = ["gate.regression_REG-1 not recorded PASS: NOT_EVALUABLE", "gate.regression_REG-1 d_branch None != d-parsed",
             "gate.regression_REG-1 exclusion-list sha256 differs from the plan's"]
o, e = rep["copies"]["original"], rep["copies"]["readback_list_emptied"]
oc, ec = o["r4_checker_on_the_(a)_package"], e["r4_checker_on_the_(a)_package"]
rep["evaluation"] = {
    "original: RB-4 (a) passes (no 'has not run' / 'did not pass' refusal naming the (a) package)": not o["RB-4 (a) refusals naming the (a) package"],
    "original: frozen checker exit 0 and the only r4 items are the three REG-1 items (the development reading: 'admits')":
        oc.get("frozen_checker_exit") == 0 and oc.get("stop_classes") == ["another checker item: %s" % EXPECTED3],
    "emptied: the wrapper refuses the later package on RB-4 (b) naming the (a) package": bool(e["RB-4 (b) refusals naming the (a) package"]),
    "emptied: the frozen checker exits 1 with its item 'no child RLIMIT_AS read-back recorded'":
        ec.get("frozen_checker_exit") == 1 and any("no child RLIMIT_AS read-back recorded" in s for s in (ec.get("stop_classes") or [])),
    "literal reading ('with the original, it admits', i.e. no RB-4 (b) refusal at all naming the (a) package)": not o["RB-4 (b) refusals naming the (a) package"]}
rep["pass_under_the_development_reading"] = all(v for k, v in rep["evaluation"].items() if not k.startswith("literal"))
rep["pass_under_the_literal_reading"] = rep["pass_under_the_development_reading"] and rep["evaluation"]["literal reading ('with the original, it admits', i.e. no RB-4 (b) refusal at all naming the (a) package)"]
json.dump(rep, open(os.path.join(D, "d.json"), "w"), indent=1, default=str)
print(json.dumps(rep["evaluation"], indent=1))
print("DV-18 (d): development reading %s; literal reading %s" % ("PASS" if rep["pass_under_the_development_reading"] else "FAIL",
                                                                 "PASS" if rep["pass_under_the_literal_reading"] else "NOT MET"))
