# EXP-GFPN-05ff43 — implementation note, protocols 2-r4 and 2-a1-r4 (r4 stage, TASK-20260924-d91a96)

Stage note of the r4 stage (maximum_runs 0; no run package). Scratch outputs live in the session scratchpad, referred to
only as `<scratchpad>`. Section 0 is the running progress log; the two RC-4 sections follow it; the remaining sections
are completed at the end of the stage.

## 0. Progress log (UTC)

- 03:52:17Z stage start. Before any write, the SEVENTEEN amendment files were hashed with
  `sha256sum -c <scratchpad>/r4/lka1-expected.sha256`, where the expected file was cut from
  `ledger/decisions/DEC-20260924-daf670.yaml` lines 1052-1068 (`bound_hashes`). All 17 print `OK` (0 mismatches).
- 03:52Z GFPN_V2_CAP_BYTES check (R4S-13; LKA-11 (d)), in the environment this stage was launched in:
  - `env | grep -c GFPN_V2_CAP_BYTES` printed `0`;
  - `printenv GFPN_V2_CAP_BYTES` printed nothing and exited `1`.
  The variable is UNSET. Every child environment this stage builds is derived from this environment and never adds it.
- 03:52Z HEAD 1768588f0d7f94020f235e2141d7a843f45b150f; `GIT_OPTIONAL_LOCKS=0 git status --porcelain` empty.
- 04:00:48Z DV-9 baseline taken before any repository write (`<scratchpad>/r4/dv9/baseline.json`): 1294 files hashed
  under the frozen roots; the other 48 run packages recorded by listing and lstat metadata only (2110 files, never read,
  R4S-12); 5 pre-existing byte-code files; `runs/` 55 entries (54 run directories + `.gitkeep`); git status empty.
- 04:01:03Z-04:02:01Z 42 run ids minted with `python3 -B tools/allocate_id.py --next run --area GFPN` and each BARE id
  checked with `--check` (rc 0 and 0 occurrences for all 42; 42 distinct) before any file named it
  (`<scratchpad>/r4/ids/`).
- 04:04:39Z first repository write: `implementation-v2-r4/` created (the exclusion list copied byte for byte from
  `implementation-v2-r3/`, and `minted-run-ids.txt`).
- 04:23:47Z the union map M computed from the delivered writer's inputs; this note opened with the RC-4 (b) and RC-4 (a)
  records below. Neither r4 plan exists at this time.

## RC-4 (b): declared metadata key paths (JSON pointer), recorded before either plan was written

(Written at 04:24Z. At this time neither `trial-plan-v2-r4.json` nor `trial-plan-v2-a1-r4.json` exists. This satisfies
DEC-20260923-80e280 RC-4 (b), re-pointed to r4 by DEC-20260924-daf670 LKA-3 and card R4S-5.)

`trial-plan-v2-r4.json` (12 paths):

| path | added / changed | PS-3 category |
| --- | --- | --- |
| `/protocol_version` | changed (2 → "2-r4") | protocol label |
| `/task_id` | changed (→ TASK-20260924-b85e59) | task ids |
| `/written_by_task` | added (TASK-20260924-d91a96) | task ids |
| `/archived_by` | changed (→ "TASK-20260924-4a47e5 phase A (Coordinator)") | archived_by |
| `/repair` | added (the LKA-1 content) | the `repair` block |
| `/gate/regression` | added (REG-1, d-parsed, with the exclusion list's sha256) | gate.regression |
| `/gate/admission` | added (the gate admission as RB-4 words it, with RL-4 / RK-3 / RF-3 / RF-5) | gate admission |
| `/id_map` | added (31 entries, v2 → r4) | id map |
| `/v2_ids_never_reused` | added (the 31 frozen v2 ids) | never-reused lists |
| `/a1_ids_never_reused` | added (the 11 frozen v2-a1 ids) | never-reused lists |
| `/retired_ids` | added (ids kept as records; the 162 retired ids: 29 v2, 11 v2-a1, 42 r1, 42 r2, 38 r3) | retired id lists |
| `/ceiling_note` | added (6 existing + 31 + 11 = 48 of 48, over ten plans) | ceiling note |

`trial-plan-v2-a1-r4.json` (13 paths):

| path | added / changed | PS-3 category |
| --- | --- | --- |
| `/protocol_version` | changed ("2-a1" → "2-a1-r4") | protocol label |
| `/task_id` | changed (→ TASK-20260924-46a554) | task ids |
| `/written_by_task` | changed (→ TASK-20260924-d91a96) | task ids |
| `/archived_by` | changed (→ "TASK-20260924-4a47e5 phase A (Coordinator)") | archived_by |
| `/repair` | added (the LKA-1 content, with the a1 gate re-pointing and the phase-B receipt re-pointed to TASK-20260924-4a47e5, VC-6 (c)) | the `repair` block |
| `/gate/regression` | added (REG-1, d-parsed) | gate.regression |
| `/gate/admission` | added (as in the v2-r4 plan) | gate admission |
| `/id_map` | added (11 entries, v2-a1 → r4) | id maps |
| `/id_map_v2` | added (31 entries, v2 → r4) | id maps |
| `/frozen_v2_ids_never_reused` | added (the 31 frozen v2 ids; RC-4 (d)) | never-reused lists |
| `/a1_ids_never_reused` | added (the 11 frozen v2-a1 ids; RC-4 (d)) | never-reused lists |
| `/retired_ids` | added (as in the v2-r4 plan) | retired id lists |
| `/ceiling_note` | added | ceiling note |

In `trial-plan-v2-a1-r4.json` the pre-existing `/v2_ids_never_reused` is NOT a declared key: it is mapped like every
other field, so its image lists the 31 r4 v2 ids (RC-4 (d)). `/gate/v2_blocking_packages`,
`/gate/addendum_blocking_package` and aggregate_a1's `driver_args` are not declared keys; they are mapped through M.
The derivation source is the FROZEN plans (trial-plan-v2.json sha256 16f33e39...4e16; trial-plan-v2-a1.json sha256
2a788720...5ac6), never the r1, r2 or r3 plans (R4S-5).

## RC-4 (a): the union map M (42 entries), recorded before either plan was written

Assignment rule (as the earlier stages): ids are taken in minting order (`implementation-v2-r4/minted-run-ids.txt`;
section 16 has the allocator outputs). The first 31 go to the packages of `trial-plan-v2.json` in plan order; the next
11 to the packages of `trial-plan-v2-a1.json` in plan order. The writer's `inputs()` checked every image against the
frozen, r1, r2 and r3 plans, the v1 ids and the 162 retired ids: 0 collisions; M is a bijection.

id_map_v2 (31):

| order | frozen v2 id | r4 id | label |
| --- | --- | --- | --- |
| 1 | RUN-GFPN-ac4487 | RUN-GFPN-3e27a0 | F-1..F-3 fixture, n = m = 3, p' = 4111 (G1) |
| 2 | RUN-GFPN-3377f1 | RUN-GFPN-878af1 | F-1..F-3 fixture, n = m = 3, p' = 16777291 (G2) |
| 3 | RUN-GFPN-76420e | RUN-GFPN-315a64 | jv_anchor_system_trace_identity, p' = 16777291, n = 5, m = 4 (G3) |
| 4 | RUN-GFPN-b231c1 | RUN-GFPN-d1a204 | frozen controls (G4) |
| 5 | RUN-GFPN-a07776 | RUN-GFPN-f87282 | F-4 secondary fixture, n = m = 4 (NOT blocking) |
| 6 | RUN-GFPN-1ad09b | RUN-GFPN-e761f2 | build p' = 4111 |
| 7 | RUN-GFPN-0c7483 | RUN-GFPN-3c4bc4 | cells 4111 ecgfp5_shaped m = 5 |
| 8 | RUN-GFPN-4abae0 | RUN-GFPN-cf4442 | cells 4111 random_2torsion m = 5 |
| 9 | RUN-GFPN-9e4212 | RUN-GFPN-4689f8 | cells 4111 random_no2torsion m = 5 |
| 10 | RUN-GFPN-bbbbe3 | RUN-GFPN-5e877a | cells 4111 ecgfp5_shaped m = 4 |
| 11 | RUN-GFPN-a521dd | RUN-GFPN-89b623 | cells 4111 random_2torsion m = 4 |
| 12 | RUN-GFPN-a07b6d | RUN-GFPN-9fd0fa | cells 4111 random_no2torsion m = 4 |
| 13 | RUN-GFPN-dc1d4e | RUN-GFPN-add291 | build p' = 262151 |
| 14 | RUN-GFPN-b9207c | RUN-GFPN-50fa88 | cells 262151 ecgfp5_shaped m = 5 |
| 15 | RUN-GFPN-aa56bd | RUN-GFPN-d02ab7 | cells 262151 random_2torsion m = 5 |
| 16 | RUN-GFPN-e5b90d | RUN-GFPN-61f15b | cells 262151 random_no2torsion m = 5 |
| 17 | RUN-GFPN-d2f759 | RUN-GFPN-722d56 | cells 262151 ecgfp5_shaped m = 4 |
| 18 | RUN-GFPN-745cad | RUN-GFPN-7c0be2 | cells 262151 random_2torsion m = 4 |
| 19 | RUN-GFPN-aeff00 | RUN-GFPN-0f6e79 | cells 262151 random_no2torsion m = 4 |
| 20 | RUN-GFPN-3db273 | RUN-GFPN-15cd11 | build p' = 16777291 |
| 21 | RUN-GFPN-3be8a4 | RUN-GFPN-15c228 | cells 16777291 ecgfp5_shaped m = 5 |
| 22 | RUN-GFPN-00e64b | RUN-GFPN-eb674f | cells 16777291 random_2torsion m = 5 |
| 23 | RUN-GFPN-c5294d | RUN-GFPN-75c894 | cells 16777291 random_no2torsion m = 5 |
| 24 | RUN-GFPN-36cad2 | RUN-GFPN-191941 | cells 16777291 ecgfp5_shaped m = 4 |
| 25 | RUN-GFPN-11d2ad | RUN-GFPN-929d40 | cells 16777291 random_2torsion m = 4 |
| 26 | RUN-GFPN-fc5d58 | RUN-GFPN-ed0ea7 | cells 16777291 random_no2torsion m = 4 |
| 27 | RUN-GFPN-8f86cc | RUN-GFPN-dabc2a | aggregate (ladder table, scoring, HEUR-GFPN-DFLAT, F4, band) |
| 28 | RUN-GFPN-e26e4b | RUN-GFPN-377a64 | contingency 1 |
| 29 | RUN-GFPN-9da048 | RUN-GFPN-45fc69 | contingency 2 |
| 30 | RUN-GFPN-59320d | RUN-GFPN-b0325c | contingency 3 |
| 31 | RUN-GFPN-1596f6 | RUN-GFPN-a146f6 | contingency 4 |

id_map_a1 (11):

| order | frozen v2-a1 id | r4 id | label |
| --- | --- | --- | --- |
| 1 | RUN-GFPN-0d91bf | RUN-GFPN-5c417c | controls_a1, p' = 1073741831 (BLOCKING for the addendum) |
| 2 | RUN-GFPN-8c772a | RUN-GFPN-957eb1 | build p' = 1073741831 |
| 3 | RUN-GFPN-569fd7 | RUN-GFPN-82322f | cells 1073741831 ecgfp5_shaped m = 5 |
| 4 | RUN-GFPN-086463 | RUN-GFPN-c7b90c | cells 1073741831 random_2torsion m = 5 |
| 5 | RUN-GFPN-bab146 | RUN-GFPN-2111a4 | cells 1073741831 random_no2torsion m = 5 |
| 6 | RUN-GFPN-7dd55d | RUN-GFPN-e8e2c9 | cells 1073741831 ecgfp5_shaped m = 4 |
| 7 | RUN-GFPN-47aa51 | RUN-GFPN-adf7eb | cells 1073741831 random_2torsion m = 4 |
| 8 | RUN-GFPN-3a70f1 | RUN-GFPN-cf0210 | cells 1073741831 random_no2torsion m = 4 |
| 9 | RUN-GFPN-ae4918 | RUN-GFPN-690ecb | aggregate_a1 |
| 10 | RUN-GFPN-8cfac3 | RUN-GFPN-296a26 | contingency a1-1 |
| 11 | RUN-GFPN-6a7f35 | RUN-GFPN-9389e1 | contingency a1-2 |
