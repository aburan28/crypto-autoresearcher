#!/bin/sh
# r4 stage id minting (R4S-5): 42 x allocate, then --check each BARE id. Run from the repository root.
set -u
export PYTHONDONTWRITEBYTECODE=1
OUT="$1"
: > "$OUT/mint.log"; : > "$OUT/check.log"; : > "$OUT/ids.txt"
i=1
while [ $i -le 42 ]; do
  echo "### mint $i (command: python3 -B tools/allocate_id.py --next run --area GFPN)" >> "$OUT/mint.log"
  python3 -B tools/allocate_id.py --next run --area GFPN > "$OUT/one.txt" 2>&1
  rc=$?
  cat "$OUT/one.txt" >> "$OUT/mint.log"; echo "rc=$rc" >> "$OUT/mint.log"
  sed -n "s/^free run id for 'GFPN': \(RUN-GFPN-[0-9a-f]\{6\}\)$/\1/p" "$OUT/one.txt" >> "$OUT/ids.txt"
  i=$((i+1))
done
for id in $(cat "$OUT/ids.txt"); do
  echo "### python3 -B tools/allocate_id.py --check $id" >> "$OUT/check.log"
  python3 -B tools/allocate_id.py --check "$id" >> "$OUT/check.log" 2>&1
  echo "rc=$?" >> "$OUT/check.log"
done
rm -f "$OUT/one.txt"
