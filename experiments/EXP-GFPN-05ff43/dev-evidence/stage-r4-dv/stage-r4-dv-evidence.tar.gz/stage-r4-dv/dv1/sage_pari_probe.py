from sage.all import *
from sage.libs.pari import pari
print('R4PROBE parisize', int(pari.default('parisize')))
print('R4PROBE parisizemax', int(pari.default('parisizemax')))
print('R4PROBE stacksize', int(pari.stacksize()))
print('R4PROBE stacksizemax', int(pari.stacksizemax()))
import sage.version; print('R4PROBE sage_version', sage.version.version)
