"""Scratch editor: r4-specific edits to implementation-v2-r4/r4_dv12.py and r4_dv16.py (exact-string replacements)."""
import sys
d = sys.argv[1]


def edit(fn, pairs):
    p = d + "/" + fn
    s = open(p).read()
    for a, b in pairs:
        assert s.count(a) == 1, (fn, s.count(a), a[:90])
        s = s.replace(a, b)
    open(p, "w").write(s)
    print("edited", fn)


edit("r4_dv12.py", [
    ('''"""EXP-GFPN-05ff43 r3 successor stage -- DV-12 (seedresolve SF-6 (a)-(g), at S-1): the SE-3 re-solve path, FORCED,
in a scratch toy copy through a development shim that no delivered entry can reach. Development only. Started from
implementation-v2-r2/r2_dv12.py (cases, forcing and evaluation carried; re-pointed to the r3 layer and its
solver-events.json structure; the toy environment is DV-7's, r4_dv7.Toy).''',
     '''"""EXP-GFPN-05ff43 r4 stage (TASK-20260924-d91a96) -- DV-12 (seedresolve SF-6 (a)-(g), at S-1): the SE-3 re-solve
path, FORCED, in a scratch toy copy through a development shim that no delivered entry can reach. Development only.
Started from implementation-v2-r3/r3_dv12.py (cases, forcing and evaluation carried; re-pointed to the r4 layer; the
toy environment is DV-7's, r4_dv7.Toy). r4 changes: the wrapper is run as RK-4 (a) words the development method
(preflight, its refusals recorded; refusals naming a DECLARED SYNTHETIC toy package (G3, G4) are expected; any other
refusal fails the case and nothing is launched; then launch); the frozen checker the wrapper runs at admission and
after the package is the toy check shim; the synthetic phase-A receipt carries commit_sha = the repository HEAD.'''),
    ('''    shims = T.write_shims(os.path.join(out, "shims"), extra=forcing)
    W.ENTRY_V2 = W.ENTRY_A1 = shims["entry_toy.py"]''',
     '''    shims = T.write_shims(os.path.join(out, "shims"), extra=forcing)
    W.ENTRY_V2 = W.ENTRY_A1 = shims["entry_toy.py"]
    import r4_check_run as K
    K.FROZEN_LAUNCHER = [sys.executable, "-B", shims["check_toy.py"]]'''),
    ('''    # a synthetic TASK-20260924-4a47e5 phase-A receipt binding the r3 files as they are at THIS check's start (the layer
    # is not edited while a check runs)''',
     '''    # a synthetic TASK-20260924-4a47e5 phase-A receipt binding the r4 files as they are at THIS check's start (the layer
    # is not edited while a check runs); commit_sha: the repository HEAD'''),
    ('''    T.dump(env["receipt_a"], {"synthetic": "development only; never a receipt", "commit_sha": "dev-synthetic-not-a-commit",''',
     '''    import subprocess
    head = subprocess.run(["git", "-C", R.REPO, "rev-parse", "HEAD"], capture_output=True, text=True,
                          env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")).stdout.strip()
    T.dump(env["receipt_a"], {"synthetic": "development only; never a receipt", "commit_sha": head,'''),
    ('''    rid = rid_of(env)
    report = {"toy_env": "DV-7 toy environment (toy-env.json)", "target_tag": target_tag, "run_id": rid, "cases": {}}''',
     '''    rid = rid_of(env)
    Gt = R.load_json(env["plan_v2r4"])["gate"]["blocking_packages"]
    synth = {Gt[2], Gt[3]}                                   # the DV-7 toy's declared synthetic gate packages
    import re
    pat = re.compile(r"(?:gate package|read package) (RUN-GFPN-[0-9a-f]{6})")
    report = {"toy_env": "DV-7 toy environment (toy-env.json)", "target_tag": target_tag, "run_id": rid, "cases": {},
              "declared_synthetic_packages": sorted(synth)}'''),
    ('''        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = W.main([rid])
        t1 = datetime.datetime.now(datetime.timezone.utc)''',
     '''        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            refusals, info = W.preflight(rid)
        exp_ref = [r for r in refusals if (r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ")
                                           or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package "))
                   and pat.search(r) and pat.search(r).group(1) in synth]
        unexp_ref = [r for r in refusals if r not in exp_ref]
        rc = None
        if not unexp_ref:
            with contextlib.redirect_stdout(buf):
                rc = W.launch(rid, None, info)
        t1 = datetime.datetime.now(datetime.timezone.utc)'''),
    ('''        row = {"run_dir": rd, "wrapper_rc": rc, "wrapper_stdout": buf.getvalue().splitlines(), "started": t0.isoformat(), "finished": t1.isoformat(),''',
     '''        row = {"run_dir": rd, "wrapper_launch_rc": rc, "launched": rc is not None, "preflight_refusals_expected": exp_ref,
               "preflight_refusals_unexpected": unexp_ref, "r4_verdict": man and (man.get("verdict") or {}).get("r4_verdict"),
               "r4_stop_classes": man and (man.get("verdict") or {}).get("stop_classes"),
               "wrapper_stdout": buf.getvalue().splitlines(), "started": t0.isoformat(), "finished": t1.isoformat(),'''),
    ('''        print("  case %-2s rc=%s status=%s fclass=%s gate_pass=%s (%.0fs) %s" % (case, rc, row["status"], row["failure_class"], row["gate_pass"],
                                                                                (t1 - t0).total_seconds(), reporter["brief"](row)))''',
     '''        print("  case %-2s launched=%s status=%s fclass=%s gate_pass=%s verdict=%s unexpected-refusals=%s (%.0fs) %s" % (
            case, rc is not None, row["status"], row["failure_class"], row["gate_pass"], row["r4_verdict"], unexp_ref,
            (t1 - t0).total_seconds(), reporter["brief"](row)))'''),
])

edit("r4_dv16.py", [
    ('''"""EXP-GFPN-05ff43 r3 successor stage -- DV-16 (healthresolve HR-9, as launchcover and consumercover incorporate it;
card R3S-9): the HR-3 health re-solve path, FORCED, in a scratch toy copy through a development shim that no delivered
entry can reach. Development only. New file (the case runner is r4_dv12.run_cases; the toy environment is DV-7's).''',
     '''"""EXP-GFPN-05ff43 r4 stage (TASK-20260924-d91a96) -- DV-16 (healthresolve HR-9, as launchcover and consumercover
incorporate it; DEC-20260924-daf670 LKA-11 (a)): the HR-3 health re-solve path, FORCED, in a scratch toy copy through a
development shim that no delivered entry can reach. Development only. Started from implementation-v2-r3/r3_dv16.py (the
case runner is r4_dv12.run_cases, which runs preflight then launch; the toy's synthetic G3 / G4 make R-7's RB-4 (b)
refusals EXPECTED; the toy environment is DV-7's).'''),
    ('''TOY PRIME, declared in implementation-v2-r3.md before this check runs''', '''TOY PRIME, declared in implementation-v2-r4.md before this check runs'''),
    ('''    # DV-16 attempt 2 fix: the in-process wrapper's REG-1 reference is the toy G1 (same id in the toy and the real r3 plan);''',
     '''    # (carried from r3 DV-16 attempt 2) the in-process wrapper's REG-1 reference is the toy G1 (same id in the toy and the real r4 plan);'''),
    ('''    report["all_cases_pass"] = all(v["pass"] for v in res.values()) and len(res) == 5 and U.get("status") is not None''',
     '''    report["all_cases_pass"] = (all(v["pass"] for v in res.values()) and len(res) == 5 and U.get("status") is not None
                                and all(c.get("launched") for c in cs.values()))'''),
])
