"""Scratch editor: r4_dv6.snapshot reads the REAL runs directory by lstat metadata only (card R4S-12)."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''def snapshot(dirs):
    out = {}
    for d in dirs:
        for dp, dn, fn in os.walk(d):
            for n in dn + fn:
                out[os.path.join(dp, n)] = None if n in dn else sha(os.path.join(dp, n))
    return out'''
b = '''def snapshot(dirs):
    """Content hashes of scratch and r4-tree files; under the REAL runs directory, lstat metadata (size, mtime) only:
    the stage reads no run package outside the six the card permits (R4S-12)."""
    out = {}
    real_runs = os.path.abspath(R.RUNS_DIR) + os.sep
    for d in dirs:
        for dp, dn, fn in os.walk(d):
            for n in dn + fn:
                q = os.path.join(dp, n)
                if n in dn:
                    out[q] = None
                elif (os.path.abspath(q) + os.sep).startswith(real_runs):
                    st = os.lstat(q)
                    out[q] = ("lstat", st.st_size, st.st_mtime)
                else:
                    out[q] = sha(q)
    return out'''
assert s.count(a) == 1
open(p, "w").write(s.replace(a, b))
print("edited")
