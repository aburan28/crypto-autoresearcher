"""Scratch editor: r4-specific edits to implementation-v2-r4/r4_inventory.py (exact-string replacements)."""
import sys
p = sys.argv[1]
s = open(p).read()


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('''"""EXP-GFPN-05ff43 r3 successor stage -- the r3 CONSUMER INVENTORY of DV-11 (consumercover CC-5 as extended by
valueclose VC-3; DEC-20260924-e52eec VA-6 (d), VA-7 (b), VA-8; card LKA-8, LKA-9). Development only; called by DV-11
(r4_devchecks_more.dv11). New file.''',
    '''"""EXP-GFPN-05ff43 r4 stage (TASK-20260924-d91a96) -- the r4 CONSUMER INVENTORY of DV-11 (consumercover CC-5 as
extended by valueclose VC-3; DEC-20260924-e52eec VA-6 (d), VA-7 (b), VA-8; readbackcover RB-7; readbackfull RL-5;
readbackclose RK-5; failclosed RF-7; childend RG-8; gapattr RH-7 with attcount RI-5 (b); DEC-20260924-daf670 LKA-8,
LKA-9). Development only; called by DV-11 (r4_devchecks_more.dv11). Started from implementation-v2-r3/r3_inventory.py.''')
rep('''  1. Every function of every r3 .py file''', '''  1. Every function of every r4 .py file''')
rep('''  3. FIXPOINT over data AND control dependence (VC-3): a function that calls a listed function of the r3 layer and''',
    '''  3. FIXPOINT over data AND control dependence (VC-3): a function that calls a listed function of the r4 layer and''')
rep('''     Deterministic reading adopted (declared in implementation-v2-r3.md)''', '''     Deterministic reading adopted (declared in implementation-v2-r3.md, carried to r4)''')
rep('''     an epsilon value to choose a recorded result; no r3 file imports an r1, r2 or v1 module; no r3 file describes S-3
     as "output never classified" without the CORR-20260924-432f43 distinction.''',
    '''     an epsilon value to choose a recorded result; no r4 file imports an r1, r2, r3 or v1 module; no r4 file describes
     S-3 as "output never classified" without the CORR-20260924-432f43 distinction; r4 additions: (LKA-8) every
     function that reads an RB-1 value (an attempt or pass-through record field) at E1-E4 is one of the consumers the
     incorporating texts name (attcount RI-1 (a) (i), (ii): r4_gaps.ri1_counts; launchkind RJ-1 (b):
     r4_gaps.rj1_callgrind) or a gamma writer; (LKA-9) callgrind_result_present is written by exactly one function,
     r4_resolve._rb1_callgrind_result_present, whose body is exactly the key-membership test
     `"instructions_callgrind" in res`, called only by r4_resolve._rb1_s1, and read at E1-E4 only by
     r4_gaps.rj1_callgrind; no delivered function with effect E1-E4 names a CG-3 field, the S-3 (callgrind-site)
     section or a callgrind-site count (VA-6 (c); CC-5); the REQUIRED LISTINGS of RB-7, RL-5, RG-8, RH-7 / RI-5 (b)
     and LKA-8 / LKA-9 are each present with exactly the class those texts give.''')
rep('''  6. REPORTS: the VA-6 (d) listing and the CG-3 fields no r3 function reads at E1-E4''', '''  6. REPORTS: the VA-6 (d) listing and the CG-3 fields no r4 function reads at E1-E4''')
rep('''     files the byte sweep reads; the comparison with the archived consumer census by file and function for every r3 file
     started from an r2 file.''', '''     files the byte sweep reads; the comparison with the archived consumer census by file and function for every r4 file
     whose r3 origin started from an r2 file; the classification LABELS of RG-2 and RH-2 (no value class).''')
rep('''"the frozen checker's exit status; the r3 findings; prints the SC-4 table (E6)"''', '''"the frozen checker's exit status; the r4 findings; prints the SC-4 table (E6)"''')
rep("'module attributes; r3 constants'", "'module attributes; r4 constants'")
rep("'r3 constants and redirected values'", "'r4 constants and redirected values'")
rep("'plan text; r3 constants'", "'plan text; r4 constants'")
rep('''FORBIDDEN_IMPORT_PREFIXES = ("r1_", "r2_")''', '''FORBIDDEN_IMPORT_PREFIXES = ("r1_", "r2_", "r3_")''')
rep('''        stops.append("an r3 file imports an r1, r2 or v1 module: %s" % bad_imports)''', '''        stops.append("an r4 file imports an r1, r2, r3 or v1 module: %s" % bad_imports)''')
rep('''        stops.append("an r3 file describes S-3 as''', '''        stops.append("an r4 file describes S-3 as''')
rep('''        stops.append("an r3 consumer uses an epsilon value''', '''        stops.append("an r4 consumer uses an epsilon value''')
rep('''           "CG-3 fields no r3 function reads at E1-E4": CG3_FIELDS,''', '''           "CG-3 fields no r4 function reads at E1-E4": CG3_FIELDS,''')
rep('''           "plan text and r3 constants (VA-7 (a))"''', '''           "plan text and r4 constants (VA-7 (a))"''')
rep('''    """For every r3 file started from an r2 file: the archived census's rows for the r2 file, by function (site, effect,
    class counts), next to the r3 function's listing."""''', '''    """For every r4 file whose r3 origin started from an r2 file: the archived census's rows for the r2 file, by
    function (site, effect, class counts), next to the r4 function's listing."""''')
rep('''                        "note": None if r3row else "no r3 function of this name is listed (renamed, split or reading no site value; see the note)"})''',
    '''                        "note": None if r3row else "no r4 function of this name is listed (renamed, split or reading no site value; see the note)"})''')

# ---- the r4 classes
rep('''# listed by reading, not by the detector (control dependence the detector cannot see)''', '''E = "epsilon"
CLASSES.update({
    # r4_recorder.py -- the RL-1 launch recorder (gamma; RL-5, RK-5, RF-7, RG-8, RH-7)
    "r4_recorder.py::launch_recorder": (G, "E5", "RL-1 (a)-(d); RK-1; RF-1; RG-1", "the frozen run_child's returned record or raise; the call's arguments", "the recording pass-through; returns / re-raises unchanged"),
    "r4_recorder.py::_finish": (G, "E5", "RL-1 (c); RF-1 (b); RG-1 (b)", "the counter; the returned record / raise", "writes one launch record or the foreign file"),
    "r4_recorder.py::_record_return": (G, "E5", "RL-1 (c); RK-1 (a), (c); RG-1 (c)", "the returned record (key presence)", "recording"),
    "r4_recorder.py::_record_raise": (G, "E5", "RK-1 (b); RF-1 (a); RG-1 (c)", "the frozen rec on the traceback", "recording"),
    "r4_recorder.py::_inspect_raise": (G, "E5", "RK-1 (b); RF-1 (a)", "traceback frames of the captured frozen code objects (read-only)", "recording"),
    "r4_recorder.py::_chain": (G, "E5", "RF-1 (a)", "__context__ / __cause__ chain", "recording"),
    "r4_recorder.py::_base_record": (G, "E5", "RL-1 (c); RG-1 (b); RG-4 (a)", "the call's arguments; the observer", "recording"),
    "r4_recorder.py::_bind": (G, "E5", "RL-1 (a)", "the call's arguments against the frozen signature", "recording"),
    "r4_recorder.py::_foreign": (G, "E5", "RF-1 (b)", "pids; the raised type", "writes recorder-foreign-<pid>.json in a non-installing process"),
    "r4_recorder.py::_after_fork_in_parent": (G, "E5", "RG-1 (a); RH-4", "/proc/self/task/<tid>/children; perf_event_open", "the RG-1 callback and the RH-4 mark; records only"),
    "r4_recorder.py::_thread_children": (G, "E5", "RG-1 (a) (1)", "/proc/self/task/<tid>/children", ""),
    "r4_recorder.py::_perf_open_task_clock": (G, "E5", "RG-1 (a) (2)", "perf_event_open (software task clock)", "the counter open"),
    "r4_recorder.py::_read_counter": (G, "E5", "RG-1 (b)", "the counter's value, time enabled, time running", "the counter read"),
    "r4_recorder.py::child_end_value": (G, "E5", "RG-1 (c); RH-4", "the observer, marks, report and returncode", "writes child_end (epsilon)"),
    "r4_recorder.py::install": ("reads no site value", "E5", None, "function identities", "the RL-1 installation (the one load of the frozen run_child, LKA-7 (b))"),
    "r4_recorder.py::readback": ("reads no site value", "E2", None, "function identities; code objects; sys.modules", "RL-5 install read-back"),
    "r4_recorder.py::_identity": ("reads no site value", "E5", None, "function identities", ""),
    "r4_recorder.py::_iso": ("reads no site value", "E5", None, "a timestamp", ""),
    "r4_recorder.py::_utc": ("reads no site value", "E5", None, "clock", ""),
    # r4_resolve.py -- RB-1, RL-2 writers
    "r4_resolve.py::_rb1_s1": (G, "E5", "RB-1 (a)-(e) at S-1 (RJ-1 (a))", "the result the frozen solve RETURNED for the attempt", "recording"),
    "r4_resolve.py::_rb1_s2": (G, "E5", "RB-1 (a)-(d) at S-2", "the result the frozen run_system RETURNED for the attempt", "recording"),
    "r4_resolve.py::_rb1_pair": (G, "E5", "RB-1 (b)", "the returned result's read-back pair", "recording"),
    "r4_resolve.py::_rb1_callgrind_result_present": (G, "E5", "RB-1 (e) (launchkind RJ-1 (a); LKA-9)", "key membership of 'instructions_callgrind' in the returned result", "recording; reads no value inside it"),
    "r4_resolve.py::_passthrough_record": (G, "E5", "RL-2", "the gb_only result the frozen solve returned", "recording"),
    "r4_resolve.py::append_launch_record": (G, "E5", "RL-1 (c)", "the launch record", "the single event writer"),
    "r4_resolve.py::_recording_failure": (G, "E1", "RB-1; RL-1 (d); RL-2 (a recording failure is an SE-2 (4) violation)", "the failing write", "raises SolverEventConsistencyError"),
    "r4_resolve.py::solve.make": (G, "E5", "SE-2 (2)(a); RB-1", "via _attempt_record_s1", ""),
    # r4_gaps.py -- the RL-3 recorder-gap computation (epsilon; E2 through RF-3 (a))
    "r4_gaps.py::recorder_gaps": (E, "E2", None, "the package's files, launch records, RB-1 / RL-2 records, events, counters, raw-result 'comparator.child' presence", "RL-3 as launchkind reads it; FAIL through RF-3 (a)"),
    "r4_gaps.py::_evaluate": (E, "E2", None, "via the listed functions", "orchestrator of RL-3 (RH-1 with RI-1, RJ-1, RJ-2, RJ-3, RJ-4)"),
    "r4_gaps.py::attribute": (E, "E2", None, "launch records' stdout_path / stderr_path / argv; spec files; events' renamed_files", "RH-1 (i)-(vi) with RI-1 (d) (the RG-4 attribution)"),
    "r4_gaps.py::_spec_ok": (E, "E2", None, "child/<tag>.spec.json (written by the frozen driver before the launch)", "RH-1 (v)"),
    "r4_gaps.py::_renamed_ok": (E, "E2", None, "SE-3 / HR-3 events' renamed_files; launch order", "RH-1 (vi)"),
    "r4_gaps.py::ri1_counts": (E, "E2", None, "launch records; RB-1 attempt records; RL-2 pass-through records; events; site counters", "attcount RI-1 (a) (i)-(iii), (b), (c) (LKA-8)"),
    "r4_gaps.py::rj1_callgrind": (E, "E2", None, "callgrind launch records; RB-1 (e) callgrind_result_present", "launchkind RJ-1 (b), (c) (LKA-8; LKA-9: its only E1-E4 reader)"),
    "r4_gaps.py::rj3_comparator": (E, "E2", None, "comparator launch records; raw-result 'comparator' mapping with key 'child' (presence)", "launchkind RJ-3 (LKA-8)"),
    "r4_gaps.py::rj4_unknown": (E, "E2", None, "launch records' stdout_path forms", "launchkind RJ-4 (b) (LKA-8; LKA-10)"),
    "r4_gaps.py::form_of": (E, "E2", None, "a relativized stdout_path", "RJ-4 (a) forms"),
    "r4_gaps.py::relativize": (E, "E2", None, "a recorded stdout_path; the recorded run directory", "LKA-10 strict prefix"),
    "r4_gaps.py::run_dir_recorded": ("reads no site value", "E2", None, "command.txt line 2 (GFPN_RUN_DIR)", "LKA-10"),
    "r4_gaps.py::package_files": (E, "E2", None, "the package's file listing under the five directories", "RL-3"),
    "r4_gaps.py::load_doc": (E, "E5", None, "solver-events.json", "loader"),
    "r4_gaps.py::load_raw": ("alpha", "E5", None, "raw-result.json", "loader (RJ-3 reads one key's presence)"),
    "r4_gaps.py::_argv": (E, "E2", None, "a launch record's argv", ""),
    # r4_check_run.py -- the r4 verdict layer (V-4 / epsilon readers; E2)
    "r4_check_run.py::verdict": ("V-4", "E2", None, "the frozen checker's exit and items; the r4 findings; launch records; manifest raw_result_writer; foreign files; gaps",
                                 "RK-3 (b) with RF-2, RF-3; stop classes RF-3 (b); LABELS RG-2, RH-2 (no value class)"),
    "r4_check_run.py::frozen_items": ("V-4", "E2", None, "the frozen checker's failing item lines", "RF-2 (iv)"),
    "r4_check_run.py::launch_class_check": (E, "E2", None, "launch records", "RF-3 (a) with RG-1 (d)"),
    "r4_check_run.py::launch_record_class": (E, "E2", None, "one launch record", "classes (A), (B), (C)"),
    "r4_check_run.py::undetermined_check": (E, "E2", None, "launch records' child_created / child_end / frame_inspection; raw_result_writer", "RF-0 (c)"),
    "r4_check_run.py::writer_check": (E, "E2", None, "manifest raw_result_writer (epsilon, written by the wrapper, RF-7)", "RF-0 (b); RF-3 (a)"),
    "r4_check_run.py::foreign_check": (E, "E2", None, "recorder-foreign-<pid>.json presence", "RF-1 (b)"),
    "r4_check_run.py::foreign_files": (E, "E2", None, "recorder-foreign-<pid>.json names", "RF-1 (b)"),
    "r4_check_run.py::gaps_check": (E, "E2", None, "the RL-3 gap lists", "RF-3 (a)"),
    "r4_check_run.py::zl_child_files": (E, "E2", None, "the package's file listing", "RK-3 (b) (iii)"),
    "r4_check_run.py::x13_check": ("alpha", "E2", None, "the controls_a1 image's run_status / gate_pass; the admission values recorded in the manifest", "RF-5 X-13"),
    "r4_check_run.py::recorded_attempts": (E, "E6", None, "RB-1 attempt records (the recorded attempt of each call)", "RB-3 enumeration (E6)"),
    # r4_run_wrapper.py
    "r4_run_wrapper.py::checker_verdict": ("V-4", "E2", None, "the r4 checker's exit status and verdict (run in this process)", "RB-4 (b); RL-4; RK-3 (b) (RB-7: consumer of V-4, E2)"),
    "r4_run_wrapper.py::rl4_read_packages": ("V-4", "E2", None, "each read package's r4 verdict", "RL-4 with RF-3 (b)"),
    "r4_run_wrapper.py::f4_recorded": ("V-4", "E5", None, "the F-4 package's r4 verdict", "RK-3 (d): recorded only, gates nothing"),
    "r4_run_wrapper.py::read_packages": ("reads no site value", "E2", None, "plan text; manifest existence", "RL-4 read list (X-03, X-04, X-07..X-11)"),
    "r4_run_wrapper.py::read_packages.add": ("reads no site value", "E5", None, "", ""),
    "r4_run_wrapper.py::readback_sources": ("V-1 row K-2", "E5", None, "RB-2 (a)-(c) with RL-3 (d), (e): raw-result by key name, child/*.meta.json, attempt, launch and pass-through records", "the RB-2 / RL-3 collector (K-2 derivative); records only"),
    "r4_run_wrapper.py::threads_sources": ("V-1 row K-2", "E5", None, "threads_executed by key name and RB-1 (c)", "RB-2; records only"),
    "r4_run_wrapper.py::child_readback_accounting": ("V-1 row K-2", "E5", None, "via readback_sources, launch_class_accounting, r4_gaps.recorder_gaps", "resources.child_readback_accounting; records only"),
    "r4_run_wrapper.py::launch_class_accounting": (E, "E5", None, "launch records", "RK-2 with RF-1 (c); records only"),
    "r4_run_wrapper.py::raw_result_writer": (E, "E5", None, "the wrapper's own parse result", "RF-0 (b) (epsilon, written by the wrapper, RF-7)"),
    "r4_run_wrapper.py::listing": ("reads no site value directly", "E5", None, "every file's bytes (sha256 only)", "RL-3 / RGL-7 listing"),
    "r4_run_wrapper.py::_pair_key": ("reads no site value directly", "E5", None, "a pair (primitive)", ""),
    # r4_make_plans.py
    "r4_make_plans.py::admission_block": ("reads no site value", "E5", None, "constants", "plan writer"),
    "r4_make_plans.py::branch_evidence": ("reads no site value", "E2", None, "the DV-2 / DV-3 development outputs (PS-1 branch)", "plan writer"),
})
# REQUIRED LISTINGS (RB-7, RL-5, RG-8, RH-7 with RI-5 (b), LKA-8, LKA-9): name -> (function, class, effect or None)
REQUIRED = {
    "RB-7 / LKA-9: the RB-1 (e) writer": ("r4_resolve.py::_rb1_callgrind_result_present", "gamma", "E5"),
    "RB-7: the RB-1 writers (S-1, S-2)": ("r4_resolve.py::_rb1_s1", "gamma", "E5"),
    "RB-7: the RB-2 collector (K-2 derivative, E5)": ("r4_run_wrapper.py::readback_sources", "V-1 row K-2", "E5"),
    "RB-7: the RB-3 enumeration (E6)": ("r4_check_run.py::recorded_attempts", "epsilon", "E6"),
    "RB-7: RB-4 (b) consumer of V-4 (E2)": ("r4_run_wrapper.py::checker_verdict", "V-4", "E2"),
    "RL-5: the launch recorder": ("r4_recorder.py::launch_recorder", "gamma", "E5"),
    "RL-5: reader of launch records (RK-2 accounting)": ("r4_run_wrapper.py::launch_class_accounting", "epsilon", "E5"),
    "RL-5: reader of launch records (RF-3 (a))": ("r4_check_run.py::launch_class_check", "epsilon", "E2"),
    "RL-5: reader of pass-through records (RL-3 (e))": ("r4_run_wrapper.py::readback_sources", "V-1 row K-2", "E5"),
    "RG-8: the callback": ("r4_recorder.py::_after_fork_in_parent", "gamma", "E5"),
    "RG-8: the counter read": ("r4_recorder.py::_read_counter", "gamma", "E5"),
    "RG-8: child_end (writer)": ("r4_recorder.py::child_end_value", "gamma", "E5"),
    "RG-8 / RH-7: the RG-4 / RH-1 attribution": ("r4_gaps.py::attribute", "epsilon", "E2"),
    "RH-7: RH-1 (v)": ("r4_gaps.py::_spec_ok", "epsilon", "E2"),
    "RH-7: RH-1 (vi)": ("r4_gaps.py::_renamed_ok", "epsilon", "E2"),
    "RH-7 / RI-5 (b): the RH-4 mark (in the callback)": ("r4_recorder.py::_after_fork_in_parent", "gamma", "E5"),
    "RI-5 (b) / LKA-8: the RI-1 counts (a) (i), (ii)": ("r4_gaps.py::ri1_counts", "epsilon", "E2"),
    "LKA-8 / LKA-9: RJ-1 (b)": ("r4_gaps.py::rj1_callgrind", "epsilon", "E2"),
    "LKA-8: RJ-3": ("r4_gaps.py::rj3_comparator", "epsilon", "E2"),
    "LKA-8: RJ-4 (b)": ("r4_gaps.py::rj4_unknown", "epsilon", "E2"),
}
LABELS = {"RG-2 infrastructure-stop outcome": "r4_check_run.py::verdict (label only; read only by the RF-3 (b) stop record and the planned-basis scope; no value class)",
          "RH-2 cap-mismatch stop outcome": "r4_check_run.py::verdict (label only; read only by the RF-3 (b) stop record and the planned-basis scope; no value class)"}
RB1_TOKENS = ("rb1", "callgrind_result_present", "attempt_records", "passthrough_records")
RB1_E1E4_CONSUMERS = ("r4_gaps.py::ri1_counts", "r4_gaps.py::rj1_callgrind")
CG3_KEYS = ("callgrind_children_observed", "with_log_visible_ssf_indicator", "with_quotient_dimension_mismatch",
            "with_readback_differing_from_requested_cap", "log_visible_ssf_indicator", "printed_quotient_dimension_equals_recorded_attempt",
            "child_readback_equals_requested_cap", "reg1_compared_fields_verbatim", "fglm_squarefree_degree", "random_linear_form_string_in_log",
            "attempt_recorded_by_the_wrapper")


def _nodoc_nodes(fn):
    """own_nodes without the function's docstring expression."""
    body = list(fn.body)
    if body and isinstance(body[0], ast.Expr) and isinstance(getattr(body[0], "value", None), ast.Constant) and isinstance(body[0].value.value, str):
        body = body[1:]
    stack = list(body)
    while stack:
        n = stack.pop()
        yield n
        for ch in ast.iter_child_nodes(n):
            if not isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)):
                stack.append(ch)


def lka_checks(trees, rows):
    """LKA-8, LKA-9 and VA-6 (c) / CC-5 on the delivered files. Returns (report, stops)."""
    stops, rep = [], {"rb1_token_readers": [], "callgrind_result_present_names": [], "calls_of_rb1_writer": [], "cg3_or_s3_names": []}
    by_key = {r["function"]: r for r in rows}
    for f, tree in trees.items():
        if f in DEV_FILES:
            continue
        for q, fn in functions(tree):
            key = "%s::%s" % (f, q)
            consts = {n.value for n in _nodoc_nodes(fn) if isinstance(n, ast.Constant) and isinstance(n.value, str)}
            attrs = {n.attr for n in _nodoc_nodes(fn) if isinstance(n, ast.Attribute)}
            calls = {(n.func.attr if isinstance(n.func, ast.Attribute) else getattr(n.func, "id", None)) for n in _nodoc_nodes(fn) if isinstance(n, ast.Call)}
            cls = (CLASSES.get(key) or MANUAL.get(key) or (None, None))
            c0, eff = cls[0], cls[1]
            if consts & set(RB1_TOKENS):
                rep["rb1_token_readers"].append({"function": key, "tokens": sorted(consts & set(RB1_TOKENS)), "class": c0, "effect": eff})
                if c0 != "gamma" and eff in ("E1", "E2", "E3", "E4") and key not in RB1_E1E4_CONSUMERS:
                    stops.append("LKA-8: %s reads an RB-1 value at %s and is not a consumer the incorporating texts name" % (key, eff))
            if "callgrind_result_present" in consts:
                rep["callgrind_result_present_names"].append(key)
                if key not in ("r4_resolve.py::_rb1_s1", "r4_gaps.py::rj1_callgrind"):
                    stops.append("LKA-9: %s names callgrind_result_present (only the writer _rb1_s1 and the reader rj1_callgrind may)" % key)
            if "_rb1_callgrind_result_present" in calls:
                rep["calls_of_rb1_writer"].append(key)
                if key != "r4_resolve.py::_rb1_s1":
                    stops.append("LKA-9: %s calls _rb1_callgrind_result_present" % key)
            hit = sorted((consts & set(CG3_KEYS)) | ({"SITE_S3"} & attrs))
            if hit:
                rep["cg3_or_s3_names"].append({"function": key, "names": hit, "effect": eff})
                if eff in ("E1", "E2", "E3", "E4"):
                    stops.append("VA-6 (c) / CC-5 / LKA-9: %s names %s at %s" % (key, hit, eff))
            if key == "r4_resolve.py::_rb1_callgrind_result_present":
                body = [st for st in fn.body if not (isinstance(st, ast.Expr) and isinstance(getattr(st, "value", None), ast.Constant))]
                ok = (len(body) == 1 and isinstance(body[0], ast.Return) and isinstance(body[0].value, ast.Compare)
                      and isinstance(body[0].value.left, ast.Constant) and body[0].value.left.value == "instructions_callgrind"
                      and len(body[0].value.ops) == 1 and isinstance(body[0].value.ops[0], ast.In)
                      and isinstance(body[0].value.comparators[0], ast.Name) and body[0].value.comparators[0].id == "res")
                rep["rb1_e_writer_body_is_the_key_membership_test"] = ok
                rep["rb1_e_writer_source"] = ast.unparse(fn)
                if not ok:
                    stops.append("LKA-9: _rb1_callgrind_result_present is not exactly the key-membership test")
    if "rb1_e_writer_body_is_the_key_membership_test" not in rep:
        stops.append("LKA-9: r4_resolve._rb1_callgrind_result_present not found")
    req = {}
    for name, (fkey, cls, eff) in REQUIRED.items():
        r = by_key.get(fkey)
        ok = bool(r) and r["class"] == cls and (eff is None or r["effect"] == eff)
        req[name] = {"function": fkey, "listed": bool(r), "class": r and r["class"], "effect": r and r["effect"], "expected": [cls, eff], "ok": ok}
        if not ok:
            stops.append("required listing %s: %s not listed with class %s / effect %s" % (name, fkey, cls, eff))
    rep["required_listings"] = req
    rep["classification_labels_no_value_class"] = LABELS
    return rep, stops


# listed by reading, not by the detector (control dependence the detector cannot see)''')
rep('''    if unclassified:
        stops.append("listed delivered functions without a classification: %s" % unclassified)''',
    '''    if unclassified:
        stops.append("listed delivered functions without a classification: %s" % unclassified)
    lka, lka_stops = lka_checks({f: ast.parse(texts[f]) for f in files}, rows)
    stops += lka_stops''')
rep('''    rep = {"method": __doc__, "files": files, "n_functions": len(funcs), "n_listed": len(rows), "rows": rows, "imports": imports,
           "VA-6 (d)": va6, "VA-7 (b)": va7, "declared_table_size": len(CLASSES), "manual_listings": sorted(MANUAL)}''',
    '''    rep = {"method": __doc__, "files": files, "n_functions": len(funcs), "n_listed": len(rows), "rows": rows, "imports": imports,
           "VA-6 (d)": va6, "VA-7 (b)": va7, "declared_table_size": len(CLASSES), "manual_listings": sorted(MANUAL),
           "LKA-8_LKA-9_and_required_listings": lka}''')
rep('''    rep["summary"] = {"n_functions": len(funcs), "n_listed": len(rows), "counts_by_class": counts, "gamma": gam,
                      "unclassified": unclassified, "bad_imports": bad_imports, "stops": stops}''',
    '''    rep["summary"] = {"n_functions": len(funcs), "n_listed": len(rows), "counts_by_class": counts, "gamma": gam,
                      "unclassified": unclassified, "bad_imports": bad_imports, "stops": stops,
                      "required_listings_ok": all(v["ok"] for v in lka["required_listings"].values()),
                      "rb1_e_writer_body_is_the_key_membership_test": lka.get("rb1_e_writer_body_is_the_key_membership_test"),
                      "callgrind_result_present_names": lka["callgrind_result_present_names"],
                      "rb1_token_readers": lka["rb1_token_readers"], "labels": LABELS}''')
open(p, "w").write(s)
print("edited")
