"""Scratch: print the (28)-(30) gap-level / verdict-level table (detectors enabled / disabled) and the (32) rows."""
import json, sys
r = json.load(open(sys.argv[1]))
for it in r["items"]:
    if it["item"].startswith(("(28)", "(29)", "(30)", "(31)")):
        print("ITEM", it["item"][:90])
        print("   alteration:", json.dumps(it["alteration_detail"])[:300])
        for k in sorted(it):
            if k.startswith("gap_level"):
                g = it[k]
                print("   %-28s named=%s gap_files=%s" % (k, g["named_kinds"], [x["file"] for x in g["gap_files"]][:6]))
            if k.startswith("verdict_level"):
                v = it[k]
                print("   %-28s verdict=%s stops=%s" % (k, v["verdict"], [s[:60] for s in (v["stop_classes"] or [])]))
        print("   pass:", it["pass"], "restored:", it["restored_sha256_equal"])
print("(32):")
for o, v in r["positive_control_32"].items():
    print("  ", o, "named", v["named_gaps"], "gap_files", len(v["gap_files"]), "verdict", v["verdict"]["verdict"], v["verdict"]["stop_classes"] and [s[:80] for s in v["verdict"]["stop_classes"]])
