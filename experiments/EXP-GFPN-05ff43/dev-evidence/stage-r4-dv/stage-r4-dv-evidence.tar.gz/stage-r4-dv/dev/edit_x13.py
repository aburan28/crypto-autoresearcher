"""Scratch editor: r4_check_run.x13_check reads the controls_a1 image in the SAME runs directory as the package under
check (the directory the frozen a1 checker's X-13 read resolves to), not through R.RUNS_DIR."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''    cid = plan["gate"]["addendum_blocking_package"]
    rp = os.path.join(R.RUNS_DIR, cid, "raw-result.json")'''
b = '''    cid = plan["gate"]["addendum_blocking_package"]
    # the image in the package's OWN runs directory (in a package: R.RUNS_DIR), the file the frozen X-13 read opens
    rp = os.path.join(os.path.dirname(os.path.abspath(rd).rstrip("/")), cid, "raw-result.json")'''
assert s.count(a) == 1
s = s.replace(a, b)
a2 = '''def x13_check(man, which, plan, rid, errs):'''
b2 = '''def x13_check(man, which, plan, rid, rd, errs):'''
assert s.count(a2) == 1
s = s.replace(a2, b2)
a3 = '''    x13_check(man, which, plan, rid, v_errs)             # RF-5'''
b3 = '''    x13_check(man, which, plan, rid, rd, v_errs)         # RF-5'''
assert s.count(a3) == 1
s = s.replace(a3, b3)
open(p, "w").write(s)
print("edited")
