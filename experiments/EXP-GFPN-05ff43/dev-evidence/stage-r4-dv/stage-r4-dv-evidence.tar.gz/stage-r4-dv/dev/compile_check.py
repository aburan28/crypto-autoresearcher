"""Scratch: compile every .py of the r4 layer with compile() (no byte code written, nothing imported)."""
import os, sys
d = sys.argv[1]
bad = 0
for f in sorted(os.listdir(d)):
    if f.endswith(".py"):
        try:
            compile(open(os.path.join(d, f)).read(), f, "exec")
            print("ok  ", f)
        except SyntaxError as e:
            bad += 1
            print("FAIL", f, e)
sys.exit(1 if bad else 0)
