"""Scratch editor: DV-18 (d) attempt 2 -- the (d) preflights read a (d)-specific development plan copy in which EVERY
occurrence of the G4 plan run id is replaced by the (a) package's development label (gate.blocking_packages, requires,
the package entry), so that the wrapper's RB-4 examines the (a) package as the G4 image."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''dplan = R.load_json(R.PLAN_V2_R4)
F4 = [p for p in dplan["packages"] if p["kind"] == "fixture4"][0]["run_id"]
D = os.path.join(OUT, "d")
if os.path.exists(D):
    raise SystemExit("REFUSING: %s exists" % D)
rep = {"development_label_of_the_(a)_package": LABEL, "later_package": F4, "copies": {}}'''
b = '''D = os.path.join(OUT, "d")
if os.path.exists(D):
    raise SystemExit("REFUSING: %s exists" % D)
os.makedirs(D)
PLAN_RID = PK["development_plan_copies"]["package_under_test"]["plan_run_id"]
dplans = {}
for key, attr in (("v2", "PLAN_V2_R4"), ("a1", "PLAN_A1_R4")):
    txt = open(getattr(R, attr)).read()
    n = txt.count(PLAN_RID)
    dp = os.path.join(D, "trial-plan-%s-r4.dev-d.json" % key)
    open(dp, "w").write(txt.replace(PLAN_RID, LABEL))
    dplans[key] = {"path": dp, "occurrences_of_the_G4_plan_run_id_replaced_by_the_label": n}
    setattr(R, attr, dp)
dplan = R.load_json(R.PLAN_V2_R4)
F4 = [p for p in dplan["packages"] if p["kind"] == "fixture4"][0]["run_id"]
rep = {"development_label_of_the_(a)_package": LABEL, "later_package": F4, "copies": {},
       "d_specific_plan_copies": dplans, "gate_blocking_packages_in_the_d_copy": dplan["gate"]["blocking_packages"]}'''
assert s.count(a) == 1
s = s.replace(a, b)
a2 = '''    runs = os.path.join(D, "world_a_copy_%s" % name, "runs")
    os.makedirs(os.path.dirname(runs))'''
b2 = '''    runs = os.path.join(D, "world_a_copy_%s" % name, "runs")
    os.makedirs(os.path.dirname(runs))
    CFG2 = json.load(open(CFGP))
    CFG2["R"].update(PLAN_V2_R4=R.PLAN_V2_R4, PLAN_A1_R4=R.PLAN_A1_R4, RUNS_DIR=runs)
    cfg2 = os.path.join(os.path.dirname(runs), "cfg-d.json")
    json.dump(CFG2, open(cfg2, "w"), indent=1)
    os.environ["R4_DV18_CFG"] = cfg2'''
assert s.count(a2) == 1
s = s.replace(a2, b2)
open(p, "w").write(s)
print("edited")
