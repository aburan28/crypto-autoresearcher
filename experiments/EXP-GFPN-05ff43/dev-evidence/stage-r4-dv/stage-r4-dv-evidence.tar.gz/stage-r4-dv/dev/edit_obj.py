"""Scratch editor: the objects' check shim installs no proxy (suffix None) instead of the faulty replace()."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''open(check_shim, "w").write(CHECK_SHIM.replace('and not (name == "v2_solver" and CFG.get("suffix"))', 'and False'))'''
b = '''open(check_shim, "w").write(CHECK_SHIM.replace('CFG = json.load(open(os.environ["R4_DV18_OBJ_CFG"]))',
                                               'CFG = json.load(open(os.environ["R4_DV18_OBJ_CFG"]))\\nCFG["suffix"] = None   # the checker process: no stand-in'))'''
assert s.count(a) == 1
open(p, "w").write(s.replace(a, b))
print("edited")
