"""Scratch editor: apply the r4-specific edits to implementation-v2-r4/r4_dv6.py (exact-string replacements; each must hit once)."""
import sys
p = sys.argv[1]
s = open(p).read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80])
    s = s.replace(a, b)
rep('''"""EXP-GFPN-05ff43 r3 successor stage -- DV-6: r3 wrapper refusals R-1..R-13 (dry-runs), the entry points' PARI
read-back refusal, the RC-3 redirection read-back refusal, the SE-3 and HR-3 replacement read-back refusals (attribute
rebound after install; recorded original replaced), a v2-entry case with a1_health imported, and the VA-7 (a) refusals
(an r3 constant, a redirected attribute or a plan string carrying a forbidden task id). Started from
implementation-v2-r2/r2_dv6.py. Development only; everything simulated lives in --out.''',
'''"""EXP-GFPN-05ff43 r4 stage (TASK-20260924-d91a96) -- DV-6: r4 wrapper refusals R-1..R-13 (dry-runs) with the RB-4
refusal cases (readbackcover RB-5: a gate package whose r4 checker fails; a controls_a1 image whose r4 checker fails)
and the RL-4 refusal (a read package whose r4 verdict is FAIL), the entry points' PARI read-back refusal, the RC-3
redirection read-back refusal, the SE-3, HR-3 and RL-5 replacement read-back refusals (attribute rebound after install;
recorded original replaced), a v2-entry case with a1_health imported, and the VA-7 (a) refusals (an r4 constant, a
redirected attribute or a plan string carrying a forbidden task id). Started from implementation-v2-r3/r3_dv6.py.
Development only; everything simulated lives in --out.''')
rep('''reason: r4_run_wrapper.git_tree_state returns the r3 files as tracked and clean (the r3 tree is not committed in
this stage) and a synthetic TASK-20260924-4a47e5 phase-A receipt in scratch binds the r3 files as they are. The real''',
'''reason: r4_run_wrapper.git_tree_state returns the r4 files as tracked and clean (the r4 tree is not committed in
this stage) and a synthetic TASK-20260924-4a47e5 phase-A receipt in scratch binds the r4 files as they are. The real''')
rep("real and scratch runs directories and the r3 tree are compared", "real and scratch runs directories and the r4 tree are compared")
rep('"DV-6 only: binds the r3 layer files as they are now', '"DV-6 only: binds the r4 layer files as they are now')
rep('''            "K": 5, "spacing_s": 2.0, "consistency_violation": False,
            "sites": {R.SITE_S1: {"counters": {}, "events": []}, R.SITE_S2: {"counters": {}, "events": []}, R.SITE_S3: {"counters": {}, "records": []}}}''',
'''            "K": 5, "spacing_s": 2.0, "consistency_violation": False, "launch_records": [], "recording_failures": [],
            "sites": {R.SITE_S1: {"counters": {}, "events": [], "attempt_records": [], "passthrough_records": []},
                      R.SITE_S2: {"counters": {}, "events": [], "attempt_records": []}, R.SITE_S3: {"counters": {}, "records": []}}}''')
rep("# G1..G4 (r3 ids)", "# G1..G4 (r4 ids)")
rep("# ---- R-1 (altered copies of each of the NINE bound files)", "# ---- R-1 (altered copies of each of the SEVENTEEN bound files)")
rep('''                      ("RUN-GFPN-0fa6cd", "an r2 run id"), ("RUN-GFPN-0f0f0f", "not reserved")):''',
'''                      ("RUN-GFPN-0fa6cd", "an r2 run id"), ("RUN-GFPN-f6a21a", "an r3 run id"), ("RUN-GFPN-bfe956", "an r3 run id"),
                      ("RUN-GFPN-0f0f0f", "not reserved")):''')
rep('''    case("R-2 RUN-GFPN-c8c1f8 (an r2 contingency id: on the 124-id retired list)", ["RUN-GFPN-c8c1f8"], "R-2 RUN-GFPN-c8c1f8 is a retired run id (the 124 retired ids)")
    # exhaustive: every one of the 124 retired ids, every frozen v2 / v2-a1 id and every v1 id is refused by R-2''',
'''    case("R-2 RUN-GFPN-c8c1f8 (an r2 contingency id: on the 162-id retired list)", ["RUN-GFPN-c8c1f8"], "R-2 RUN-GFPN-c8c1f8 is a retired run id (the 162 retired ids)")
    case("R-2 %s (an r3 id retired unused: on the 162-id retired list)" % R.RETIRED_R3[0], [R.RETIRED_R3[0]], "R-2 %s is a retired run id (the 162 retired ids)" % R.RETIRED_R3[0])
    # exhaustive: every one of the 162 retired ids, every frozen v2 / v2-a1 id, every r3 id and every v1 id is refused by R-2''')
rep('''    for rid in sorted(set(R.RETIRED_ALL) | set(frozen_all) | set(v1ids)):''',
'''    r3_all = [x["run_id"] for x in R.load_json(R.PLAN_V2_R3)["packages"]] + [x["run_id"] for x in R.load_json(R.PLAN_A1_R3)["packages"]]
    for rid in sorted(set(R.RETIRED_ALL) | set(frozen_all) | set(v1ids) | set(r3_all)):''')
rep('''(124 retired, 42 frozen, v1)''', '''(162 retired, 42 frozen, 42 r3, v1)''')
rep('''    s = scratch_runs("r3")
    os.makedirs(os.path.join(s, G[0]))''', '''    s = scratch_runs("r3dir")
    os.makedirs(os.path.join(s, G[0]))''')
rep('''    case("R-6 real state: r3 tree uncommitted, 4a47e5 phase-A receipt absent"''', '''    case("R-6 real state: r4 tree uncommitted, 4a47e5 phase-A receipt absent"''')
rep('''    case("R-7 controls_a1 image not passed", [BUILD_A1], "R-7 controls_a1 image %s did not pass" % CTL_A1, runs=s)''',
'''    case("R-7 controls_a1 image not passed", [BUILD_A1], "R-7 controls_a1 image %s did not pass" % CTL_A1, runs=s)
    # ---- RB-4 (b) refusal cases (readbackcover RB-5): (a) passes, the r4 checker fails
    s = scratch_runs("rb4_gate_checker")
    write_pkg(s, G[0], copy_from=ref)
    for g in G[1:]:
        write_pkg(s, g)
    case("RB-4 (b): every gate package completed_valid with gate_pass true, REG-1 passes on the synthetic G1, but the r4 checker "
         "fails on synthetic G2 (and on G3, G4 and the G1 copy)", [F4], "R-7 (RB-4 (b)) the r4 checker on gate package %s: exit 1 verdict FAIL" % G[1], runs=s)
    s = scratch_runs("rb4_ctl_checker")
    write_pkg(s, G[0], copy_from=ref)
    for g in G[1:]:
        write_pkg(s, g)
    write_pkg(s, CTL_A1, status="completed_valid", gate_pass=True)
    case("RB-4 (b): the controls_a1 image completed_valid with gate_pass true, but the r4 checker fails on it (synthetic image)", [BUILD_A1],
         "R-7 (RB-4 (b)) the r4 checker on the controls_a1 image %s: exit 1 verdict FAIL" % CTL_A1, runs=s)
    # ---- RL-4: a read package whose r4 verdict is FAIL (G2 reads G1 through REG-1, X-03)
    s = scratch_runs("rl4_read")
    write_pkg(s, G[0], copy_from=ref)
    case("RL-4: G2's read package G1 (X-03, a synthetic copy with a manifest) has r4 verdict FAIL", [G[1]],
         "R-8 (RL-4; RF-3 (b) designed stop) read package %s (X-03 G1 read by REG-1): r4 verdict FAIL" % G[0], runs=s)''')
rep('''    extra = R.RETIRED_R1[:3] + R.RETIRED_R2[:3]                # r1 and r2 ids count toward the eight-plan ceiling (HR-10)
    for i in frozen + extra:
        os.makedirs(os.path.join(s, i))
    case("R-11 shared ceiling: 48 synthetic run directories (42 frozen + 3 r1 + 3 r2 ids)", [G[0]], "R-11 ceiling: 48 run directories", runs=s)''',
'''    extra = R.RETIRED_R1[:2] + R.RETIRED_R2[:2] + R.RETIRED_R3[:2]   # r1, r2 and r3 ids count toward the ten-plan ceiling (RB-6 (e))
    for i in frozen + extra:
        os.makedirs(os.path.join(s, i))
    case("R-11 shared ceiling: 48 synthetic run directories (42 frozen + 2 r1 + 2 r2 + 2 r3 ids)", [G[0]], "R-11 ceiling: 48 run directories", runs=s)''')
rep('''    case("R-13 / VA-7 (a): an r3 constant (the stage card constant, patched in this process) carries a forbidden task id", [G[0]],
         "R-13 (VA-7 (a)) an r3 constant or redirected attribute value carries a forbidden task id",''',
'''    case("R-13 / VA-7 (a): an r4 constant (the stage card constant, patched in this process) carries a forbidden task id", [G[0]],
         "R-13 (VA-7 (a)) an r4 constant or redirected attribute value carries a forbidden task id",''')
rep('''            ("r4_entry_v2.py", "v2_with_a1_health", "HR-3 read-back: a module named a1_health is imported in the v2 entry", False),''',
'''            ("r4_entry_v2.py", "v2_with_a1_health", "HR-3 read-back: a module named a1_health is imported in the v2 entry", False),
            ("r4_entry_v2.py", "rl1_attr", "RL-5 install read-back: v2_solver.run_child is not the RL-1 launch recorder", False),
            ("r4_entry_a1.py", "rl1_attr", "RL-5 install read-back: v2_solver.run_child is not the RL-1 launch recorder", False),
            ("r4_entry_v2.py", "rl1_orig", "RL-5 install read-back: the recorder's captured original is not the frozen v2_solver.run_child", False),
            ("r4_entry_a1.py", "rl1_orig", "RL-5 install read-back: the recorder's captured original is not the frozen v2_solver.run_child", False),''')
rep('''#   va7_redirect: the r3 run-card constant''', '''#   rl1_attr: after the RL-1 install, v2_solver.run_child is rebound to the captured frozen function -> RL-5 refuses;
#   rl1_orig: the recorder's captured original is replaced by a non-frozen function -> RL-5 refuses;
#   va7_redirect: the r4 run-card constant''')
rep('''import r4_resolve as RS
mode, entry = os.environ["R4_DV6_MODE"], os.environ["R4_DV6_ENTRY"]
if mode == "se3_attr":''', '''import r4_resolve as RS
import r4_recorder as REC
mode, entry = os.environ["R4_DV6_MODE"], os.environ["R4_DV6_ENTRY"]
if mode == "rl1_attr":
    _instr = REC.install
    def install_rec(mod, rd):
        rec = _instr(mod, rd)
        mod.run_child = REC._ST["original"]
        return rec
    REC.install = install_rec
elif mode == "rl1_orig":
    _instr = REC.install
    def install_rec(mod, rd):
        rec = _instr(mod, rd)
        _o = REC._ST["original"]
        def run_child(*a, **k):
            return _o(*a, **k)
        REC._ST["original"] = run_child
        return rec
    REC.install = install_rec
elif mode == "se3_attr":''')
open(p, "w").write(s)
print("edited", p)
