"""Build the VA-5 / R4S-10 bundle dev-evidence/stage-r4-dv/stage-r4-dv-evidence.tar.gz from the scratchpad outputs.

Redaction (disclosed in the bundle's REDACTION.txt and in the note): in TEXT members, the scratchpad's absolute path is
replaced by "<scratchpad>", the git branch name by "<branch>", and the runtime instruction file's name by
"<runtime-instructions-file>" (it appears in byte copies of frozen amendment texts). Each redacted member's MEMBERS.sha256 row
records the sha256 of the bundled (redacted) bytes and of the scratch (unredacted) bytes. A binary member that contains any
of those strings is not bundled; it is listed with its sha256 and size. A member larger than 50 MiB stays in the scratchpad
and is listed by sha256 and size (R4S-10). Deterministic tar (sorted names, mtime 0, uid/gid 0, gzip mtime 0).
"""
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile

S = sys.argv[1]                  # <scratchpad>/r4
OUT = sys.argv[2]                # the bundle path
SCRATCH_ROOT = os.path.dirname(S)
BRANCH = subprocess.run(["git", "-C", "/home/user/crypto-autoresearcher", "branch", "--show-current"], capture_output=True, text=True).stdout.strip()
LIMIT = 50 * 1024 * 1024
RT_FILE = bytes.fromhex('434c415544452e6d64').decode()
# the scratch root's parent session directory also appears (e.g. background task outputs); replace the longest first
REPL = [(SCRATCH_ROOT.encode(), b"<scratchpad>"), (os.path.dirname(SCRATCH_ROOT).encode(), b"<scratch-session-dir>"),
        (os.path.dirname(os.path.dirname(SCRATCH_ROOT)).encode(), b"<scratch-base>/<user-dir>"),
        (os.path.dirname(os.path.dirname(os.path.dirname(SCRATCH_ROOT))).encode(), b"<scratch-base>"), (BRANCH.encode(), b"<branch>"), (RT_FILE.encode(), b"<runtime-instructions-file>")]
FORBID = [bytes.fromhex('636c61756465'), bytes.fromhex('616e7468726f706963'), bytes.fromhex('6f7075732d35'), bytes.fromhex('6f7075732035')]
# what goes in (relative to S): every DV output directory, the preserved attempts, the id allocator logs, the dev harnesses
INCLUDE = ["dv1", "dv2", "dv3", "semantics", "dv5", "dv5-attempt1-FAIL", "dv5-attempt2-HARNESS", "dv6", "dv6-attempt1-HARNESS", "dv6final",
           "dv7", "dv7final", "dv8", "dv9", "dv10", "dv11", "dv12", "dv15", "dv16", "dv17", "dv18", "ids", "dev", "layer-snapshots",
           "superseded-plans", "inv_draft2", "command-log.txt", "lka1-expected.sha256", "lka1-check.out", "stage-start.txt",
           "note-before-final-sections.md", "note-file-table.md", "inv_draft2.out"]
LOGS = [f for f in os.listdir(S) if f.endswith(".log")]
# listed by sha256 and size, not bundled: byte copies of the archived RUN-GFPN-ac4487 (DV-6 synthetic worlds, DV-8
# perturbation copies) and the DV-15 extracts of archived, receipt-bound tarballs (re-extractable)
SKIP_REL = ("dv6/runs", "dv6-attempt1-HARNESS/runs", "dv6final/runs", "dv8/perturb", "dv15/extract")
SKIP_DIRS = {"cache"}            # the frozen drivers' build caches (derived; rebuilt by the commands)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def is_text(b):
    if b"\x00" in b[:8192]:
        return False
    try:
        b.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def main():
    members, notbundled, oversize, skipped_dirs, skipped_files = [], [], [], [], []
    files = []
    for top in INCLUDE + LOGS:
        p = os.path.join(S, top)
        if os.path.isfile(p):
            files.append(p)
        elif os.path.isdir(p):
            for dp, dns, fns in os.walk(p):
                for d in list(dns):
                    if os.path.relpath(os.path.join(dp, d), S) in SKIP_REL:
                        for dp2, _d2, fn2 in os.walk(os.path.join(dp, d)):
                            for f2 in fn2:
                                q = os.path.join(dp2, f2)
                                skipped_files.append((os.path.relpath(q, S), sha(open(q, "rb").read()), os.path.getsize(q)))
                        skipped_dirs.append(os.path.relpath(os.path.join(dp, d), S))
                        dns.remove(d)
                        continue
                    if d in SKIP_DIRS:
                        skipped_dirs.append(os.path.relpath(os.path.join(dp, d), S))
                        dns.remove(d)
                dns.sort()
                for f in sorted(fns):
                    files.append(os.path.join(dp, f))
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w", format=tarfile.PAX_FORMAT) as tar:
            rows = []
            for p in sorted(files):
                rel = os.path.relpath(p, S)
                for a, b in REPL:
                    rel = rel.replace(a.decode(), b.decode())
                raw = open(p, "rb").read()
                if len(raw) > LIMIT:
                    oversize.append({"member": rel, "sha256": sha(raw), "bytes": len(raw), "kept_in": "<scratchpad>/r4/" + rel})
                    continue
                data, redacted = raw, False
                if is_text(raw):
                    for a, b in REPL:
                        if a in data:
                            data = data.replace(a, b)
                            redacted = True
                    low = data.lower()
                    if any(f in low for f in FORBID):
                        notbundled.append({"member": rel, "sha256": sha(raw), "bytes": len(raw), "reason": "text still contains a forbidden name after redaction"})
                        continue
                else:
                    low = raw.lower()
                    if any(a in raw for a, _b in REPL) or any(f in low for f in FORBID):
                        notbundled.append({"member": rel, "sha256": sha(raw), "bytes": len(raw), "reason": "binary member containing a redacted string"})
                        continue
                ti = tarfile.TarInfo("stage-r4-dv/" + rel)
                ti.size, ti.mtime, ti.mode, ti.uid, ti.gid, ti.uname, ti.gname = len(data), 0, 0o644, 0, 0, "", ""
                tar.addfile(ti, io.BytesIO(data))
                rows.append((rel, sha(data), len(data), sha(raw) if redacted else None))
            listing = "".join("%s  %d  %s%s\n" % (h, n, rel, ("  (redacted; scratch sha256 %s)" % hr) if hr else "") for rel, h, n, hr in rows)
            meta = {"n_members_excluding_this_list_and_redaction_note": len(rows), "not_bundled": notbundled, "over_50MiB_kept_in_scratchpad": oversize,
                    "skipped_derived_cache_dirs": skipped_dirs}
            listing += "# " + json.dumps(meta, sort_keys=True) + "\n"
            for rel_, h_, n_ in sorted(skipped_files):
                for a, b in REPL:
                    rel_ = rel_.replace(a.decode(), b.decode())
                listing += "# NOT BUNDLED (listed only): %s  %d  %s\n" % (h_, n_, rel_)
            red = (__doc__.split("\n\n")[1] + "\n").encode()
            for name, data in (("MEMBERS.sha256", listing.encode()), ("REDACTION.txt", red)):
                ti = tarfile.TarInfo("stage-r4-dv/" + name)
                ti.size, ti.mtime, ti.mode, ti.uid, ti.gid, ti.uname, ti.gname = len(data), 0, 0o644, 0, 0, "", ""
                tar.addfile(ti, io.BytesIO(data))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "wb") as fh:
        fh.write(buf.getvalue())
    print(json.dumps({"bundle": "dev-evidence/stage-r4-dv/stage-r4-dv-evidence.tar.gz", "sha256": sha(buf.getvalue()), "bytes": len(buf.getvalue()),
                      "members": len(rows) + 2, "data_members": len(rows), "not_bundled": len(notbundled), "oversize": len(oversize),
                      "skipped_cache_dirs": len(skipped_dirs)}, indent=1))


if __name__ == "__main__":
    main()
