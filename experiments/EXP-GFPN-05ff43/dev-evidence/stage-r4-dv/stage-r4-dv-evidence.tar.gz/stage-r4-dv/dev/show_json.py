"""Scratch: print selected keys of a JSON file (path, then dotted keys)."""
import json, sys
d = json.load(open(sys.argv[1]))
for k in sys.argv[2:]:
    o = d
    for part in k.split("."):
        o = o[int(part)] if isinstance(o, list) else o[part]
    print(k, "=", json.dumps(o, indent=1, default=str)[:4000])
