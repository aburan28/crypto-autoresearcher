"""Scratch: DV-9 summary numbers for the note."""
import json, sys
d = json.load(open(sys.argv[1]))
print("n_baseline", d["n_baseline"], "changed", len(d["changed"]), "added", len(d["added"]), "removed", len(d["removed"]))
print("other runs metadata:", d["other_run_packages_metadata_only"]["n_files"], "changed", len(d["other_run_packages_metadata_only"]["changed_or_added_or_removed"]))
print("receipts:", {k: (v if isinstance(v, str) else (v["experiment_paths_bound_and_readable"], v["equal"])) for k, v in d["receipt_equalities"].items()})
print("amendments all equal:", all(v[2] for v in d["amendments_seventeen"].values()), "ladder unchanged", d["ladder_json"]["unchanged"])
print("bytecode now", len(d["bytecode_now"]), "late", len(d["bytecode_later_than_stage_start"]), "unchanged", d["bytecode_unchanged_since_baseline"])
print("git status lines", len(d["git_status"]), "outside scope", d["git_status_outside_write_scope"], "tracked mods", d["git_status_tracked_modifications"])
print("runs entries", d["runs_dir_entries"], "no new run dir", d["no_new_run_directory"], "head", d["git_head"], d["git_head_unchanged"])
