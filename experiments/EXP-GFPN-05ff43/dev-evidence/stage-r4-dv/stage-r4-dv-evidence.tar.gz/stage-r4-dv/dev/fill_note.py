"""Scratch editor: fill the note's DV-6 final / DV-9 / DV-17 placeholders (text given here)."""
import sys
p = sys.argv[1]
s = open(p).read()
rep = {
    "| DV-6 | PASS (attempt 2); PENDING-DV6-FINAL | 04:40Z |":
        "| DV-6 | PASS (attempt 2, pre-patch layer); PASS again on the final layer | 04:40Z; 06:18Z-06:22Z |",
    "| DV-9 | PENDING-DV9 | last | section 9 |": "| DV-9 | PASS | 06:22Z (last) | section 9 |",
    "| DV-17 | PENDING-DV17 | 05:55Z- | section 12 of r3 carried: 36 entries x R = 10 calls of the frozen callgrind_instr":
        "| DV-17 | PASS | 05:54:56Z-06:18:02Z | 360 calls (36 entries x R = 10) of the frozen callgrind_instr",
    "PENDING-DV9-TEXT": (
        "PASS at 06:22Z, against the baseline taken at 04:00:48Z before any write (`dv9/baseline.json`; stage start "
        "03:52:17Z):\n"
        "- the 1294 files hashed under the frozen roots (every frozen tree, plan, amendment, the specification, "
        "`implementation/ladder.json`, the archives this stage verifies): 0 changed, 0 added, 0 removed;\n"
        "- the other run packages (2110 files, lstat size and mtime only, never read): 0 changed;\n"
        "- the seventeen amendments equal their bound sha256; `ladder.json` unchanged (7e42961d...327c);\n"
        "- receipt equalities (paths under the experiment that this stage may read): TASK-20260923-0fa03f phase A (14) and "
        "phase B (345), TASK-20260923-4ff597 phase A (12), TASK-20260924-f1fb0e phase A (22) and phase B (801), "
        "TASK-20260923-53a47d (17), TASK-20260924-5ca2a5 (19), TASK-20260924-3ee9a8 (3), TASK-20260924-0957c2 (3), "
        "TASK-20260924-ad3f9a (3), TASK-20260924-c65bfb (3), TASK-20260924-68cf6b (0 such paths): all equal. The run-package "
        "paths among them are files of the six packages R4S-12 permits (RUN-GFPN-ac4487, -3377f1 and the four r3 gate "
        "packages), hashed to verify the receipts; no other run package was read;\n"
        "- byte code: the 5 pre-existing files only; none later than the stage start; no `__pycache__` anywhere in the "
        "repository newer than the stage start;\n"
        "- `git status --porcelain --untracked-files=all` (GIT_OPTIONAL_LOCKS=0): 23 lines, every one an untracked path in the "
        "write scope; 0 tracked modifications; HEAD unchanged (1768588f0d7f94020f235e2141d7a843f45b150f); `runs/` 55 entries, "
        "no new run directory."),
}
for a, b in rep.items():
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)
open(p, "w").write(s)
print("filled")
