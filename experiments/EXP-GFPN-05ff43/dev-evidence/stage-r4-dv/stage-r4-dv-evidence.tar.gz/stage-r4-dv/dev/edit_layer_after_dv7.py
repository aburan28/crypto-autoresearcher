"""Scratch editor applied after DV-7 attempt 2 (recorded in the command log): three layer changes.
(1) r4_check_run.py: the frozen checker is run with cwd = the runs directory on the run directory's NAME, and the r4
    checker prints the run directory's name, so that no recorded text carries the absolute run directory in a form other
    than a path prefix (DEC-20260924-daf670 LKA-4 (b), as the DV-18 value table reads the manifest's verdict block);
(2) r4_run_wrapper.py: the recorded r4 checker command names the run directory's name, not its path;
(3) r4_dv7.py (development harness): the accounting directory is created before step (4) (the defect carried from r3),
    and the failed toy G2 is handled as the attempt-2 continuation declared (its 'did not pass' refusal expected).
"""
import sys
d = sys.argv[1]


def edit(fn, pairs):
    p = d + "/" + fn
    s = open(p).read()
    for a, b in pairs:
        assert s.count(a) == 1, (fn, s.count(a), a[:100])
        s = s.replace(a, b)
    open(p, "w").write(s)
    print("edited", fn)


edit("r4_check_run.py", [
    ('''        print("%s: FAIL; run id not reserved in either r4 plan" % rd)''',
     '''        print("%s: FAIL; run id not reserved in either r4 plan" % rid)'''),
    ('''    mode = "frozen-v2" if which == "v2r4" else "frozen-a1"
    pr = subprocess.run(FROZEN_LAUNCHER + [mode, rd], capture_output=True, text=True,
                        env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))''',
     '''    mode = "frozen-v2" if which == "v2r4" else "frozen-a1"
    # the frozen checker runs in its own process (RC-3 (e)) with cwd = the runs directory, on the run directory's NAME
    # (it joins every path to that argument and reads the run id from its basename), so its printed text names the run
    # directory's name, never its absolute path
    pr = subprocess.run(FROZEN_LAUNCHER + [mode, rid], cwd=os.path.dirname(rd), capture_output=True, text=True,
                        env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))'''),
    ('''    print("%s: r4 checks %s; %s" % (rd, "PASS" if not errs else "FAIL", notes))''',
     '''    print("%s: r4 checks %s; %s" % (rid, "PASS" if not errs else "FAIL", notes))'''),
])
edit("r4_run_wrapper.py", [
    ('''    out = {"command": "r4_check_run.main(%r) in the r4 run wrapper's process (frozen checker in its own process: %s)"
                      % (os.path.relpath(rd, R.REPO) if rd.startswith(R.REPO) else rd, " ".join(K.FROZEN_LAUNCHER)),''',
     '''    out = {"command": "r4_check_run.main(<runs directory>/%s) in the r4 run wrapper's process (frozen checker in its own process, "
                      "cwd <runs directory>: %s <mode> %s)" % (rid, " ".join(K.FROZEN_LAUNCHER), rid),'''),
])
edit("r4_dv7.py", [
    ('''    print("(4) the r4 checker on every toy package that ran through the wrapper")
    checks = []''',
     '''    print("(4) the r4 checker on every toy package that ran through the wrapper")
    os.makedirs(os.path.join(tdir, "accounting"), exist_ok=True)
    checks = []'''),
    ('''    report["declared_synthetic_packages"] = sorted(SYNTH)
    pat = re.compile(r"(?:gate package|read package) (RUN-GFPN-[0-9a-f]{6})")

    def classify(refusals):
        exp, unexp = [], []
        for r in refusals:
            m = pat.search(r)
            if (r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ") or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package ")) \\
                    and m and m.group(1) in SYNTH:
                exp.append(r)
            else:
                unexp.append(r)
        return exp, unexp''',
     '''    report["declared_synthetic_packages"] = sorted(SYNTH)
    # DECLARED BEFORE ANY LAUNCH (r4 DV-7 attempts 1-2; the r3 stage's attempt 2): the toy G2 (fixture --p 1039) is known
    # to keep the SSF signature on all six attempts of two toy systems and to end failed; if it does not pass, it STAYS
    # the toy lineage's G2 (it is not replaced) and the refusal "R-7 repaired gate package <toy G2> did not pass" is
    # EXPECTED for every later package. R-7's admission of a PASSING toy G2 is then not exercised (stated in the report).
    FAILED_G2 = []
    report["declared_failed_toy_G2_rule"] = "if the toy G2 does not pass, its R-7 'did not pass' refusal is expected for every later package"
    pat = re.compile(r"(?:gate package|read package) (RUN-GFPN-[0-9a-f]{6})")

    def classify(refusals):
        exp, unexp = [], []
        for r in refusals:
            m = pat.search(r)
            if FAILED_G2 and r.startswith("R-7 repaired gate package %s did not pass" % FAILED_G2[0]):
                exp.append(r)
            elif (r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ") or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package ")) \\
                    and m and m.group(1) in SYNTH:
                exp.append(r)
            else:
                unexp.append(r)
        return exp, unexp'''),
    ('''    run("A", G[1], "v2", SEED_A, runsB, rec_ref_B)
''',
     '''    g2 = run("A", G[1], "v2", SEED_A, runsB, rec_ref_B)
    if g2["status"] != "completed_valid" or g2["gate_pass"] is not True:
        FAILED_G2.append(G[1])
        report["toy_G2_did_not_pass"] = {"run_id": G[1], "status": g2["status"], "failure_class": g2["failure_class"], "gate_pass": g2["gate_pass"]}
'''),
    ('''              "all_run_packages_completed_valid": all(x["status"] == "completed_valid" for x in pkgs),''',
     '''              "all_run_packages_completed_valid_except_a_declared_failed_toy_G2": all(x["status"] == "completed_valid" for x in pkgs
                                                                                      if not (x["world"] == "A" and x["run_id"] in FAILED_G2)),'''),
])
edit("r4_dv12.py", [
    ('''    Gt = R.load_json(env["plan_v2r4"])["gate"]["blocking_packages"]
    synth = {Gt[2], Gt[3]}                                   # the DV-7 toy's declared synthetic gate packages''',
     '''    Gt = R.load_json(env["plan_v2r4"])["gate"]["blocking_packages"]
    synth = {Gt[2], Gt[3]}                                   # the DV-7 toy's declared synthetic gate packages
    # the DV-7 toy's declared rule: a toy G2 that did not pass stays the gate; its 'did not pass' refusal is expected
    g2raw = os.path.join(toy_dir, "world_A", "exp", "runs", Gt[1], "raw-result.json")
    failed_g2 = None
    if os.path.exists(g2raw):
        _g2 = json.load(open(g2raw))
        if _g2.get("run_status") != "completed_valid" or _g2.get("gate_pass") is not True:
            failed_g2 = Gt[1]'''),
    ('''        exp_ref = [r for r in refusals if (r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ")
                                           or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package "))
                   and pat.search(r) and pat.search(r).group(1) in synth]''',
     '''        exp_ref = [r for r in refusals if ((r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ")
                                            or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package "))
                                           and pat.search(r) and pat.search(r).group(1) in synth)
                   or (failed_g2 and r.startswith("R-7 repaired gate package %s did not pass" % failed_g2))]'''),
])
