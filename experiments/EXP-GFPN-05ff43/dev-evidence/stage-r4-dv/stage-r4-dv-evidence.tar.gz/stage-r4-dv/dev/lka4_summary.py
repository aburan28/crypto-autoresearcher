"""Scratch: summarize the LKA-4 value table of a DV-18 eval file (class counts; not-ok rows; text-log rows)."""
import json, sys, collections
e = json.load(open(sys.argv[1]))
t = e["LKA-4 value table"]
c = collections.Counter((r["file"].split("/")[0] if "/" in r["file"] else r["file"], r["class"][:70], r["ok"]) for r in t["rows"])
for k, v in sorted(c.items()):
    print(v, k)
print("absent listed fields:", t["listed_fields_absent_recorded_absent_not_a_STOP (LKA-4 (c))"])
print("text log rows:", len(t["text_log_rows"]), "not ok:", len(e["text_log_rows_not_ok"]))
for r in e["text_log_rows_not_ok"][:8]:
    print("  TEXT", r["file"], r["path"], r["form"][:80], r["raw"][:160])
print("argv rows not ok:", [r for r in e["RG-3 (e) argv substitution"] if not r.get("ok", True)][:2])
print("spec rows:", len(e["RH-3 (a) spec out substitution"]), "not ok:", [r for r in e["RH-3 (a) spec out substitution"] if not r["ok"]][:2])
