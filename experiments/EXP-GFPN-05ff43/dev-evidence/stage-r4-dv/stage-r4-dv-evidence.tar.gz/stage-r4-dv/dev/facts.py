"""Scratch: print the facts the note quotes (DV-2 / DV-3 / semantics / DV-1 / DV-9 baseline / plans)."""
import json, os, sys
S = sys.argv[1]
def j(p):
    return json.load(open(os.path.join(S, p)))
d3 = j("dv3/dv3.json"); print("DV-3 keys:", list(d3)[:20]); print(json.dumps({k: d3[k] for k in d3 if k not in ("workers",)}, default=str)[:1500])
sm = j("semantics/semantics.json"); print("SEM:", json.dumps(sm, default=str)[:1200])
d2 = j("dv2/dv2.json"); print("DV-2 keys:", list(d2)); print(json.dumps({k: d2[k] for k in ("pass",) if k in d2}))
d1 = j("dv1/dv1_static.json"); print("DV-1 probe:", json.dumps(d1["sage_child_probe"]["values"]), json.dumps(d1["toolchain"])[:800])
