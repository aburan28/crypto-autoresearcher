"""Scratch editor: the r4 bundle builder's INCLUDE list, and SKIP_REL (copies of archived packages / re-extractable
archive extracts / synthetic DV-6 worlds are listed by sha256 and size, not bundled)."""
import sys
p = sys.argv[1]
s = open(p).read()
a = s[s.index("INCLUDE = ["):s.index("SKIP_DIRS = ")]
b = '''INCLUDE = ["dv1", "dv2", "dv3", "semantics", "dv5", "dv5-attempt1-FAIL", "dv5-attempt2-HARNESS", "dv6", "dv6-attempt1-HARNESS", "dv6final",
           "dv7", "dv7final", "dv8", "dv9", "dv10", "dv11", "dv12", "dv15", "dv16", "dv17", "dv18", "ids", "dev", "layer-snapshots",
           "superseded-plans", "inv_draft2", "command-log.txt", "lka1-expected.sha256", "lka1-check.out", "stage-start.txt",
           "note-before-final-sections.md", "note-file-table.md", "inv_draft2.out"]
LOGS = [f for f in os.listdir(S) if f.endswith(".log")]
# listed by sha256 and size, not bundled: byte copies of the archived RUN-GFPN-ac4487 (DV-6 synthetic worlds, DV-8
# perturbation copies) and the DV-15 extracts of archived, receipt-bound tarballs (re-extractable)
SKIP_REL = ("dv6/runs", "dv6-attempt1-HARNESS/runs", "dv6final/runs", "dv8/perturb", "dv15/extract")
'''
s = s.replace(a, b)
a2 = '''            for dp, dns, fns in os.walk(p):
                for d in list(dns):
                    if d in SKIP_DIRS:'''
b2 = '''            for dp, dns, fns in os.walk(p):
                for d in list(dns):
                    if os.path.relpath(os.path.join(dp, d), S) in SKIP_REL:
                        for dp2, _d2, fn2 in os.walk(os.path.join(dp, d)):
                            for f2 in fn2:
                                q = os.path.join(dp2, f2)
                                skipped_files.append((os.path.relpath(q, S), sha(open(q, "rb").read()), os.path.getsize(q)))
                        skipped_dirs.append(os.path.relpath(os.path.join(dp, d), S))
                        dns.remove(d)
                        continue
                    if d in SKIP_DIRS:'''
assert s.count(a2) == 1
s = s.replace(a2, b2)
a3 = '''    members, notbundled, oversize, skipped_dirs = [], [], [], []'''
b3 = '''    members, notbundled, oversize, skipped_dirs, skipped_files = [], [], [], [], []'''
assert s.count(a3) == 1
s = s.replace(a3, b3)
a4 = '''            listing += "# " + json.dumps(meta, sort_keys=True) + "\\n"'''
b4 = '''            listing += "# " + json.dumps(meta, sort_keys=True) + "\\n"
            for rel_, h_, n_ in sorted(skipped_files):
                for a, b in REPL:
                    rel_ = rel_.replace(a.decode(), b.decode())
                listing += "# NOT BUNDLED (listed only): %s  %d  %s\\n" % (h_, n_, rel_)'''
assert s.count(a4) == 1
s = s.replace(a4, b4)
open(p, "w").write(s)
print("edited")
