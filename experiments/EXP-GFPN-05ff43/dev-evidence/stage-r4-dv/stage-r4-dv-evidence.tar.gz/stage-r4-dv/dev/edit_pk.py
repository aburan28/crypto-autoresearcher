"""Scratch editor: remove unused lines from the DV-18 package harness (before its first run)."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''import importlib.util                                    # noqa: E402
spec = importlib.util.spec_from_file_location("_v2c_paths", os.path.join(R.V2_DIR, "v2_common.py"))
real_fx3 = real_fx4 = None
src = open(os.path.join(R.V2_DIR, "v2_common.py")).read()
m3 = re.search(r'^RED_TEAM_SCRATCH = (.+)$', src, re.M)
'''
assert s.count(a) == 1
s = s.replace(a, "")
open(p, "w").write(s)
print("edited")
