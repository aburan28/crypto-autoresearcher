"""Scratch editor: DV-18 (h) module-level launch detection restricted to run_child, subprocess.* and os exec-family calls."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''            if isinstance(n, ast.Call) and callee(n)[0] in LAUNCHERS and not isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):'''
b = '''            if isinstance(n, ast.Call) and (callee(n)[0] == "run_child" or callee(n)[1] == "subprocess" or (callee(n)[1] == "os" and callee(n)[0] in EXEC_FAMILY)) \\
                    and not isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):'''
assert s.count(a) == 1
open(p, "w").write(s.replace(a, b))
print("edited")
