"""Scratch: the RC-4 (a) union map M from the delivered writer's inputs() (reads the frozen plans and minted ids only)."""
import sys, json
sys.dont_write_bytecode = True
sys.path.insert(0, sys.argv[1])
import r4_make_plans as MP
v2, a1, m2, m1, M, v2_order, a1_order = MP.inputs()
lab2 = {p["run_id"]: p["label"] for p in v2["packages"]}
lab1 = {p["run_id"]: p["label"] for p in a1["packages"]}
out = {"id_map_v2": [[i + 1, k, m2[k], lab2[k]] for i, k in enumerate(v2_order)],
       "id_map_a1": [[i + 1, k, m1[k], lab1[k]] for i, k in enumerate(a1_order)],
       "declared_v2": MP.DECLARED_KEYS_V2, "declared_a1": MP.DECLARED_KEYS_A1, "bijection": len(set(M.values())) == 42}
json.dump(out, open(sys.argv[2], "w"), indent=1)
for row in out["id_map_v2"]:
    print("| %d | %s | %s | %s |" % tuple(row))
print("---")
for row in out["id_map_a1"]:
    print("| %d | %s | %s | %s |" % tuple(row))
print("bijection", out["bijection"])
