"""Scratch: list the run directories DV-15 (b) enumerates: every package the DV-7 final run launched (dv7.json), every
DV-12 and DV-16 case package (their reports), one per line."""
import json, os, sys
S = sys.argv[1]
out = []
for x in json.load(open(os.path.join(S, "dv7final", "dv7.json")))["packages"]:
    if x.get("launched"):
        out.append(x["run_dir"])
for f in ("dv12/dv12.json", "dv16/dv16.json"):
    for c in json.load(open(os.path.join(S, f)))["cases"].values():
        if c.get("launched"):
            out.append(c["run_dir"])
print("\n".join(out))
