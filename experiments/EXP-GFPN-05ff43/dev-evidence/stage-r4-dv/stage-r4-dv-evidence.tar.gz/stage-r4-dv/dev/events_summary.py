"""Scratch: summarize the S-1 / S-2 events of a solver-events.json (tag, attempts, clauses, accepted, still_ssf, cap)."""
import json, sys
d = json.load(open(sys.argv[1]))
for site, sec in (d.get("sites") or {}).items():
    for e in sec.get("events") or []:
        print(site, e.get("tag"), "attempts", len(e.get("attempts") or []), "clauses", [a.get("ssf_clause") for a in e.get("attempts") or []],
              "accepted", e.get("accepted_attempt"), "still_ssf", e.get("still_ssf_after_last_attempt"), "cap", e.get("resolve_cap_reached"))
    print(site, "counters", sec.get("counters"))
print("launch_records", len(d.get("launch_records") or []))
