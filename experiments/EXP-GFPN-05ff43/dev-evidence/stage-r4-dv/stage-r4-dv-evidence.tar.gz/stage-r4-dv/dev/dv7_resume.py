"""DV-7 continuation (attempt 2) -- a DEVELOPMENT harness kept OUTSIDE implementation-v2-r4/ (bundled under dv7/).
EXP-GFPN-05ff43 r4 stage, TASK-20260924-d91a96. Derived from the r3 stage's continuation dv7_resume5.py (reference copy).

Why it exists (recorded harness reasons; command log entry [27]):
  (a) attempt 1 crashed in step (4): the accounting directory was never created (harness defect carried in r4_dv7.py
      from r3_dv7.py; NOT fixed in the layer, because the layer is bound by attempt 1's synthetic phase-A receipt);
  (b) toy G2 (fixture --p 1039) ended failed / implementation_error (the frozen driver's AC-5 reading) because the toy
      raw_u and S3_rescaled systems of target reg0 kept the SSF signature (clause ii) on all six SE-3 attempts -- the
      r3 stage's attempt-2 observation, reproduced -- so every later package met R-7's refusal "toy G2 did not pass",
      which attempt 1's classifier did not list as expected, and nothing was launched.
What it does NOT redo: steps (1) and (2) and the toy G2 package. The SE-5 probe ran ONCE, in attempt 1; its RECORDED
packages (world A G1, world B G1), the perturbed copy and the receipts are reused unchanged and re-READ (no solve).
DECLARED BEFORE ANY LAUNCH OF THIS CONTINUATION: the real toy G2 (as recorded by attempt 1) stays the toy lineage's G2 --
it is NOT replaced by a synthetic row (unlike the r3 continuation) -- and the refusal "R-7 repaired gate package <toy G2>
did not pass" is EXPECTED for every later package, exactly like the refusals naming the declared synthetic packages (G3,
G4, the builds and cells at 262151 / 16777291). Every other refusal is unexpected (a DV-7 failure; not launched).
Consequence, stated plainly: R-7's admission of a PASSING toy G2 is not exercised here (as in r3); the refusal of a
failed gate package is.
No layer file is edited; the synthetic phase-A receipt of attempt 1 still binds the layer as it is (checked at start).

usage: python3 -B dv7_resume.py OUT     (OUT = attempt 1's --out directory)
"""
import contextlib
import datetime
import io
import json
import os
import re
import sys

sys.dont_write_bytecode = True
LAYER = "/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2-r4"
sys.path.insert(0, LAYER)
import r4_common as R           # noqa: E402
import r4_dv7 as T              # noqa: E402

ATTEMPT1_VERDICTS = {"se5_probe": "PASS (printed by attempt 1: 'SE-5 probe: PASS []')",
                     "reg1_perturbed_copy": "FAIL (printed by attempt 1: 'REG-1 on a perturbed copy: FAIL')"}


def main(out):
    tdir = os.path.join(out, "toy")
    sys.path.insert(0, R.V2_DIR)
    sys.path.insert(0, R.A1_DIR)
    toy = T.Toy(tdir)
    env = toy.load()
    bound = R.load_json(env["receipt_a"])["path_sha256"]
    unbound = [os.path.join(dp, f) for dp, _d, fn in os.walk(LAYER) for f in fn if os.path.relpath(os.path.join(dp, f), R.REPO) not in bound]
    if unbound:
        raise SystemExit("REFUSING: files in the layer not bound by the synthetic receipt: %s" % unbound)
    stale = [p for p, h in bound.items() if T.sha(os.path.join(R.REPO, p)) != h]
    if stale:
        raise SystemExit("REFUSING: layer changed since attempt 1's receipt: %s" % stale)
    v2r4, a1r4 = R.load_json(env["plan_v2r4"]), R.load_json(env["plan_a1r4"])
    by = {pk["order"]: pk for pk in v2r4["packages"]}
    G = v2r4["gate"]["blocking_packages"]
    report = {"attempt": 2, "kind": "continuation of attempt 1 from step (3); the real failed toy G2 stays the gate package (declared)",
              "started": R.now(), "no_ladder_or_fixture_prime_solved": True, "attempt1_verdicts_as_printed": ATTEMPT1_VERDICTS,
              "toy_primes": {"a1_role": T.TOY_A1_P, "v2_role": env["v2_role_prime"], "fixture_n3": T.TOY_FX3, "fixture_n4": T.TOY_FX4_P}}
    SYNTH = {G[2], G[3]} | {by[o]["run_id"] for o in range(13, 27)}
    FAILED_G2 = G[1]
    report["declared_synthetic_packages"] = sorted(SYNTH)
    report["declared_failed_gate_package_expected_in_refusals"] = FAILED_G2
    os.environ["GFPN_V2_CACHE_DIR"] = os.path.join(tdir, "cache")
    worlds = {w: os.path.join(tdir, "world_%s" % w, "exp") for w in ("A", "B")}
    runsA, runsB = os.path.join(worlds["A"], "runs"), os.path.join(worlds["B"], "runs")
    rec_ref_A = os.path.join(tdir, "toy-reference-receipt-worldA-G1.json")
    rec_ref_B = os.path.join(tdir, "toy-reference-receipt-worldB-G1.json")
    rec_b = os.path.join(tdir, "toy-4a47e5-post-run-receipt.json")
    trace = os.path.join(tdir, "trace.jsonl")
    shims = {n: os.path.join(tdir, "shims", n) for n in ("entry_toy.py", "check_toy.py")}
    import r4_run_wrapper as W
    import r4_check_run as K
    import r4_reg1 as REG
    K.FROZEN_LAUNCHER = [sys.executable, "-B", shims["check_toy.py"]]
    real_git = W.git_tree_state
    W.git_tree_state = lambda paths: (env["r4files"], []) if paths == R.R4_PATHS_REL else real_git(paths)
    W.ENTRY_V2 = W.ENTRY_A1 = shims["entry_toy.py"]
    for k, v in {"PLAN_V2_R4": env["plan_v2r4"], "PLAN_A1_R4": env["plan_a1r4"], "PLAN_V2": env["plan_v2"], "RECEIPT_R4_PHASE_A": env["receipt_a"],
                 "RECEIPT_R4_PHASE_B": rec_b, "REG1_REFERENCE_RUN": G[0]}.items():
        setattr(R, k, v)
    prev = R.load_json(os.path.join(out, "dv7-attempt1-progress.json"))["packages"]
    pkgs = [x for x in prev if x["run_id"] in (G[0], G[1]) and x["launched"]]
    assert [(x["world"], x["run_id"]) for x in pkgs] == [("A", G[0]), ("B", G[0]), ("A", G[1])], [(x["world"], x["run_id"]) for x in pkgs]
    for x in pkgs:
        x["recorded_by"] = "attempt 1"
    pat = re.compile(r"(?:gate package|read package) (RUN-GFPN-[0-9a-f]{6})")

    def classify(refusals):
        exp, unexp = [], []
        for r in refusals:
            m = pat.search(r)
            if r.startswith("R-7 repaired gate package %s did not pass" % FAILED_G2):
                exp.append(r)
            elif (r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ") or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package ")) \
                    and m and m.group(1) in SYNTH:
                exp.append(r)
            else:
                unexp.append(r)
        return exp, unexp

    def run(w, rid, entry_kind, seed, reg_runs, reg_receipt):
        os.environ["R4_TOY_CFG"] = T.cfg_for(tdir, env, worlds[w], reg_runs, reg_receipt, rec_b, trace)
        os.environ["R4_TOY_ENTRY"] = entry_kind
        os.environ["R4_TOY_PACKAGE"] = "%s/%s" % (w, rid)
        R.RUNS_DIR, R.RECEIPT_V2_PHASE_B = reg_runs, reg_receipt
        W.RUNS = os.path.join(worlds[w], "runs")
        W.DRIVER_PYTHONHASHSEED = seed
        t0 = datetime.datetime.now(datetime.timezone.utc)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            refusals, info = W.preflight(rid)
        exp_ref, unexp_ref = classify(refusals)
        rc = None
        if not unexp_ref:
            with contextlib.redirect_stdout(buf):
                rc = W.launch(rid, None, info)
        t1 = datetime.datetime.now(datetime.timezone.utc)
        man = T.manifest_row(W.RUNS, rid)
        row = {"world": w, "run_id": rid, "entry": entry_kind, "PYTHONHASHSEED_set": seed, "wrapper_launch_rc": rc,
               "preflight_refusals_expected": exp_ref, "preflight_refusals_unexpected": unexp_ref, "launched": rc is not None,
               "wrapper_output": buf.getvalue().splitlines(), "recorded_by": "attempt 2",
               "r4_verdict": man and (man.get("verdict") or {}).get("r4_verdict"),
               "r4_stop_classes": man and (man.get("verdict") or {}).get("stop_classes"),
               "raw_result_writer": man and man.get("raw_result_writer"),
               "gate_package_checker": man and {k: (v.get("exit_status"), v.get("verdict")) for k, v in ((man.get("gate") or {}).get("gate_package_checker") or {}).items()},
               "required_package_checker": man and {k: (v.get("exit_status"), v.get("verdict")) for k, v in ((man.get("gate") or {}).get("required_package_checker") or {}).items()},
               "run_dir": os.path.join(W.RUNS, rid), "started": t0.isoformat(), "finished": t1.isoformat(),
               "status": man and man["status"], "failure_class": man and man["failure_class"], "gate_pass": man and man["result"]["gate_pass"],
               "getrlimit": man and man["resources"]["child_rlimit_as_read_back_by_getrlimit"],
               "threads": man and man["resources"]["msolve_threads_executed"],
               "pari_stack_status": man and (man["resources"]["pari_stack"] or {}).get("status"),
               "hashseed_readback": man and ((man.get("environment") or {}).get("PYTHONHASHSEED_driver_readback") or {}).get("PYTHONHASHSEED_env"),
               "reg1_in_manifest": man and ((man.get("gate") or {}).get("regression_REG-1") or {}).get("verdict"),
               "solver_events_block": man and man.get("solver_events")}
        pkgs.append(row)
        T.dump(os.path.join(out, "dv7-progress.json"), dict(report, packages=pkgs))
        print("   world %s %s %-4s launched=%s status=%s gate_pass=%s REG-1=%s verdict=%s hashseed=%s expected-refusals=%d unexpected=%s (%.0fs)" % (
            w, rid, entry_kind, rc is not None, row["status"], row["gate_pass"], row["reg1_in_manifest"], row["r4_verdict"], row["hashseed_readback"],
            len(exp_ref), unexp_ref, (t1 - t0).total_seconds()), flush=True)
        return row
    # ---- (2') re-read of the recorded SE-5 packages (no solve)
    ga, gb = os.path.join(runsA, G[0]), os.path.join(runsB, G[0])
    probe = REG.compare(ga, gb, receipt=rec_ref_A)
    report["se5_probe"] = {"PYTHONHASHSEED": {"world_A": T.SEED_A, "world_B": T.SEED_B}, "reference": "world A G1", "candidate": "world B G1",
                           "run_once_in": "attempt 1", "verdict_reread": probe["verdict"], "failures": probe["failures"], "output": REG.render(probe),
                           "ssf_per_world": {x["world"]: (x["solver_events_block"] or {}).get("sites") for x in pkgs if x["run_id"] == G[0]}}
    pr = REG.compare(ga, os.path.join(tdir, "perturbed", G[0]), receipt=rec_ref_A)
    report["reg1_perturbed_copy"] = {"perturbation": "world B G1 copy: planted_targets[0] first arm D + 1 (written by attempt 1)",
                                     "verdict_reread": pr["verdict"], "failures": pr["failures"]}
    print("(2') recorded SE-5 packages re-read: probe %s; perturbed copy %s" % (probe["verdict"], pr["verdict"]), flush=True)
    if probe["verdict"] != "PASS":
        report["STOP"] = "SE-5 re-read differs from attempt 1's printed PASS"
        T.dump(os.path.join(out, "dv7.json"), dict(report, packages=pkgs, **{"pass": False}))
        return 3
    # ---- (3) the rest of the lineage in world A
    print("(3) world A (continuation): G3, G4 SYNTHETIC; F-4; v2 build, cells, aggregate; the addendum packages", flush=True)
    for g, why in ((G[2], "anchor-identity is not run at toy scale (hard-coded p' = 16777291 and the Sage anchor system; DV-18 (b) runs it)"),
                   (G[3], "controls is not run at toy scale (hard-coded fixture field at 4111 and ladder primes 4111, 262151, 16777291; DV-18 (a) runs it)")):
        T.synthetic_pkg(runsA, g, {"kind": "synthetic_gate", "run_status": "completed_valid", "gate_pass": True, "synthetic": T.SYN, "reason": why})
    for o in [5, 6, 7, 8, 9, 10, 11, 12]:
        run("A", by[o]["run_id"], "v2", T.SEED_A, runsB, rec_ref_B)
    T.synthetic_v2_cells(runsA, v2r4, skip_ids={by[o]["run_id"] for o in range(7, 13)})
    for o in (13, 20):
        T.synthetic_pkg(runsA, by[o]["run_id"], {"kind": "build", "run_status": "completed_valid", "synthetic": T.SYN,
                                                 "reason": "SYNTHETIC toy row: builds at 262151 / 16777291 are not run at toy scale"})
    run("A", by[27]["run_id"], "v2", T.SEED_A, runsB, rec_ref_B)
    v2_read = [by[o]["run_id"] for o in range(1, 28) if by[o]["kind"] in ("cells", "aggregate")]
    head = R.load_json(env["receipt_a"]).get("commit_sha")
    T.dump(rec_b, {"synthetic": T.SYN, "commit_sha": head,
                   "path_sha256": {os.path.relpath(os.path.join(runsA, i, "raw-result.json"), R.REPO): T.sha(os.path.join(runsA, i, "raw-result.json"))
                                   for i in v2_read if os.path.exists(os.path.join(runsA, i, "raw-result.json"))}})
    ba = {pk["order"]: pk for pk in a1r4["packages"]}
    for o in range(1, 10):
        run("A", ba[o]["run_id"], "a1", T.SEED_A, runsB, rec_ref_B)
    agg_path = os.path.join(runsA, ba[9]["run_id"], "raw-result.json")
    agg = R.load_json(agg_path) if os.path.exists(agg_path) else {}
    report["rc8_aggregate_a1_phase_b_check"] = (agg.get("v2_bytes_phase_B_check") or {}).get("status")
    report["packages"] = pkgs
    # ---- (4) the r4 checker, standalone, on every toy package that ran (accounting directory created)
    print("(4) the r4 checker on every toy package that ran through the wrapper", flush=True)
    os.makedirs(os.path.join(tdir, "accounting"), exist_ok=True)
    checks = []
    for x in pkgs:
        if not x["launched"]:
            continue
        os.environ["R4_TOY_CFG"] = T.cfg_for(tdir, env, worlds[x["world"]], runsB if x["world"] == "A" else runsA,
                                             rec_ref_B if x["world"] == "A" else rec_ref_A, rec_b, None)
        os.environ.pop("R4_TOY_PACKAGE", None)
        R.RUNS_DIR = runsB if x["world"] == "A" else runsA
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = K.main(x["run_dir"], os.path.join(tdir, "accounting", "%s_%s.json" % (x["world"], x["run_id"])))
        lines = buf.getvalue().splitlines()
        checks.append({"world": x["world"], "run_id": x["run_id"], "rc": rc, "output": lines,
                       "failing_items": [l.strip()[2:] for l in lines if l.startswith("  - ")],
                       "r4_verdict": next((l.split(": ", 1)[1] for l in lines if l.startswith("R4 VERDICT: ")), None)})
        print("   check world %s %s rc=%s verdict=%s %s" % (x["world"], x["run_id"], rc, checks[-1]["r4_verdict"], checks[-1]["failing_items"][:3]), flush=True)
    report["checker"] = checks
    # ---- (5) DV-13, DV-14, forbidden ids, DV-1 dynamic
    ran = [x for x in pkgs if x["launched"]]
    report["dv13"] = {"per_package": [{"world": x["world"], "run_id": x["run_id"], "set": x["PYTHONHASHSEED_set"], "driver_readback": x["hashseed_readback"]} for x in ran],
                      "evaluated_over": "every toy package launched (%d); refused launches (%d) start no driver" % (len(ran), len(pkgs) - len(ran))}
    report["dv13"]["pass"] = bool(ran) and all((x["hashseed_readback"] == T.SEED_A) if x["world"] == "A" else (x["hashseed_readback"] == T.SEED_B) for x in ran)
    gaps = []
    for x in ran:
        sp = os.path.join(x["run_dir"], "solver-events.json")
        if not os.path.exists(sp):
            continue
        doc = R.load_json(sp)
        for site in (R.SITE_S1, R.SITE_S2):
            for e in ((doc.get("sites") or {}).get(site) or {}).get("events") or []:
                a = e.get("attempts") or []
                for i in range(1, len(a)):
                    s = datetime.datetime.strptime(a[i]["start_utc"], "%Y-%m-%dT%H:%M:%S.%fZ")
                    en = datetime.datetime.strptime(a[i - 1]["end_utc"], "%Y-%m-%dT%H:%M:%S.%fZ")
                    gaps.append({"package": "%s/%s" % (x["world"], x["run_id"]), "site": site, "tag": e.get("tag"), "attempt": a[i]["attempt"],
                                 "gap_s": (s - en).total_seconds()})
    report["dv14"] = {"re_solve_gaps": gaps, "n_re_solves": len(gaps), "pass": all(g["gap_s"] >= R.SPACING_S for g in gaps)}
    bad = []
    for dp, _d, fn in os.walk(tdir):
        for f in fn:
            b = open(os.path.join(dp, f), "rb").read()
            for t in R.FORBIDDEN_TASK_IDS:
                if t.encode() in b:
                    bad.append({"file": os.path.relpath(os.path.join(dp, f), tdir), "id": t})
    report["forbidden_task_ids_in_toy_artifacts_report_only"] = bad
    tr = [json.loads(l) for l in open(trace)] if os.path.exists(trace) else []
    calls = [t for t in tr if t["event"] == "cypari2.Pari.__call__"]
    report["dv1_dynamic"] = {
        "trace_file": "dv7/toy/trace.jsonl (attempt 1 and attempt 2 records)", "n_events": len(tr),
        "in_process_pari_calls": sorted({json.dumps([t.get("package"), t.get("p"), t.get("field_degree"), " <- ".join(reversed(t["stack"][-3:]))]) for t in calls}),
        "cypari2_constructions_by_caller": sorted({json.dumps([(t.get("package") or "").split("/")[0], t["stack"][-1] if t["stack"] else None]) for t in tr if t["event"] == "cypari2.Pari()"}),
        "children_by_launcher": sorted({json.dumps([t.get("launcher"), t.get("child_argv0")]) for t in tr if t["event"] == "fork"}),
        "gp_children": [{"package": t.get("package"), "launcher": t.get("launcher"), "pid": t.get("child_pid")} for t in tr
                        if t["event"] == "fork" and t.get("child_argv0") == "gp"],
        "imports": sorted({json.dumps([(t.get("package") or "").split("/")[0], t["event"]]) for t in tr if t["event"].startswith("import:")})}

    # ---- (6) evaluation
    def check_ok(c):
        if c["world"] == "B":
            return c["failing_items"] == ["SE-6: the driver process read back PYTHONHASHSEED '12345', not '0'"]
        return c["rc"] == 0 and c["r4_verdict"] in ("PASS", "PASS_ZL")
    later = [x for x in pkgs if x["recorded_by"] == "attempt 2"]
    exp_ok = {"no_unexpected_preflight_refusal": all(not x["preflight_refusals_unexpected"] for x in later),
              "every_continuation_package_launched": all(x["launched"] for x in later),
              "every_world_A_manifest_verdict_PASS_or_PASS_ZL": all(x["r4_verdict"] in ("PASS", "PASS_ZL") for x in ran if x["world"] == "A"),
              "all_run_packages_completed_valid_except_the_declared_failed_toy_G2":
                  all(x["status"] == "completed_valid" for x in ran if not (x["world"] == "A" and x["run_id"] == FAILED_G2)),
              "checker_passes_every_world_A_package": all(check_ok(c) for c in checks if c["world"] == "A"),
              "checker_on_world_B_G1_fails_only_on_the_declared_SE6_override": all(check_ok(c) for c in checks if c["world"] == "B"),
              "se5_probe_pass": probe["verdict"] == "PASS", "reg1_perturbed_copy_fails": pr["verdict"] == "FAIL",
              "rc8_phase_b_verified": report["rc8_aggregate_a1_phase_b_check"] == "verified",
              "dv13_pass": report["dv13"]["pass"], "dv14_pass": report["dv14"]["pass"],
              "getrlimit_all_10737418240": all(all(g == {"soft": R.CAP_BYTES, "hard": R.CAP_BYTES} for g in (x["getrlimit"] or [])) for x in ran),
              "threads_all_1": all((x["threads"] or [1]) == [1] for x in ran),
              "every_package_pari_stack_command_returned": all(x["pari_stack_status"] == "command_returned" for x in ran)}
    report["summary"] = exp_ok
    report["packages_run"] = len(ran)
    report["pass"] = all(exp_ok.values())
    report["not_exercised"] = {"anchor-identity": "not run at toy scale; run ONCE by DV-18 (b) at its hard-coded parameters (RB-5)",
                               "controls": "not run at toy scale; run ONCE by DV-18 (a) at its hard-coded parameters (RB-5)",
                               "R-7 admission of a PASSING toy G2": "not exercised: the real toy G2 failed at 1039 (declared, recorded)",
                               "contingency launches": "not launched in the toy; every R-12 refusal is exercised by DV-6"}
    report["finished"] = R.now()
    T.dump(os.path.join(out, "dv7.json"), report)
    print(json.dumps(report["summary"], indent=1))
    print("DV-7:", "PASS" if report["pass"] else "FAIL", flush=True)
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
