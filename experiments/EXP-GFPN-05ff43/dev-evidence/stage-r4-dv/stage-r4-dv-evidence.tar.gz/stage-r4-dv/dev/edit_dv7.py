"""Scratch editor: apply the r4-specific edits to implementation-v2-r4/r4_dv7.py (exact-string replacements; each must
hit exactly once)."""
import sys
p = sys.argv[1]
s = open(p).read()


def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:100])
    s = s.replace(a, b)


# ---- docstring
i0 = s.index('"""EXP-GFPN-05ff43 r3 successor stage')
i1 = s.index('"""\nimport contextlib')
s = s[:i0] + '''"""EXP-GFPN-05ff43 r4 stage (TASK-20260924-d91a96) -- DV-7: TOY INTEGRATION of the DELIVERED r4 layer (paristack PS-6
DV-7 with RC-3, RC-8; solverevent SE-5 (the probe) and SE-8; healthresolve HR-9 (controls-a1 through the r4 a1 entry);
DEC-20260924-15a77a SC-11 (f); DEC-20260924-daf670 LKA-11 (a)), with the dynamic part of DV-1 (every PARI entry), the
dynamic part of DV-11 (every fork of the frozen run_child, with its launching site and the wrapped-call intervals),
DV-13 and DV-14. Development only: never imported by an entry point, the wrapper or the checker. Started from
implementation-v2-r3/r3_dv7.py (the toy construction of stage R1's DV-7, reproduced; no r1, r2 or r3 module is
imported).

Called as `python3 -B r4_devchecks.py dv7 --out DIR`. Everything it writes goes under DIR.

Toy objects (NO ladder or fixture prime is solved; toy primes only):
  * n = m = 3 fixture data at 1033 and 1039 (stage R1's construction and declared stream label), n = m = 4 data at 1033;
  * toy ladder rungs chosen by the frozen a1_toy.toy_ladder (gp in capped children, launched through the DELIVERED r4
    launch recorder installed over the frozen run_child in this development process): 1021 (addendum role) and the
    first complete prime of a declared candidate list (v2 role);
  * toy copies of BOTH r4 plans (same ids, same metadata, same repair block): G1 -> fixture --p 1033, G2 -> fixture
    --p 1039, F-4 -> the toy n = 4 data, the 4111 build and its six cells -> the v2-role toy prime with the m = 5 / m = 4
    roles played by m = 3 / m = 2; controls_a1, the addendum build and its six cells -> 1021. Toy-only m = 2 watchdog
    keys are added to both toy copies AND to the toy copy of trial-plan-v2.json (so R-9 runs unmodified).
SYNTHETIC PACKAGES, DECLARED HERE BEFORE ANY LAUNCH: G3 (anchor-identity) and G4 (controls) are synthetic in the toy
(their frozen commands hard-code 16777291 / 4111 and are run instead by DV-18 (a), (b) at those parameters, RB-5); the
v2 builds and cells at 262151 and 16777291 are synthetic rows. A synthetic package carries no launch record and no
r4-conforming manifest, so the r4 checker FAILs it; under RB-4 (b) / RL-4 every later package that requires or reads
one is REFUSED by preflight. Each toy package is therefore run as RK-4 (a) / RF-4 (a) word the development method:
the wrapper's preflight first, its refusals recorded verbatim; the refusals that name a DECLARED SYNTHETIC package
("R-7 (RB-4 (b)) the r4 checker on gate package <synthetic>" and "R-8 (RL-4; RF-3 (b) designed stop) read package
<synthetic>") are EXPECTED and listed; ANY OTHER refusal is a DV-7 failure and the package is not launched; then the
wrapper's `launch` for the package in this process. No bypass flag, mode or argument is added to the r4 wrapper.
Contingency launches are not exercised here (every R-12 refusal is exercised by DV-6).

SE-5 PROBE (run ONCE): world A runs toy G1 with PYTHONHASHSEED "0" (the delivered condition, SE-6); world B runs the
SAME toy G1 in a separate process with PYTHONHASHSEED "12345", set by the development-only in-process override of
r4_run_wrapper.DRIVER_PYTHONHASHSEED (SC-11 (f)); both under SE-2 with K = 5. REG-1 (d-parsed) compares world B's
RECORDED results with world A's. Any difference in a REG-1-compared field STOPS the stage.
The rest of the lineage runs in world A (delivered condition), with REG-1 in R-7 evaluated against world B's G1.
In-process stubs (disclosed): r4_run_wrapper.git_tree_state returns the r4 files tracked and clean; a synthetic
TASK-20260924-4a47e5 phase-A receipt in scratch binds the r4 files as they are (commit_sha: the repository HEAD) and a
synthetic phase-B receipt binds the toy v2 packages (RC-8 form).
DEVELOPMENT TRACE (entry and checker child processes, via the shim; never delivered): (1) the module global `os` of
v2_solver is a delegating proxy whose `fork` calls the real os.fork and, in the PARENT only, appends one trace line
(pid, argv[0] and tag read from the frozen _run_child_locked frame, the launching site from the stack, whether a
wrapped call is in progress); it sits BENEATH the RL-1 recorder (the recorder, its RG-1 callback and the RL-5
read-back are untouched); (2) r4_resolve._call_original (the documented development indirection) is wrapped to log
each wrapped call's interval; (3) cypari2.Pari is subclassed to log PARI entries (DV-1 dynamic).
"""
''' + s[i1 + 4:]

# ---- the toy ladder: gp children through the delivered recorder installed in this process
rep('''    sys.path.insert(0, R.V2_DIR)
    sys.path.insert(0, R.A1_DIR)
    import a1_toy
    trail = []''', '''    sys.path.insert(0, R.V2_DIR)
    sys.path.insert(0, R.A1_DIR)
    import r4_devchecks as DC
    DC.recorder_in_this_process(os.path.join(tdir, "ladder_recorder_rundir"))   # the RL-1 installation (r4_recorder.install)
    import a1_toy
    trail = []''')

# ---- the shim: drop the run_child tracer (it would make RL-5 refuse; RG-3 (b)), add the os proxy beneath the recorder
rep('''            if _n == "v2_solver":
                rc = module.run_child
                def run_child(argv, *a, **k):
                    st = _stack()
                    t0 = time.time()
                    rec = rc(argv, *a, **k)
                    t1 = time.time()
                    _log("child_end", {"child_argv0": os.path.basename(argv[0]), "child_flags": [x for x in argv if x in ("-P", "-g", "--tool=callgrind")],
                                       "msolve_in_argv": any(os.path.basename(x) == "msolve" for x in argv), "tag": _tag_of(argv),
                                       "launcher": _launcher(st), "inside_wrapper_original_call": DEPTH[0] > 0,
                                       "t_start": t0, "t_end": t1, "outcome": rec.get("outcome"),
                                       "rlimit_as_child_getrlimit": rec.get("rlimit_as_child_getrlimit")})
                    return rec
                module.run_child = run_child''', '''            if _n == "v2_solver" and TRACE:
                module.os = _OsProxy()''')
rep('''_orig_call_original = RS._call_original''', '''class _OsProxy(object):
    """Development fork tracer (DV-7 / DV-11 only): delegates every attribute to the real os module; fork() calls the
    real os.fork (so every os.register_at_fork callback, the RG-1 observer included, runs as without the proxy) and, in
    the PARENT only, appends one trace line. It sits beneath the RL-1 recorder and replaces no function the RL-5
    read-back names."""
    def __getattr__(self, name):
        return getattr(os, name)
    def fork(self):
        pid = os.fork()
        if pid > 0:
            argv = None
            f = sys._getframe(1)
            while f is not None:
                if f.f_code.co_name == "_run_child_locked":
                    argv = f.f_locals.get("argv")
                    break
                f = f.f_back
            st = _stack()
            _log("fork", {"child_pid": pid, "t": time.time(), "child_argv0": os.path.basename(argv[0]) if argv else None,
                          "tag": _tag_of(argv) if argv else None, "launcher": _launcher(st),
                          "inside_wrapper_original_call": DEPTH[0] > 0,
                          "msolve_in_argv": bool(argv) and any(os.path.basename(x) == "msolve" for x in argv)})
        return pid

_orig_call_original = RS._call_original''')
rep('''for n in names if n[0].startswith(("v2_", "a1_", "r3_")))[-160:]''', '''for n in names if n[0].startswith(("v2_", "a1_", "r4_")))[-160:]''')

# ---- toy build: receipt commit_sha HEAD
rep('''        dump(rec_a, {"synthetic": SYN, "commit_sha": "dv7-synthetic-not-a-commit", "path_sha256": {p: sha(os.path.join(R.REPO, p)) for p in r4files}})''',
'''        head = subprocess.run(["git", "-C", R.REPO, "rev-parse", "HEAD"], capture_output=True, text=True,
                              env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")).stdout.strip()
        dump(rec_a, {"synthetic": SYN, "commit_sha": head, "path_sha256": {p: sha(os.path.join(R.REPO, p)) for p in r4files}})''')
rep('''import random
import shutil
import sys''', '''import random
import re
import shutil
import subprocess
import sys''')

# ---- the lineage: preflight, classify, launch
rep('''    import r4_reg1 as REG
    real_git = W.git_tree_state''', '''    import r4_reg1 as REG
    K.FROZEN_LAUNCHER = [sys.executable, "-B", shims["check_toy.py"]]        # the wrapper's admission checks use it too
    real_git = W.git_tree_state''')
rep('''    pkgs = []

    def run(w, rid, entry_kind, seed, reg_runs, reg_receipt):''', '''    pkgs = []
    by0 = {pk["order"]: pk for pk in v2r4["packages"]}
    SYNTH = {G[2], G[3]} | {by0[o]["run_id"] for o in range(13, 27)}      # declared synthetic (DV-7 docstring), before any launch
    report["declared_synthetic_packages"] = sorted(SYNTH)
    pat = re.compile(r"(?:gate package|read package) (RUN-GFPN-[0-9a-f]{6})")

    def classify(refusals):
        exp, unexp = [], []
        for r in refusals:
            m = pat.search(r)
            if (r.startswith("R-7 (RB-4 (b)) the r4 checker on gate package ") or r.startswith("R-8 (RL-4; RF-3 (b) designed stop) read package ")) \\
                    and m and m.group(1) in SYNTH:
                exp.append(r)
            else:
                unexp.append(r)
        return exp, unexp

    def run(w, rid, entry_kind, seed, reg_runs, reg_receipt):''')
rep('''        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = W.main([rid])
        t1 = datetime.datetime.now(datetime.timezone.utc)
        man = manifest_row(W.RUNS, rid)
        row = {"world": w, "run_id": rid, "entry": entry_kind, "PYTHONHASHSEED_set": seed, "wrapper_rc": rc, "wrapper_output": buf.getvalue().splitlines(),''',
'''        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            refusals, info = W.preflight(rid)
        exp_ref, unexp_ref = classify(refusals)
        rc = None
        if not unexp_ref:
            with contextlib.redirect_stdout(buf):
                rc = W.launch(rid, None, info)
        t1 = datetime.datetime.now(datetime.timezone.utc)
        man = manifest_row(W.RUNS, rid)
        row = {"world": w, "run_id": rid, "entry": entry_kind, "PYTHONHASHSEED_set": seed, "wrapper_launch_rc": rc,
               "preflight_refusals_expected": exp_ref, "preflight_refusals_unexpected": unexp_ref, "launched": rc is not None,
               "wrapper_output": buf.getvalue().splitlines(),
               "r4_verdict": man and (man.get("verdict") or {}).get("r4_verdict"),
               "r4_stop_classes": man and (man.get("verdict") or {}).get("stop_classes"),
               "raw_result_writer": man and man.get("raw_result_writer"),
               "gate_package_checker": man and {k: (v.get("exit_status"), v.get("verdict")) for k, v in ((man.get("gate") or {}).get("gate_package_checker") or {}).items()},
               "required_package_checker": man and {k: (v.get("exit_status"), v.get("verdict")) for k, v in ((man.get("gate") or {}).get("required_package_checker") or {}).items()},''')
rep('''        print("   world %s %s %-4s rc=%s status=%s gate_pass=%s REG-1=%s hashseed=%s (%.0fs)" % (
            w, rid, entry_kind, rc, row["status"], row["gate_pass"], row["reg1_in_manifest"], row["hashseed_readback"], (t1 - t0).total_seconds()))''',
'''        print("   world %s %s %-4s launched=%s status=%s gate_pass=%s REG-1=%s verdict=%s hashseed=%s expected-refusals=%d unexpected=%s (%.0fs)" % (
            w, rid, entry_kind, rc is not None, row["status"], row["gate_pass"], row["reg1_in_manifest"], row["r4_verdict"], row["hashseed_readback"],
            len(exp_ref), unexp_ref, (t1 - t0).total_seconds()))''')
rep('''    # ---- (4) the r3 checker on every toy package that ran through the wrapper
    print("(4) the r3 checker on every toy package that ran through the wrapper")
    K.FROZEN_LAUNCHER = [sys.executable, "-B", shims["check_toy.py"]]
    checks = []
    for x in pkgs:''', '''    # ---- (4) the r4 checker on every toy package that ran through the wrapper (again, standalone; the wrapper already
    #          recorded each package's own verdict in its manifest)
    print("(4) the r4 checker on every toy package that ran through the wrapper")
    checks = []
    for x in pkgs:
        if not x["launched"]:
            continue''')
rep('''        checks.append({"world": x["world"], "run_id": x["run_id"], "rc": rc, "output": lines,
                       "failing_items": [l.strip()[2:] for l in lines if l.startswith("  - ")]})''',
'''        checks.append({"world": x["world"], "run_id": x["run_id"], "rc": rc, "output": lines,
                       "failing_items": [l.strip()[2:] for l in lines if l.startswith("  - ")],
                       "r4_verdict": next((l.split(": ", 1)[1] for l in lines if l.startswith("R4 VERDICT: ")), None)})''')
rep('''        "children_by_launcher": sorted({json.dumps([t.get("launcher"), t.get("child_argv0")]) for t in tr if t["event"] == "child_end"}),
        "gp_children": [{"package": t.get("package"), "launcher": t.get("launcher"), "getrlimit": t.get("rlimit_as_child_getrlimit")} for t in tr
                        if t["event"] == "child_end" and t.get("child_argv0") == "gp"],''',
'''        "children_by_launcher": sorted({json.dumps([t.get("launcher"), t.get("child_argv0")]) for t in tr if t["event"] == "fork"}),
        "gp_children": [{"package": t.get("package"), "launcher": t.get("launcher"), "pid": t.get("child_pid")} for t in tr
                        if t["event"] == "fork" and t.get("child_argv0") == "gp"],''')
rep('''    def check_ok(c):
        if c["world"] == "B":
            return c["failing_items"] == ["SE-6: the driver process read back PYTHONHASHSEED '12345', not '0'"]
        return c["rc"] == 0
    exp_ok = {"all_run_packages_completed_valid": all(x["status"] == "completed_valid" for x in pkgs),''',
'''    def check_ok(c):
        if c["world"] == "B":
            return c["failing_items"] == ["SE-6: the driver process read back PYTHONHASHSEED '12345', not '0'"]
        return c["rc"] == 0 and c["r4_verdict"] in ("PASS", "PASS_ZL")
    exp_ok = {"no_unexpected_preflight_refusal": all(not x["preflight_refusals_unexpected"] for x in pkgs),
              "every_package_launched": all(x["launched"] for x in pkgs),
              "every_world_A_manifest_verdict_PASS_or_PASS_ZL": all(x["r4_verdict"] in ("PASS", "PASS_ZL") for x in pkgs if x["world"] == "A"),
              "all_run_packages_completed_valid": all(x["status"] == "completed_valid" for x in pkgs),''')
rep('''    report["not_exercised"] = {"anchor-identity": "hard-codes p' = 16777291 and runs the Sage comparator on the anchor system; exercising it solves an anchor system at a ladder prime (forbidden: R3S-9)",
                               "controls": "hard-codes fixture_n3(4111) and C.ladder_entry(4111 / 262151 / 16777291); every system it solves is at a fixture or ladder prime (forbidden: R3S-9); its in-process PARI point (4111, n = 3) is covered by DV-2",''',
'''    report["not_exercised"] = {"anchor-identity": "hard-codes p' = 16777291 and the Sage comparator; not run at toy scale; run ONCE by DV-18 (b) at its hard-coded parameters (RB-5)",
                               "controls": "hard-codes fixture_n3(4111) and C.ladder_entry(4111 / 262151 / 16777291); not run at toy scale; run ONCE by DV-18 (a) at its hard-coded parameters (RB-5)",''')
rep('''    for g, why in ((G[2], "anchor-identity is not exercisable at toy scale (hard-coded p' = 16777291 and the Sage anchor system)"),
                   (G[3], "controls is not exercisable at toy scale (hard-coded fixture field at 4111 and ladder primes 4111, 262151, 16777291)")):''',
'''    for g, why in ((G[2], "anchor-identity is not run at toy scale (hard-coded p' = 16777291 and the Sage anchor system; DV-18 (b) runs it)"),
                   (G[3], "controls is not run at toy scale (hard-coded fixture field at 4111 and ladder primes 4111, 262151, 16777291; DV-18 (a) runs it)")):''')
open(p, "w").write(s)
print("edited", p)
