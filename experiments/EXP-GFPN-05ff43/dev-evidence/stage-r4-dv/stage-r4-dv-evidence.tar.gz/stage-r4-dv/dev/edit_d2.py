"""Scratch editor: DV-18 (d) attempt 3 -- the (d)-specific plan copy replaces the G4 plan run id by the label ONLY at
gate.blocking_packages / gate.v2_blocking_packages and in every package's `requires` (the package entry already carries
the label); the id maps and every other value stay as in the (a) harness's plan copy."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''for key, attr in (("v2", "PLAN_V2_R4"), ("a1", "PLAN_A1_R4")):
    txt = open(getattr(R, attr)).read()
    n = txt.count(PLAN_RID)
    dp = os.path.join(D, "trial-plan-%s-r4.dev-d.json" % key)
    open(dp, "w").write(txt.replace(PLAN_RID, LABEL))
    dplans[key] = {"path": dp, "occurrences_of_the_G4_plan_run_id_replaced_by_the_label": n}
    setattr(R, attr, dp)'''
b = '''for key, attr in (("v2", "PLAN_V2_R4"), ("a1", "PLAN_A1_R4")):
    pl = R.load_json(getattr(R, attr))
    changed = []
    for gk in ("blocking_packages", "v2_blocking_packages"):
        lst = (pl.get("gate") or {}).get(gk)
        if isinstance(lst, list) and PLAN_RID in lst:
            pl["gate"][gk] = [LABEL if x == PLAN_RID else x for x in lst]
            changed.append("/gate/%s" % gk)
    for i, pk_ in enumerate(pl["packages"]):
        if PLAN_RID in (pk_.get("requires") or []):
            pk_["requires"] = [LABEL if x == PLAN_RID else x for x in pk_["requires"]]
            changed.append("/packages/%d/requires" % i)
    dp = os.path.join(D, "trial-plan-%s-r4.dev-d.json" % key)
    json.dump(pl, open(dp, "w"), indent=1)
    dplans[key] = {"path": dp, "paths_where_the_G4_plan_run_id_was_replaced_by_the_label": changed}
    setattr(R, attr, dp)'''
assert s.count(a) == 1
open(p, "w").write(s.replace(a, b))
print("edited")
