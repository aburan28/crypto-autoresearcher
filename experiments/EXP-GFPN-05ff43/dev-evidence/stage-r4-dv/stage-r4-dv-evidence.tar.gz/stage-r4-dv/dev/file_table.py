"""Scratch: the r4 file table: each implementation-v2-r4/ file, its sha256, its r3 origin with the origin's phase-A sha256
(TASK-20260924-f1fb0e snapshot receipt) or 'new'."""
import hashlib, json, os, sys
REPO = "/home/user/crypto-autoresearcher"
E = os.path.join(REPO, "experiments", "EXP-GFPN-05ff43")
rc = json.load(open(os.path.join(REPO, "coordination", "goals", "GOAL-GFPN-380702", "archives", "TASK-20260924-f1fb0e", "snapshot-receipt.json")))
ps = rc.get("path_sha256") or {}
ORIGIN = {"r4_accounting.py": "r3_accounting.py", "r4_check_run.py": "r3_check_run.py", "r4_common.py": "r3_common.py", "r4_devchecks.py": "r3_devchecks.py",
          "r4_devchecks_more.py": "r3_devchecks_more.py", "r4_dv12.py": "r3_dv12.py", "r4_dv16.py": "r3_dv16.py", "r4_dv6.py": "r3_dv6.py", "r4_dv7.py": "r3_dv7.py",
          "r4_entry_a1.py": "r3_entry_a1.py", "r4_entry_v2.py": "r3_entry_v2.py", "r4_gaps.py": None, "r4_inventory.py": "r3_inventory.py",
          "r4_make_plans.py": "r3_make_plans.py", "r4_recorder.py": None, "r4_reg1.py": "r3_reg1.py", "r4_resolve.py": "r3_resolve.py",
          "r4_run_wrapper.py": "r3_run_wrapper.py", "reg1-exclusion-list.json": "reg1-exclusion-list.json", "minted-run-ids.txt": None}
for f in sorted(os.listdir(os.path.join(E, "implementation-v2-r4"))):
    p = os.path.join(E, "implementation-v2-r4", f)
    h = hashlib.sha256(open(p, "rb").read()).hexdigest()
    o = ORIGIN.get(f, "?")
    if o:
        key = "experiments/EXP-GFPN-05ff43/implementation-v2-r3/" + o
        print("| `%s` | %s | `implementation-v2-r3/%s` (phase-A sha256 %s) |" % (f, h, o, ps.get(key, "NOT IN RECEIPT")))
    else:
        print("| `%s` | %s | new |" % (f, h))
