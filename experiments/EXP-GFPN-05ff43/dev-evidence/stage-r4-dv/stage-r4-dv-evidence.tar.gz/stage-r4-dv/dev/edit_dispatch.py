"""Scratch editor: DV-18 runs from scratch harness files (outside the delivered tree; LKA-7 scan scope), so the in-tree
dispatcher carries no dv18 entry."""
import sys
p = sys.argv[1]
s = open(p).read()
a = '''    if check.startswith("dv18"):
        import r4_dv18
        return r4_dv18.dispatch(check, out, rest)
'''
assert s.count(a) == 1
s = s.replace(a, "")
open(p, "w").write(s)
print("edited")
