"""Scratch editor: re-point the r3 stage's DV-17 harness (reference copy) to the r4 stage: the DELIVERED r4 launch
recorder is installed over the frozen run_child in the harness process (every callgrind child is launched through it
and recorded under a scratch run directory), and the recorded launch records are checked (pair equal to the cap)."""
import sys
p = sys.argv[1]
s = open(p).read()


def rep(a, b):
    global s
    assert s.count(a) == 1, a[:80]
    s = s.replace(a, b)


rep('''"""DV-17 (launchcover CG-5 (a)-(g); consumercover CC-8 (b), (d)) -- a DEVELOPMENT harness kept OUTSIDE
implementation-v2-r3/ so that the r3 layer has no launch site of its own (CC-1 / DV-11). Bundled under dv17/.''',
    '''"""DV-17 (launchcover CG-5 (a)-(g); consumercover CC-8 (b), (d)) -- r4 stage (TASK-20260924-d91a96). A DEVELOPMENT harness
kept OUTSIDE implementation-v2-r4/ so that the r4 layer has no launch site of its own (CC-1 / DV-11) and no load of the
frozen run_child (DEC-20260924-daf670 LKA-7). Bundled under dv17/. Derived from the r3 stage's dv17.py (reference copy).
r4 CHANGE: the DELIVERED r4 launch recorder (r4_recorder, installed by r4_devchecks.recorder_in_this_process, i.e. by
r4_recorder.install) replaces v2_solver.run_child in THIS process before the first call, so every callgrind child is
launched through it; its launch records (scratch run directory out/recorder_rundir) are checked: one per call, child
created, pair equal to the cap, child_end "exec".''')
rep('''sys.path.insert(0, V2)
import v2_solver as V           # noqa: E402  (frozen; imported read-only)''',
    '''sys.path.insert(0, V2)
sys.path.insert(0, os.path.join(EXP, "implementation-v2-r4"))
import v2_solver as V           # noqa: E402  (frozen; imported read-only)
import r4_devchecks as DC       # noqa: E402  (the delivered recorder installation helper)''')
rep('''    print("DV-17: %d entries verified, R = %d, timeout %d s, cap %d" % (len(inputs), R_CALLS, timeout, CAP), flush=True)''',
    '''    REC = DC.recorder_in_this_process(os.path.join(out, "recorder_rundir"))
    rep["recorder_installed"] = {"run_child_is_recorder": V.run_child is REC.launch_recorder}
    print("DV-17: %d entries verified, R = %d, timeout %d s, cap %d; r4 recorder installed: %s" % (len(inputs), R_CALLS, timeout, CAP,
                                                                                                 rep["recorder_installed"]), flush=True)''')
rep('''    rep["calls_made"] = n
    rep["finished"] = utc(time.time())
    rep["pass"] = stop is None and n == 36 * R_CALLS''',
    '''    rep["calls_made"] = n
    rep["finished"] = utc(time.time())
    lr = json.load(open(os.path.join(out, "recorder_rundir", "solver-events.json"))).get("launch_records") or []
    rep["launch_records"] = {"n": len(lr), "all_child_created": all(r.get("child_created") is True for r in lr),
                             "all_pair_equal_cap": all(r.get("rlimit_as_child_getrlimit") == {"soft": CAP, "hard": CAP} for r in lr),
                             "child_end_values": sorted({str(r.get("child_end")) for r in lr})}
    rep["pass"] = (stop is None and n == 36 * R_CALLS and len(lr) == n and rep["launch_records"]["all_child_created"]
                   and rep["launch_records"]["all_pair_equal_cap"])''')
open(p, "w").write(s)
print("edited")
