| `minted-run-ids.txt` | d5ca1e06f7595365d6e8cbc188c173b91d997bda2748924d312ae7dea20038a2 | new |
| `r4_accounting.py` | 93d95cbe8812015babb79f90fdeb3f21c8320d777aea6a15b6a914d31293a0b0 | `implementation-v2-r3/r3_accounting.py` (phase-A sha256 dca726f7cb35c107536ea92b1e51566b8ed1a4e1ee7a9110eac5836425757e38) |
| `r4_check_run.py` | b794adaa171538ac6e23b08195d13cf489085e0c159626e70332449d643c7181 | `implementation-v2-r3/r3_check_run.py` (phase-A sha256 939d7d7e5bc8a8c64f15df188f98f13b22ef7a9d696680f8e47854c2dbdcd14d) |
| `r4_common.py` | e9087ed6792751a0cb10d4c40efdc0fd201c90da0eab693915d823e3479a074e | `implementation-v2-r3/r3_common.py` (phase-A sha256 7bb7b688250d69a2ca209a57fd70176727aa1fe225c95c9878076be407380868) |
| `r4_devchecks.py` | b156d15d2314a0e29c73024d9ee174d791fa469295b1120e4a6f2309bbd8f90d | `implementation-v2-r3/r3_devchecks.py` (phase-A sha256 b94cb0176c25a3ac3cec504a0d9d614f47495c49e95557f3cc770d1651652cfd) |
| `r4_devchecks_more.py` | aad8f2bf66ccb8fc1c3209ed8c36e46af50d915080e9eed5d945e680e728bfe7 | `implementation-v2-r3/r3_devchecks_more.py` (phase-A sha256 d17a10749d8c40c90adeded2e64ee82f42afd93b43b963dc14d0ab843f0c04bd) |
| `r4_dv12.py` | 922e28c5c90082910146249509f21aa15d316bd462564f3f9dc420467678a168 | `implementation-v2-r3/r3_dv12.py` (phase-A sha256 4c0103ec07ac5a3a5dbad8ed29c876dbeebe44ada0dda5d80fec4308727a6dd0) |
| `r4_dv16.py` | 7c864cb56707f80f74c721f3d87c4b8da3c1bc84136ccaedd25f0f41ec6fc802 | `implementation-v2-r3/r3_dv16.py` (phase-A sha256 7bc2df84d70dc87dadb7913a5b4e8529769d0066faa020869a3e62beaa1710b3) |
| `r4_dv6.py` | adbc6c909f9e378962d76c592e70415dfa1f6034593a33308cda55f74164256f | `implementation-v2-r3/r3_dv6.py` (phase-A sha256 23e82cac90c6411175ca7896fc3dc43384c75b5dfac050a68585c5d0457ae4d5) |
| `r4_dv7.py` | acb3a3546d82910f7f32b8029cccf66dc9f0958cd2fb16c8d551191661ec6ce7 | `implementation-v2-r3/r3_dv7.py` (phase-A sha256 1376cbd44ab3e73ff92da612281270270cc33a50b1f42fbd3869c17fd715a740) |
| `r4_entry_a1.py` | 1c1c8d9dbce54f151327fcb7a0cabba503ad2914118fe36c097ced48245badcb | `implementation-v2-r3/r3_entry_a1.py` (phase-A sha256 cefbb3348174bf02546129a65a9a0961b3ad5f60341d25ca4bfab1d54cb56f23) |
| `r4_entry_v2.py` | 82ac34b9056da15155961a5e7bf9096c70d58050ebcfcad5ca86df5961afb20d | `implementation-v2-r3/r3_entry_v2.py` (phase-A sha256 f79161999507cdb5438c1be39de21ba74d25ef745f490c08e56a600c28117fbd) |
| `r4_gaps.py` | 7051a8c674e524b828f52bf3b1d3d46ebc6f3d29a4529ec4bc2d734643ef6f70 | new |
| `r4_inventory.py` | bc84fb9241c184c13bb1f9b929ba5cec762c987691908b0a2fd2e1d380dd762b | `implementation-v2-r3/r3_inventory.py` (phase-A sha256 203b5be93998c6bc0d9994eaaaa64dcbe300f34e45cc6294d4f1c219d75fe81a) |
| `r4_make_plans.py` | bed0a21c3419d67807bac5ecba4495a01c4ded7fbd34f394433b94e0bbd900a3 | `implementation-v2-r3/r3_make_plans.py` (phase-A sha256 9143eef16951e894e5de5252bbe157c533970a3090e2becabadb24ee494f3ff7) |
| `r4_recorder.py` | d367bd7e682b341bbedfd1b0a27e645d29b02d7c14c2d26ecdcb80c7e35066f8 | new |
| `r4_reg1.py` | a4bdfcfc3c4c5254a79c3bf838ee4089adc0733a1f9fec6ab34409aa088bfa57 | `implementation-v2-r3/r3_reg1.py` (phase-A sha256 04ee68d350198340d9427d1b575febc8f8cfe99b4f5f59ffef832de7b04378f3) |
| `r4_resolve.py` | 324ce12e5247b3d9eed58d6503022ba379a54cfd19efdfee6dfb7508f5bb754e | `implementation-v2-r3/r3_resolve.py` (phase-A sha256 3a6828f42a6e8dd97fd487510fbb0c153ca8f51d9bcd0c310d1af96c8d5e3e15) |
| `r4_run_wrapper.py` | 65109323d9bc576a9a3d6082a9bed8ecbdd63ffaa90d6c6a3452806acf744404 | `implementation-v2-r3/r3_run_wrapper.py` (phase-A sha256 dd52a4bfad9c4bfb0e4e37ee8a24951e8992edf8d2f1dfcc112e9bcdbabb9c19) |
| `reg1-exclusion-list.json` | 4122bcb06c1c1bdd7613ef20fa62d09207916badf7786ad3c314a04094a99f2c | `implementation-v2-r3/reg1-exclusion-list.json` (phase-A sha256 4122bcb06c1c1bdd7613ef20fa62d09207916badf7786ad3c314a04094a99f2c) |
