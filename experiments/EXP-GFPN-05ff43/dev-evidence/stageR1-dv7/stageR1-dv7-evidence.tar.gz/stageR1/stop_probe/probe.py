# Stage-R1 STOP diagnosis (development only; scratch): the SAME msolve input, the v2 cell flags, 20 capped runs.
import hashlib, json, os, sys
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2")
import v2_solver as V
d = os.path.dirname(os.path.abspath(__file__))
inp = os.path.join(d, "input.ms")
rows = []
for i in range(20):
    out = os.path.join(d, "out_%02d.ms.out" % i)
    argv = V.msolve_argv(inp, out, threads=1)
    rec = V.run_child(argv, os.path.join(d, "out_%02d.log" % i), os.path.join(d, "out_%02d.err" % i), cap_bytes=10737418240, timeout_s=1800, count_instructions=False)
    err = open(os.path.join(d, "out_%02d.err" % i)).read()
    rows.append({"i": i, "outcome": rec["outcome"], "getrlimit": rec.get("rlimit_as_child_getrlimit"), "argv": [os.path.basename(a) for a in argv],
                 "out_sha256": hashlib.sha256(open(out, "rb").read()).hexdigest(), "not_squarefree": "not squarefree" in err,
                 "elim_line": [l for l in err.splitlines() if "Elimination polynomial" in l]})
json.dump({"input_sha256": hashlib.sha256(open(inp, "rb").read()).hexdigest(), "rows": rows}, open(os.path.join(d, "probe.json"), "w"), indent=1)
from collections import Counter
print("input sha256", hashlib.sha256(open(inp, "rb").read()).hexdigest())
print("argv", rows[0]["argv"])
print("distinct outputs:", Counter(r["out_sha256"][:16] for r in rows))
print("not squarefree runs:", [r["i"] for r in rows if r["not_squarefree"]])
print("getrlimit:", Counter(json.dumps(r["getrlimit"]) for r in rows), "outcomes:", Counter(r["outcome"] for r in rows))
