
import os, sys, json, re, traceback, importlib.abc, importlib.util
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R1_TOY_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r1_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
TRACE = os.environ.get("R1_TOY_TRACE")

def _log(ev, expr=None, extra=None):
    if not TRACE:
        return
    st = ["%s:%d" % (os.path.relpath(f.filename, CFG["exp_real"]), f.lineno) for f in traceback.extract_stack()[:-2]
          if "implementation-v2" in f.filename]
    rec = {"event": ev, "pid": os.getpid(), "argv": sys.argv[1:], "stack": st[-8:]}
    if expr:
        m = re.search(r"ffgen\(Mod\(1, (\d+)\)\*\((.*?)\), 'w\)", expr)
        if m:
            rec["p"] = int(m.group(1))
            rec["field_degree"] = max(int(x) for x in re.findall(r"w\^(\d+)", m.group(2)))
        rec["expr_head"] = expr[:200]
    if extra:
        rec.update(extra)
    with open(TRACE, "a") as fh:
        fh.write(json.dumps(rec) + "\n")

sys.addaudithook(lambda ev, args: _log("import:" + args[0]) if ev == "import" and args and args[0] in ("cypari2", "sage.all", "sage") else None)
import cypari2
_Base = cypari2.Pari
class TracingPari(_Base):
    def __init__(self, *a, **k):
        _log("cypari2.Pari()")
        super().__init__(*a, **k)
    def __call__(self, s, *a, **k):
        _log("cypari2.Pari.__call__", expr=str(s))
        return super().__call__(s, *a, **k)
cypari2.Pari = TracingPari

class Hook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"] and name != "v2_solver":
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"].get(_n, {}).items():
                setattr(module, k, v)
            if _n == "v2_solver":
                rc = module.run_child
                def run_child(argv, *a, **k):
                    _log("child", extra={"child_argv0": os.path.basename(argv[0]), "child_argv": [os.path.basename(x) for x in argv[:4]]})
                    return rc(argv, *a, **k)
                module.run_child = run_child
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())

import r1_check_run as K
mode, rd = sys.argv[1], sys.argv[2]
sys.exit(K.frozen_v2(rd) if mode == "frozen-v2" else K.frozen_a1(rd))
