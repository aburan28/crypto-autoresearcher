import sys
print('dv18 trivial development child: exec reached')
sys.exit(0)
