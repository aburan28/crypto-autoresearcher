EXP-GFPN-05ff43 r5 stage (TASK-20260925-a16f78) evidence bundle. Rebuilt across three continuation sessions; see
implementation-v2-r5.md sections 0, 0.1, 0.2 for the full account of each. This third continuation's own additions
bring every DV-1..DV-18 item to a genuinely verified real result except DV-10, whose own verdict remains a
disclosed, unresolved FAIL (see below and implementation-v2-r5.md section 9).

Contents from the first / second continuations (unchanged):
- dv2/, dv3/: real DV-2 and DV-3 development-check outputs, self-consistent with the delivered
  trial-plan-v2-r5.json / trial-plan-v2-a1-r5.json (same 42 minted ids).
- id_minting/: the 42-id minting transcript.
- hash_verification/: the 18-amendment-hash verification transcript.
- dv7/: real DV-7 output (the clean, second/"dv7c" run). dv7c.log; dv7.json; solver-events/ (21 files, one per
  launched package across both SE-5 worlds).
- dv18/f/: real DV-18 (f) (xiv)/(xv) output. run-first.json plus xiv-first/, xv-first/ (the FIRST attempt, FAILED
  on a disclosed solver-lock-contention harness reason, preserved not discarded); second/ (the clean re-run, PASS).

Contents from THIS (third) continuation (all new, all real; see implementation-v2-r5.md section 0.2 for the full
command-by-command account of each):
- dv1/: dv1_static.json (the real static inventory: 276 static hits, 17 comparator hits, call graph, capped Sage
  child probe, toolchain data) and dv1_verdict.json (this continuation's own computed PASS verdict against the
  r4-precedent criteria, since the delivered dispatcher has no separate DV-1 boolean-emitting script).
- dv5/dv5.json: the real DV-5 result (PASS), after this continuation added the required `## RC-4 (a)`/`## RC-4 (b)`
  sections to implementation-v2-r5.md and fixed six leftover r4-era literal bugs in the delivered
  r5_devchecks_more.py (disclosed as D-11). `writer_regenerates_byte_identically` confirms neither plan's bytes
  or sha256 changed.
- dv6/dv6{b,c,d}/dv6.json: the real DV-6 retry sequence, audited this continuation. dv6b/dv6c fail only because
  their own `expected_reason` strings say "the r4 checker" where the delivered r5 wrapper correctly prints "the r5
  checker" (a disclosed bug in the TEST's text, not the wrapper); dv6d (the fixed test) passes 85 wrapper cases +
  17 entry cases + the R-2 exhaustive sweep.
- dv8/dv8.json: the real DV-8 result (PASS), 219 reference files verified, every perturbation/control as designed.
- dv9/: dv9-inherited-reviewed.json (the full-schema DV-9 record from an earlier pass, structurally re-reviewed
  field by field this continuation, not merely trusted) and frozen-root-baseline-after.json (this continuation's
  own re-hash confirmation that all 140 frozen-root files remain byte-identical after this continuation's own two
  write-scope edits).
- dv10/dv10.json: the real, RECONFIRMED DV-10 shortfall. `pass: false` in its own JSON: id validity right now is
  real and true for all 42 ids, but no surviving mint-time "checked before use" transcript in the required format
  exists for the CURRENT 42 ids (the earliest visible mint_log.txt names different ids -- the compaction anomaly,
  D-2). This continuation deliberately did not reformat a later audit transcript to fake the missing evidence.
- dv11/dv11-dv7c-toy.json: the real DV-11 result (PASS), after fixing two leftover r4-era function-name bugs in
  the delivered r5_inventory.py (disclosed as D-9); dynamic counts verified against the clean dv7c toy environment
  (21 packages, all_equal true) after this continuation caught that its first attempt used a stale, contention-
  affected toy build (disclosed as D-10).
- dv12/: dv12-dv7c-toy.json (the real DV-12 result against the clean toy environment) and
  dv12-dv7-toy-first-attempt.json (the same check, first run against the stale toy environment before D-10 was
  caught -- both PASS identically; preserved, not discarded).
- dv15/dv15.json: the real DV-15 result (PASS), 75 outputs / 73 ok-classified verified against their archive
  receipts, 1268 real toy rows, 0 invariant violations.
- dv16/: dv16-dv7c-toy.json and dv16-dv7-toy-first-attempt.json, same pattern as dv12/.
- dv17/: dv17.json (the real DV-17 summary: 360/360 real callgrind calls, 0 differences from the archived
  reference) and dv17-calls.jsonl (the full per-call transcript).
- dv18/d/: d.json (the real DV-18 item (3) result -- the AD-1 (d1) two-copy discriminant, THE STAGE'S ONE
  SUBSTANTIVE NEW-LOGIC REQUIREMENT, now genuinely PASS on both copies), the (d)-specific development plan copies,
  and attempt1-eval-script-bug-preserved/ (the first attempt, whose one false-negative check was a bug in this
  continuation's own scratch evaluator, not in the delivered wrapper -- preserved, not discarded).
- dv18/pkg_reports/: package-{a,b,e}.json (DV-18 item (2), the three development packages, all completed_valid)
  and eval-{a,b,e}.json (DV-18 item (5), the LKA-4 path value tables, after fixing one key-name bug, D-7).
- dv18/alter-results.json: DV-18 items (4) and (7), the 33 in-place RI-3/RJ-5 gap-level and verdict-level checks
  with detectors on/off, every restore sha256-verified, the (32)/(26) positive control on every unaltered object
  first.
- dv18/gh/{g,h}.json: DV-18 (g) and (h), re-run fresh this continuation (not merely re-bundled from a prior spot
  check).

No member exceeds 50 MiB (largest is dv12/dv12-dv7c-toy.json at ~1.2 MiB).

An EARLIER, superseded bundle (different 42-id mint, produced by a pass of this same session lost across an early
context compaction -- see implementation-v2-r5.md section 0, deviation D-2) is preserved, never deleted, outside
the repository at <scratchpad>/r5/inherited-bundle/stage-r5-dv-evidence.tar.gz.inherited-stale and was never
archived or read by any package.

Contents from the FOURTH continuation (section 0.3 of implementation-v2-r5.md), all new, all real:
- dv10-remint-investigation/investigation-transcript.txt: the real commands and outputs run to determine whether
  DV-10's shortfall could be cleanly resolved by re-minting a fresh 42 ids and regenerating both r5 plans, without
  invalidating any already-verified DV item.
- dv10-remint-investigation/conclusion.txt: the conclusion (re-minting is NOT safe, because the current 42 ids are
  embedded as real filesystem paths and as the AD-1 (d1) discriminant's F-4 package image in already-genuinely-
  verified DV-7/DV-11/DV-12/DV-16/DV-18(3) evidence from this same stage) and why re-minting was therefore NOT
  performed. DV-10's shortfall is left exactly as the third continuation disclosed it, now doubly confirmed.
