
# DV-6 development shim (never delivered): runs a delivered entry point with ONE simulated fault.
#   pari:     the configuring call does not reach PARI (configure() skips allocatemem) -> the RC-2 (a) start read-back
#             through fresh cypari2.Pari() handles must refuse;
#   redirect: an import-time hook re-redirects a module constant after the driver module is imported (the RC-3 (1)
#             hazard) -> the RC-3 (d) read-back must refuse.
import os, sys, runpy, importlib.abc, importlib.util
sys.dont_write_bytecode = True
sys.path.insert(0, '/home/user/crypto-autoresearcher/experiments/EXP-GFPN-05ff43/implementation-v2-r2')
import r2_common as R
import r2_resolve as RS
mode, entry = os.environ["R2_DV6_MODE"], os.environ["R2_DV6_ENTRY"]
if mode == "se3_attr":
    # after the entry installs the wrapper, something rebinds v2_driver.solve -> the SE-3 read-back must refuse
    _inst = RS.install
    def install(mod, rd):
        rec = _inst(mod, rd)
        mod.solve = RS.solve.__r2_original__
        return rec
    RS.install = install
elif mode == "se3_orig":
    # the wrapper's recorded original is replaced by a non-frozen function -> the SE-3 read-back must refuse
    _inst = RS.install
    def install(mod, rd):
        rec = _inst(mod, rd)
        def solve(*a, **k):
            return RS._STATE["original"](*a, **k)
        RS.solve.__r2_original__ = solve
        return rec
    RS.install = install
elif mode == "pari":
    def configure(self):
        self.rec["configured_before_first_v2_or_a1_import"] = True
        self.rec["dv6_simulated_fault"] = "allocatemem not called"
        import cypari2
        cypari2.Pari()
        return self.rec
    R.PariStack.configure = configure
else:
    class Hook(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path, target=None):
            if name != ("a1_driver" if entry.endswith("r2_entry_a1.py") else "v2_driver"):
                return None
            sys.meta_path.remove(self)
            spec = importlib.util.find_spec(name)
            sys.meta_path.insert(0, self)
            orig = spec.loader.exec_module
            def exec_module(module, _o=orig, _n=name):
                _o(module)
                if _n == "v2_driver":
                    sys.modules["v2_common"].PLAN_PATH = os.path.join(R.EXP_DIR, "trial-plan-v2.json")
                else:
                    sys.modules["a1_common"].PROTOCOL_VERSION = "2-a1"
            spec.loader.exec_module = exec_module
            return spec
    sys.meta_path.insert(0, Hook())
sys.argv = [entry] + sys.argv[1:]
runpy.run_path(entry, run_name="__main__")
