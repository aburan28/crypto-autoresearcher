
import os, sys, json, re, traceback, datetime, importlib.abc, importlib.util, runpy
sys.dont_write_bytecode = True
CFG = json.load(open(os.environ["R2_DV12_CFG"]))
sys.path.insert(0, CFG["layer_dir"])
import r2_common as R
for k, v in CFG["R"].items():
    setattr(R, k, v)
import r2_resolve as RS
CASE = os.environ.get("R2_DV12_CASE") or "U"
TRACE = CFG["trace"]
SHIMLOG = CFG["shim_log"]
TARGET = CFG["target_tag"]

def _log(ev, extra=None):
    st = traceback.extract_stack()[:-2]
    rec = {"event": ev, "pid": os.getpid(), "case": CASE,
           "inside_wrapper": any(f.filename.endswith("r2_resolve.py") and f.name == "solve" for f in st),
           "stack": ["%s:%d" % (os.path.basename(f.filename), f.lineno) for f in st if "implementation-v2" in f.filename][-8:]}
    if extra:
        rec.update(extra)
    with open(TRACE, "a") as fh:
        fh.write(json.dumps(rec) + "\n")

import cypari2
_Base = cypari2.Pari
class TracingPari(_Base):
    def __call__(self, s, *a, **k):
        m = re.search(r"ffgen\(Mod\(1, (\d+)\)\*\((.*?)\), 'w\)", str(s))
        _log("cypari2.Pari.__call__", {"p": int(m.group(1)) if m else None,
             "field_degree": max(int(x) for x in re.findall(r"w\^(\d+)", m.group(2))) if m else None})
        return super().__call__(s, *a, **k)
cypari2.Pari = TracingPari

class Hook(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path, target=None):
        if name not in CFG["mods"] and name != "v2_solver":
            return None
        sys.meta_path.remove(self)
        spec = importlib.util.find_spec(name)
        sys.meta_path.insert(0, self)
        orig = spec.loader.exec_module
        def exec_module(module, _o=orig, _n=name):
            _o(module)
            for k, v in CFG["mods"].get(_n, {}).items():
                setattr(module, k, v)
            if _n == "v2_solver":
                rc = module.run_child
                def run_child(argv, *a, **k):
                    flags = [x for x in argv if x in ("-P", "-g")]
                    _log("child", {"child_argv0": os.path.basename(argv[0]), "child_flags": flags,
                                   "msolve_in_argv": any(os.path.basename(x) == "msolve" for x in argv)})
                    return rc(argv, *a, **k)
                module.run_child = run_child
        spec.loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, Hook())

# ---- DV-12 forcing (SF-6 (a)-(g)) on the r2_resolve indirections
OFFSET = [datetime.timedelta(0)]
calls = {}
def slog(rec):
    with open(SHIMLOG, "a") as fh:
        fh.write(json.dumps(rec, default=str) + "\n")
if CASE != "U":
    _orig_call = RS._call_original
    def forced(original, args, kwargs):
        tag = args[3]
        if tag != TARGET or kwargs.get("gb_only"):
            return _orig_call(original, args, kwargs)
        k = calls[tag] = calls.get(tag, 0) + 1
        res = _orig_call(original, args, kwargs)
        real = {"outcome": res.get("outcome"), "reason": res.get("reason"), "D": res.get("D"), "output_sha256": res.get("output_sha256")}
        force = (CASE in ("a", "b", "c", "e", "g") and k == 1) or CASE in ("d", "f")
        clause = {"b": "iv", "c": "v"}.get(CASE, "ii")
        if force:
            if clause == "ii":
                res.update(outcome="degenerate_parametrisation", D=None, D_defined=False, solutions=[],
                           reason="eliminating polynomial degree %s != quotient dimension %s (DV-12 FORCED by the development shim)"
                                  % ((res.get("solution_info") or {}).get("elim_degree"), res.get("dimension_of_quotient_printed")))
            elif clause == "iv":
                res.update(outcome="degenerate_parametrisation", D=None, D_defined=False, solutions=[],
                           reason="1 parsed solution(s) fail substitution into the descended system")
            else:
                res.update(outcome="positive_dimensional", D=None, D_defined=False, solutions=[], reason="msolve reported positive dimension")
                with open(os.path.join(args[0].rd, "solver", tag + ".ms.log"), "a") as fh:
                    fh.write("\n" + RS.RANDOM_FORM + "  (DV-12 shimmed log line)\n")
        if CASE == "e" and k == 2:
            res["input"]["sha256"] = "0" * 64
        if CASE == "f" and k == 2:
            OFFSET[0] += datetime.timedelta(seconds=float(args[4]) + 1.0)
        slog({"case": CASE, "tag": tag, "attempt": k, "forced": force, "clause_forced": clause if force else None, "real_result": real,
              "recorded_as": {"outcome": res.get("outcome"), "reason": res.get("reason")},
              "input_sha_forced": CASE == "e" and k == 2, "clock_offset_s": OFFSET[0].total_seconds()})
        return res
    RS._call_original = forced
    if CASE == "f":
        RS._now = lambda: RS._utc() + OFFSET[0]
    if CASE == "g":
        RS._wait_spacing = lambda prev_end: slog({"case": CASE, "wait_spacing_shimmed_away_after": str(prev_end)})
entry = CFG["entry"]
sys.argv = [entry] + sys.argv[1:]
runpy.run_path(entry, run_name="__main__")
