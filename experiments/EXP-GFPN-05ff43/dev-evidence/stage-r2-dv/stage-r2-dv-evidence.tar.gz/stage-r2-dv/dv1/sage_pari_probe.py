from sage.all import *
from sage.libs.pari import pari
print('R2PROBE parisize', int(pari.default('parisize')))
print('R2PROBE parisizemax', int(pari.default('parisizemax')))
print('R2PROBE stacksize', int(pari.stacksize()))
print('R2PROBE stacksizemax', int(pari.stacksizemax()))
import sage.version; print('R2PROBE sage_version', sage.version.version)
