#!/usr/bin/env python3
"""SC-5 bundle writer (TASK-20260923-de3a7d; development only). Packs the stage's development outputs from the
scratchpad into experiments/EXP-GFPN-05ff43/dev-evidence/stage-r2-dv/stage-r2-dv-evidence.tar.gz with a member list
MEMBERS.sha256 (sha256, bytes, path) inside. Excluded (left in the scratchpad, listed in EXCLUDED.json with size and a
tree sha256): byte copies of RUN-GFPN-ac4487 used as perturbation / synthetic-package scratch (dv6/runs, dv8/perturb,
dv_attempts/dv8_attempt1_harness_fault/perturb) and DV-15's re-extraction of the hash-bound archives (dv15a/extract).
No member exceeds 50 MiB (checked)."""
import gzip, hashlib, io, json, os, sys, tarfile
S = sys.argv[1]; OUT = sys.argv[2]
EXCL = ["dv6/runs", "dv8/perturb", "dv_attempts/dv8_attempt1_harness_fault/perturb", "dv15a/extract"]
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()
files, excluded = [], {}
for dp, dn, fn in os.walk(S):
    rel = os.path.relpath(dp, S)
    dn[:] = sorted(d for d in dn if os.path.join(rel, d).lstrip("./") not in EXCL)
    for f in sorted(fn):
        files.append(os.path.relpath(os.path.join(dp, f), S))
for e in EXCL:
    d = os.path.join(S, e)
    lines, size = [], 0
    for dp, _dn, fn in os.walk(d):
        for f in fn:
            p = os.path.join(dp, f); size += os.path.getsize(p)
            lines.append("%s  %s" % (sha(p), os.path.relpath(p, S)))
    lines.sort()
    excluded[e] = {"files": len(lines), "bytes": size, "tree_sha256_of_sorted_sha256_lines": hashlib.sha256("\n".join(lines).encode()).hexdigest(),
                   "why": "byte copy of RUN-GFPN-ac4487 (or of hash-bound archives) used as scratch input; the perturbation or extraction is declared in the check code and its report"}
files = sorted(files)
big = [f for f in files if os.path.getsize(os.path.join(S, f)) > 50 * 1024 * 1024]
assert not big, big
members = [(sha(os.path.join(S, f)), os.path.getsize(os.path.join(S, f)), "stage-r2-dv/" + f) for f in files]
mtxt = "".join("%s  %d  %s\n" % m for m in members)
etxt = json.dumps(excluded, indent=1, sort_keys=True) + "\n"
os.makedirs(os.path.dirname(OUT), exist_ok=True)
if os.path.exists(OUT):
    raise SystemExit("REFUSING: bundle exists")
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as tf:
    for name, data in (("stage-r2-dv/MEMBERS.sha256", mtxt.encode()), ("stage-r2-dv/EXCLUDED.json", etxt.encode())):
        ti = tarfile.TarInfo(name); ti.size = len(data); ti.mtime = 0; ti.mode = 0o644
        tf.addfile(ti, io.BytesIO(data))
    for f in files:
        ti = tf.gettarinfo(os.path.join(S, f), arcname="stage-r2-dv/" + f)
        ti.uid = ti.gid = 0; ti.uname = ti.gname = ""
        with open(os.path.join(S, f), "rb") as fh:
            tf.addfile(ti, fh)
with gzip.GzipFile(OUT, "wb", mtime=0) as gz:
    gz.write(raw.getvalue())
print("bundle", OUT, sha(OUT), os.path.getsize(OUT), "members", len(members) + 2)
open(os.path.join(S, "bundle-members.sha256"), "w").write(mtxt)
open(os.path.join(S, "bundle-excluded.json"), "w").write(etxt)
