default(parisize, 256000000);
default(parisizemax, 4000000000);
print("R2GP N=", my(g = ffgen(Mod(1, 16777291)*(16777289*w^0 + 1*w^3), 'w)); my(E = ellinit([0, subst(2*w^0, 'w, g), 0, subst(1*w^1, 'w, g), subst(0, 'w, g)])); ellcard(E));
quit;
