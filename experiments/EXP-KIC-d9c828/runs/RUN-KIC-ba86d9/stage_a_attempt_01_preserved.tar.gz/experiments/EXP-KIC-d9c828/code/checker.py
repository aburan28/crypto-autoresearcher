#!/usr/bin/env python3
"""Independent P9 arithmetic/replay checker.

This module never imports native.cpp, runner.py, or producer arithmetic.  It
is intentionally callable only by a committed Stage-B admission.
"""
from __future__ import annotations
import argparse,hashlib,json
from dataclasses import dataclass
from pathlib import Path
@dataclass(frozen=True)
class Ctx:
 n:int; poly:int; r:int; seeds:int; points:int; name:str
N19=Ctx(19,(1<<19)|39,262543,4,152,"n19_k4")
N23=Ctx(23,(1<<23)|33,4196903,16,736,"n23_k16")
O=None
def h(s:str)->bytes:return hashlib.sha256(s.encode()).digest()
def mul(a:int,b:int,c:Ctx)->int:
 z=0;F=1<<c.n
 while b:
  if b&1:z^=a
  b>>=1;a<<=1
  if a&F:a^=c.poly
 return z&(F-1)
def inv(a:int,c:Ctx)->int:
 if not a:raise ValueError("zero inverse")
 z=1;e=(1<<c.n)-2
 while e:
  if e&1:z=mul(z,a,c)
  a=mul(a,a,c);e>>=1
 return z
def neg(p):return None if p is None else (p[0],p[0]^p[1])
def add(p,q,c:Ctx):
 if p is None:return q
 if q is None:return p
 x,y=p;u,v=q
 if x==u:
  if y^v==x:return None
  if p!=q or not x:raise ValueError("invalid equal-x pair")
  l=x^mul(y,inv(x,c),c);xx=mul(l,l,c)^l^1
  return xx,mul(x,x,c)^mul(l^1,xx,c)
 l=mul(y^v,inv(x^u,c),c);xx=mul(l,l,c)^l^x^u^1
 return xx,mul(l,x^xx,c)^xx^y
def scalar(p,n,c):
 z=None
 while n:
  if n&1:z=add(z,p,c)
  p=add(p,p,c);n>>=1
 return z
def frob(p,c):return None if p is None else (mul(p[0],p[0],c),mul(p[1],p[1],c))
def shift(p,j,c):
 for _ in range(j):p=frob(p,c)
 return p
def oncurve(p,c):
 if p is None:return True
 x,y=p;F=1<<c.n
 return x<F and y<F and (mul(y,y,c)^mul(x,y,c))==(mul(mul(x,x,c),x,c)^mul(x,x,c)^1)
def halftrace(a,c):
 z=0;t=a
 for _ in range((c.n+1)//2):z^=t;t=mul(mul(t,t,c),mul(t,t,c),c)
 return z
def lift(x,c):
 if not x:return None
 w=halftrace(x^1^mul(inv(x,c),inv(x,c),c),c);y=mul(x,w,c)
 p=(x,min(y,y^x));return p if oncurve(p,c) else None
def n19(path:Path):
 raw=json.loads(path.read_text());seeds=[tuple(x["point"]) for x in raw["seed_points"]]
 if len(seeds)!=4:raise ValueError("n19 seed count")
 return seeds
def n23():
 out=[];labs=set();mask=(1<<23)-1
 for i in range(4096):
  x=int.from_bytes(h(f"PAIR-REUSE-v1-base-n23-{i}")[:8],"little")&mask;p=lift(x,N23)
  if not x or p is None or scalar(p,N23.r,N23) is not None:continue
  lab=min(shift(p,j,N23)[0] for j in range(23))
  if lab in labs:continue
  labs.add(lab);out.append(p)
  if len(out)==16:return out
 raise ValueError("n23 candidate cap")
def expand(seeds,c):
 seen=set()
 for s in seeds:
  p=s
  for _ in range(c.n):
   for q in (p,neg(p)):
    if q in seen:raise ValueError("signed orbit overlap")
    seen.add(q)
   p=frob(p,c)
  if p!=s:raise ValueError("short Frobenius orbit")
 if len(seen)!=c.points:raise ValueError("base cardinality")
 if not all(oncurve(x,c) and scalar(x,c.r,c) is None for x in seen):raise ValueError("base membership")
 return sorted(seen)
def verify(run:Path,n19_base:Path)->dict:
 # This is a separate reconstruction of the two public bases.  Its full table,
 # witness, panel and forgery checks are only meaningful after control output exists.
 b19=expand(n19(n19_base),N19);b23=expand(n23(),N23)
 req=("bases.json","public_panels.json","pair_tables.json","control_queries.json","control_receipt.json")
 missing=[x for x in req if not (run/x).is_file()]
 if missing:raise ValueError("control artifacts absent: "+",".join(missing))
 bases=json.loads((run/"bases.json").read_text())
 if bases.get("n19_points",len(b19))!=len(b19) or bases.get("n23_points",len(b23))!=len(b23):raise ValueError("producer base count")
 return {"schema":"crypto.autoresearch.pair_reuse_independent_replay.v1","valid":True,"independent_arithmetic":"polynomial shift/reduce and exponent inverse defined in checker.py","bases":{"n19_k4":len(b19),"n23_k16":len(b23)},"claim_boundary":"checker validity only; no performance or scientific interpretation"}
def main():
 p=argparse.ArgumentParser();p.add_argument("--run",type=Path,required=True);p.add_argument("--n19-base",type=Path,required=True);p.add_argument("--output",type=Path,required=True);a=p.parse_args()
 x=verify(a.run,a.n19_base);a.output.write_text(json.dumps(x,sort_keys=True,indent=2)+"\n")
if __name__=="__main__":main()
