// P9 public-synthetic pair-reuse worker.  It deliberately accepts no scalars,
// oracle metadata, retained base, or retained table in a cold-job invocation.
#include <CommonCrypto/CommonDigest.h>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
using namespace std;
static void need(bool x,const string&s){if(!x)throw runtime_error(s);}
struct Pm{int n;uint32_t poly,r;int seeds,points;string id;};
static Pm pm19{19,(1u<<19)|39,262543,4,152,"n19_k4"},pm23{23,(1u<<23)|33,4196903,16,736,"n23_k16"};
static Pm P; static uint32_t F,M;
struct C {uint64_t add=0,mul=0,inv=0,batch=0,canon=0;}; static C c;
static uint32_t mul(uint32_t a,uint32_t b){c.mul++;uint64_t z=0;while(b){if(b&1)z^=a;b>>=1;a<<=1;if(a&F)a^=P.poly;}return uint32_t(z&M);}
static uint32_t sq(uint32_t a){return mul(a,a);} static uint32_t inv(uint32_t a){need(a,"zero inverse");c.inv++;uint32_t x=1,e=F-2;while(e){if(e&1)x=mul(x,a);a=sq(a);e>>=1;}return x;}
struct Pt{uint32_t x=UINT32_MAX,y=0;bool inf()const{return x==UINT32_MAX;}bool operator==(const Pt&q)const{return x==q.x&&y==q.y;}bool operator<(const Pt&q)const{return x<q.x||(x==q.x&&y<q.y);}};
static Pt O(){return{};} static Pt neg(Pt a){if(!a.inf())a.y^=a.x;return a;}
static uint64_t key(Pt a){return a.inf()?UINT64_MAX:(uint64_t(a.x)<<P.n)|a.y;}
static bool curve(Pt a){return a.inf()||(a.x<F&&a.y<F&&(sq(a.y)^mul(a.x,a.y))==(mul(sq(a.x),a.x)^sq(a.x)^1));}
static Pt add(Pt a,Pt b){c.add++;if(a.inf())return b;if(b.inf())return a;if(a.x==b.x){if((a.y^b.y)==a.x)return O();need(a==b&&a.x,"bad equal-x");uint32_t l=a.x^mul(a.y,inv(a.x)),x=sq(l)^l^1;return{x,sq(a.x)^mul(l^1,x)};}uint32_t l=mul(a.y^b.y,inv(a.x^b.x)),x=sq(l)^l^a.x^b.x^1;return{x,mul(l,a.x^x)^x^a.y};}
static Pt scalar(Pt a,uint32_t n){Pt z=O();while(n){if(n&1)z=add(z,a);a=add(a,a);n>>=1;}return z;} static Pt fr(Pt a){return a.inf()?a:Pt{sq(a.x),sq(a.y)};} static Pt sh(Pt a,int j){while(j--)a=fr(a);return a;}
static vector<Pt> batch_add(Pt p,const vector<Pt>& v){c.batch++;vector<Pt>out(v.size());vector<uint32_t>d,pre;vector<size_t>id;uint32_t total=1;for(size_t i=0;i<v.size();i++){Pt q=v[i];if(p.inf()){out[i]=q;continue;}if(q.inf()){out[i]=p;continue;}if(p.x==q.x){out[i]=add(p,q);continue;}id.push_back(i);d.push_back(p.x^q.x);pre.push_back(total);total=mul(total,d.back());}if(!id.empty()){uint32_t back=inv(total);for(size_t z=id.size();z-->0;){size_t i=id[z];Pt q=v[i];uint32_t reciprocal=mul(back,pre[z]);back=mul(back,d[z]);uint32_t l=mul(p.y^q.y,reciprocal),x=sq(l)^l^p.x^q.x^1;out[i]={x,mul(l,p.x^x)^x^p.y};}}return out;}
static string read(const string&p){ifstream f(p);need(bool(f),"cannot read "+p);return string(istreambuf_iterator<char>(f),{});} static void out(const string&p,const string&s){ofstream f(p);need(bool(f),"cannot write "+p);f<<s<<"\n";}
static vector<Pt> pairs(const string&s,const string&needle){vector<Pt>v;size_t at=0;while((at=s.find(needle,at))!=string::npos){at=s.find('[',at);if(at==string::npos)break;size_t comma=s.find(',',at),end=s.find(']',comma);if(comma==string::npos||end==string::npos)break;try{v.push_back({uint32_t(stoul(s.substr(at+1,comma-at-1))),uint32_t(stoul(s.substr(comma+1,end-comma-1)))});}catch(...){ }at=end+1;}return v;}
static array<uint32_t,8> digest(const string&s){unsigned char d[32];CC_SHA256(s.data(),CC_LONG(s.size()),d);array<uint32_t,8>w{};for(int i=0;i<8;i++)for(int j=0;j<4;j++)w[i]|=uint32_t(d[4*i+j])<<(8*j);return w;}
static uint32_t halftrace(uint32_t a){uint32_t z=0,t=a;for(int j=0;j<=(P.n-1)/2;j++){z^=t;t=sq(sq(t));}return z;}
static bool lift(uint32_t x,Pt&out){if(!x)return false;uint32_t q=x^1^mul(inv(x),inv(x)),w=halftrace(q);if((sq(w)^w)!=q)return false;uint32_t y=mul(x,w),other=y^x;out={x,min(y,other)};return curve(out);}
struct Base{vector<Pt>seed,all;unordered_set<uint64_t> mem;};
static Base base19(const string&path){string s=read(path);auto v=pairs(s,"\"point\"");need(v.size()==4,"n19 seed parse");Base b;b.seed=v;for(Pt z:v){need(curve(z)&&scalar(z,P.r).inf(),"n19 seed validation");Pt q=z;for(int j=0;j<P.n;j++){for(Pt r:{q,neg(q)}){need(b.mem.insert(key(r)).second,"n19 orbit overlap");b.all.push_back(r);}q=fr(q);}need(q==z,"n19 short orbit");}sort(b.all.begin(),b.all.end());need(int(b.all.size())==P.points,"n19 cardinality");return b;}
static Base base23(){Base b;set<uint32_t> labels;for(uint32_t i=0;b.seed.size()<16&&i<4096;i++){auto d=digest("PAIR-REUSE-v1-base-n23-"+to_string(i));uint32_t x=(uint32_t(uint64_t(d[0])|(uint64_t(d[1])<<32)))&M;Pt z;if(!x||!lift(x,z)||!scalar(z,P.r).inf())continue;uint32_t lab=x;for(int j=1;j<P.n;j++)lab=min(lab,sh(z,j).x);if(!labels.insert(lab).second)continue;b.seed.push_back(z);}need(b.seed.size()==16,"n23 seed candidate cap");for(Pt z:b.seed){Pt q=z;for(int j=0;j<P.n;j++){for(Pt r:{q,neg(q)}){need(b.mem.insert(key(r)).second,"n23 orbit overlap");b.all.push_back(r);}q=fr(q);}need(q==z,"n23 short orbit");}sort(b.all.begin(),b.all.end());need(int(b.all.size())==P.points,"n23 cardinality");return b;}
static Base makebase(const string&n19){return P.n==19?base19(n19):base23();}
struct Normal{uint32_t beta=0;vector<uint32_t>poly,dual,nib,back;Normal(){for(uint32_t z=1;z<F;z++){vector<uint32_t>a;uint32_t t=z;for(int i=0;i<P.n;i++){a.push_back(t);t=sq(t);}map<int,uint32_t>q;for(uint32_t x:a){while(x){int k=31-__builtin_clz(x);if(!q.count(k)){q[k]=x;break;}x^=q[k];}}if(int(q.size())==P.n){beta=z;poly=a;break;}}need(beta,"normal basis");for(int bit=0;bit<P.n;bit++){uint32_t v=1u<<bit,mask=0;map<int,pair<uint32_t,uint32_t>>q;for(int i=0;i<P.n;i++){uint32_t x=poly[i],m=1u<<i;while(x){int k=31-__builtin_clz(x);if(!q.count(k)){q[k]={x,m};break;}x^=q[k].first;m^=q[k].second;}}while(v){int k=31-__builtin_clz(v);need(q.count(k),"normal solve");v^=q[k].first;mask^=q[k].second;}dual.push_back(mask);}int chunks=(P.n+3)/4;nib.assign(chunks*16,0);back.assign(chunks*16,0);for(int z=0;z<chunks;z++)for(int a=0;a<16;a++)for(int k=0;k<4;k++)if(z*4+k<P.n&&(a>>k&1)){nib[z*16+a]^=dual[z*4+k];back[z*16+a]^=poly[z*4+k];}}
 uint32_t to(uint32_t x)const{uint32_t z=0;for(int i=0;i<(P.n+3)/4;i++)z^=nib[i*16+((x>>(4*i))&15)];return z;}static uint32_t rot(uint32_t x,int j){j%=P.n;return j?((x<<j)|(x>>(P.n-j)))&M:x;}pair<uint64_t,int> canon(Pt p)const{c.canon++;if(p.inf())return{UINT64_MAX,0};uint32_t x=to(p.x),best=F;int bj=0;for(int j=0;j<P.n;j++){auto z=rot(x,j);if(z<best)best=z,bj=j;}return{best,bj};}};
struct Row{Pt a,b,sum;}; struct Tbl{unordered_map<uint64_t,pair<uint16_t,uint16_t>> e;unordered_map<uint64_t,Row>n;};
static bool rowless(const Row&a,const Row&b){return tie(a.a.x,a.a.y,a.b.x,a.b.y,a.sum.x,a.sum.y)<tie(b.a.x,b.a.y,b.b.x,b.b.y,b.sum.x,b.sum.y);}
static void insert_row(Tbl&t,uint64_t k,const Row&r){auto it=t.n.find(k);if(it==t.n.end()||rowless(r,it->second))t.n[k]=r;}
static Tbl table(const Base&b,const Normal*no,bool normal){Tbl t;if(!normal){for(int i=0;i<P.points;i++)for(int j=i;j<P.points;j++)t.e.emplace(key(add(b.all[i],b.all[j])),make_pair(i,j));}else for(int i=0;i<P.seeds;i++)for(int k=i;k<P.seeds;k++)for(int j=0;j<P.n;j++)for(int sg:{1,-1}){Pt u=b.seed[i],v=sh(b.seed[k],j);if(sg<0)v=neg(v);Pt s=add(u,v);auto [z,r]=no->canon(s);Pt a=sh(u,r),bb=sh(v,r);if(bb<a)swap(a,bb);insert_row(t,z,Row{a,bb,add(a,bb)});}return t;}
static bool lookup(Pt target,const Base&b,const Tbl&t,const Normal*no,bool normal,Pt&u,Pt&v){if(!normal){auto it=t.e.find(key(target));if(it==t.e.end())return false;u=b.all[it->second.first];v=b.all[it->second.second];return add(u,v)==target;}auto[z,j]=no->canon(target);auto it=t.n.find(z);if(it==t.n.end())return false;Pt r=sh(target,j);int sg=r==it->second.sum?1:r==neg(it->second.sum)?-1:0;if(!sg)return false;u=sh(it->second.a,(P.n-j)%P.n);v=sh(it->second.b,(P.n-j)%P.n);if(sg<0)u=neg(u),v=neg(v);return b.mem.count(key(u))&&b.mem.count(key(v))&&add(u,v)==target;}
static vector<Pt> loadq(const string&path){auto q=pairs(read(path),"[");need(q.size()>=512,"Q-only panel parse");for(Pt x:q)need(curve(x)&&scalar(x,P.r).inf(),"panel point");return q;}
static void worker(const string&base,const string&qfile,const string&arm,int count,const string&output){bool n=arm=="canonical_normal_x";need(n||arm=="expanded","arm");Base b=makebase(base);unique_ptr<Normal> no;if(n)no=make_unique<Normal>();auto start=chrono::steady_clock::now();Tbl t=table(b,no.get(),n);auto q=loadq(qfile);need(count==1||count==32||count==512,"M");ostringstream j;j<<"{\"schema\":\"crypto.autoresearch.pair_reuse_job.v1\",\"regime\":\""<<P.id<<"\",\"arm\":\""<<arm<<"\",\"M\":"<<count<<",\"queries\":[";for(int z=0;z<count;z++){Pt a,v,w;bool ok=false;int hit=-1,probes=0;for(int i=0;i<P.points;i++){probes++;if(lookup(add(q[z],neg(b.all[i])),b,t,no.get(),n,a,v)){w=b.all[i];ok=true;hit=i;break;}}if(z)j<<",";j<<"{\"status\":\""<<(ok?"SAT":"UNSAT")<<"\",\"third_index\":"<<hit<<",\"probes\":"<<probes<<",\"witness\":"<<(ok?("[["+to_string(a.x)+","+to_string(a.y)+"],["+to_string(v.x)+","+to_string(v.y)+"],["+to_string(w.x)+","+to_string(w.y)+"]"):"null")<<"}";}j<<"],\"table_keys\":"<<(n?t.n.size():t.e.size())<<",\"elapsed_seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}";out(output,j.str());}
static void control(const string&base,const string&outdir){Base a=base19(base);P=pm23;F=1u<<P.n;M=F-1;Base b=base23();ostringstream z;z<<"{\"schema\":\"crypto.autoresearch.pair_reuse_bases.v1\",\"n19_points\":"<<a.all.size()<<",\"n23_points\":"<<b.all.size()<<",\"n23_seed_coordinates\":[";for(size_t i=0;i<b.seed.size();i++){if(i)z<<",";z<<"["<<b.seed[i].x<<","<<b.seed[i].y<<"]";}z<<"]}";out(outdir+"/bases.json",z.str());}
int main(int argc,char**argv){try{need(argc>=2,"mode");string mode=argv[1];string reg,base,q,arm,outp;int mc=0;for(int i=2;i+1<argc;i+=2){string k=argv[i],v=argv[i+1];if(k=="--regime")reg=v;else if(k=="--n19-base")base=v;else if(k=="--q-only")q=v;else if(k=="--arm")arm=v;else if(k=="--M")mc=stoi(v);else if(k=="--output")outp=v;}P=reg=="n23_k16"?pm23:pm19;F=1u<<P.n;M=F-1;if(mode=="--job")worker(base,q,arm,mc,outp);else if(mode=="--control")control(base,outp);else throw runtime_error("mode");}catch(const exception&e){cerr<<e.what()<<"\n";return 2;}}
