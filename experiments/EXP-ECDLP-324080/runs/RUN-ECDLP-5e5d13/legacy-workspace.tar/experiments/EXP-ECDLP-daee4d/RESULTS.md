# Stage 1 — O-EXCESS

Curves measured: 2
- p=997 a=7 b=5 N=1051 excess=0.088550 null_excess=0.055763 scalar_recover=1.0
- p=1009 a=5 b=1 N=1039 excess=0.057956 null_excess=0.057956 scalar_recover=1.0

No exponent move. No Magma/Sage/Bedrock.
