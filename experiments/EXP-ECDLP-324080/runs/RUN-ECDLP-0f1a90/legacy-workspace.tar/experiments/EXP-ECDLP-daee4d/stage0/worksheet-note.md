# Stage 0 freeze

Zero enumeration. Stage 1 must not begin until this freeze exists.
No Magma/Sage/Bedrock. GOAL-ECDLP2M-001.yaml is not edited.
