# Polynomial solver selection — software run

Measured costs on generated, bounded polynomial systems. No elliptic-curve or cryptanalytic task.

| Split | Selector | Mean PAR-2 cost (ms) | Speedup vs fixed |
|---|---|---:|---:|
| train | ridge | 12.422 | 1.026× |
| train | bandit | 12.313 | 1.035× |
| train | fixed | 12.747 | 1.000× |
| train | train_best_fixed | 12.691 | 1.004× |
| train | uniform_seeded | 12.728 | 1.001× |
| train | uniform_expected | 12.790 | 0.997× |
| train | retrospective_oracle | 12.311 | 1.035× |
| validation | ridge | 12.953 | 0.999× |
| validation | bandit | 12.766 | 1.014× |
| validation | fixed | 12.942 | 1.000× |
| validation | train_best_fixed | 12.987 | 0.997× |
| validation | uniform_seeded | 13.071 | 0.990× |
| validation | uniform_expected | 13.031 | 0.993× |
| validation | retrospective_oracle | 12.622 | 1.025× |
| test | ridge | 12.803 | 1.025× |
| test | bandit | 12.907 | 1.017× |
| test | fixed | 13.122 | 1.000× |
| test | train_best_fixed | 12.967 | 1.012× |
| test | uniform_seeded | 12.817 | 1.024× |
| test | uniform_expected | 12.953 | 1.013× |
| test | retrospective_oracle | 12.664 | 1.036× |
| test_unseen_family | ridge | 14.736 | 0.988× |
| test_unseen_family | bandit | 14.736 | 0.988× |
| test_unseen_family | fixed | 14.563 | 1.000× |
| test_unseen_family | train_best_fixed | 14.736 | 0.988× |
| test_unseen_family | uniform_seeded | 14.606 | 0.997× |
| test_unseen_family | uniform_expected | 14.572 | 0.999× |
| test_unseen_family | retrospective_oracle | 14.316 | 1.017× |

## What the numbers mean

The RL learner is a one-step contextual bandit trained offline on a fully measured training table. The retrospective oracle uses outcomes and cannot be deployed as a selector. PAR-2 charges a timeout twice its configured limit. Failed solves are never counted as fast.

Root extraction exhaustively evaluates the output basis over a small field grid. Output basis degree is recorded; intermediate degree, operation counts, and degree of regularity are not measured. Microbenchmark timing and a single fit seed do not establish an asymptotic result or broad generalization.

Completed actions: 92 / 92. Censored actions: 0.

## Full cost accounting

- input_generation: 0.000602 seconds
- independent_root_oracle: 0.002905 seconds
- label_acquisition_including_subprocess_startup: 23.546823 seconds
- input_feature_extraction: 0.000250 seconds
- model_fitting: 0.032277 seconds
- model_selection: 0.000085 seconds
- controls_including_separate_null_fit: 0.054515 seconds
- pipeline_wall_total: 23.640538 seconds
- Largest measured solver subprocess RSS: 81969152 bytes.

Controls and raw per-action observations are in controls.json and labels.jsonl. A valid learner may be slower than a fixed configuration. Timings exclude neither label acquisition nor fitting from the reported full-run overhead.
