# Polynomial solver selection — software run

Measured costs on generated, bounded polynomial systems. No elliptic-curve or cryptanalytic task.

| Split | Selector | Mean PAR-2 cost (ms) | Speedup vs fixed |
|---|---|---:|---:|
| train | ridge | 12.990 | 1.014× |
| train | bandit | 12.835 | 1.026× |
| train | fixed | 13.174 | 1.000× |
| train | train_best_fixed | 13.174 | 1.000× |
| train | uniform_seeded | 13.076 | 1.007× |
| train | uniform_expected | 13.265 | 0.993× |
| train | retrospective_oracle | 12.780 | 1.031× |
| validation | ridge | 13.080 | 1.016× |
| validation | bandit | 13.081 | 1.016× |
| validation | fixed | 13.292 | 1.000× |
| validation | train_best_fixed | 13.292 | 1.000× |
| validation | uniform_seeded | 13.260 | 1.002× |
| validation | uniform_expected | 13.234 | 1.004× |
| validation | retrospective_oracle | 12.789 | 1.039× |
| test | ridge | 13.309 | 1.000× |
| test | bandit | 13.366 | 0.996× |
| test | fixed | 13.309 | 1.000× |
| test | train_best_fixed | 13.309 | 1.000× |
| test | uniform_seeded | 13.273 | 1.003× |
| test | uniform_expected | 13.267 | 1.003× |
| test | retrospective_oracle | 12.937 | 1.029× |
| test_unseen_family | ridge | 14.911 | 1.000× |
| test_unseen_family | bandit | 14.981 | 0.995× |
| test_unseen_family | fixed | 14.911 | 1.000× |
| test_unseen_family | train_best_fixed | 14.911 | 1.000× |
| test_unseen_family | uniform_seeded | 15.824 | 0.942× |
| test_unseen_family | uniform_expected | 16.112 | 0.925× |
| test_unseen_family | retrospective_oracle | 14.513 | 1.027× |

## What the numbers mean

The RL learner is a one-step contextual bandit trained offline on a fully measured training table. The retrospective oracle uses outcomes and cannot be deployed as a selector. PAR-2 charges a timeout twice its configured limit. Failed solves are never counted as fast.

Root extraction exhaustively evaluates the output basis over a small field grid. Output basis degree is recorded; intermediate degree, operation counts, and degree of regularity are not measured. Microbenchmark timing and a single fit seed do not establish an asymptotic result or broad generalization.

Completed actions: 92 / 92. Censored actions: 0.

## Full cost accounting

- input_generation: 0.000512 seconds
- independent_root_oracle: 0.003022 seconds
- label_acquisition_including_subprocess_startup: 28.750526 seconds
- input_feature_extraction: 0.000290 seconds
- model_fitting: 0.026911 seconds
- model_selection: 0.000164 seconds
- controls_including_separate_null_fit: 0.060251 seconds
- pipeline_wall_total: 28.851381 seconds
- Largest measured solver subprocess RSS: 73711616 bytes.

Controls and raw per-action observations are in controls.json and labels.jsonl. A valid learner may be slower than a fixed configuration. Timings exclude neither label acquisition nor fitting from the reported full-run overhead.
