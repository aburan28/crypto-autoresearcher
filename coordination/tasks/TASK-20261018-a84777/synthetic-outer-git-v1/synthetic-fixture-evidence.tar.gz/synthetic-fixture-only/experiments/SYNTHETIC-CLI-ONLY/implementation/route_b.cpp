#include <iostream>
#include <string>
int main(int n,char**v) {
 if(n==2 && std::string(v[1])=="--self-test") {
  std::cout << "{\"synthetic_control\":true,\"frozen_worksheet_executed\":false}\n";
 } else {
  int fixture=9-2;
  std::cout << "{\"fixture_value\":" << fixture << ",\"synthetic_only\":true}\n";
 }
}
