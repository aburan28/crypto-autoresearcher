#include <cstdio>
#include <cstring>
int main(int n,char**v) {
 if(n==2 && std::strcmp(v[1],"--self-test")==0) {
  std::puts("{\"synthetic_control\":true,\"frozen_worksheet_executed\":false}"); return 0;
 }
 int fixture=2+5;
 std::printf("{\"synthetic_only\":true,\"fixture_value\":%d}\n",fixture);
}
