"""Seal terminal native receipts. Metadata only; never runs mathematical code."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import tarfile

ROOT = Path('/Volumes/SSD990-2/crypto-autoresearcher-isogeny-frontier-20261015')
BASE = ROOT / 'coordination/goals/GOAL-ISOU-f30a07/m44497'
OUT = BASE / 'execution/TASK-20261016-6db186'
SCRATCH = Path('/private/tmp/isou-compact-m44497-6db186')
RUNS = {name: ROOT / 'experiments/EXP-ISOU-0c7e60/runs' / rid for name, rid in (
    ('construct', 'RUN-ISOU-bb340e'), ('verify', 'RUN-ISOU-384b62'))}
assert (OUT / 'ended-utc.txt').is_file(), 'both adapters must be terminal'
assert not (OUT / 'native-evidence.tar.gz').exists()
assert not (OUT / 'observation.md').exists()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text()) if path.is_file() else None


anomalies = []
plan_path = ROOT / 'experiments/EXP-ISOU-0c7e60/trial-plan.json'
plan = read_json(plan_path)
bindings = dict(plan['source_sha256'])
bindings[str(plan_path.relative_to(ROOT))] = 'fb453554fb217b39458c3c9cad1ca0959a13f878184d90d1097f67a4cba8a416'
bindings[str((BASE / 'dispatch_queue.json').relative_to(ROOT))] = 'd1e7c11947053727752934c8018a13282bc9ffa7e1e81bd888026d06fe3f3371'
selected = ROOT / 'coordination/goals/GOAL-ISOU-f30a07/m44497/dispatch_queue.json'
bindings[str(selected.relative_to(ROOT))] = 'd1e7c11947053727752934c8018a13282bc9ffa7e1e81bd888026d06fe3f3371'
post_identity = {}
for name, expected in bindings.items():
    actual = digest(ROOT / name)
    post_identity[name] = actual
    if actual != expected:
        anomalies.append('Post-run frozen binding mismatch: ' + name)
inputs = read_json(ROOT / 'experiments/EXP-ISOU-0c7e60/inputs.json')
binary = Path(inputs['binary'])
binary_after = digest(binary)
if binary_after != inputs['binary_sha256']:
    anomalies.append('Post-run executable hash mismatch')

records = {}
for name, run in RUNS.items():
    raw = read_json(run / 'raw-result.json')
    native_path = run / 'native' / ('construction.json' if name == 'construct' else 'verification.json')
    native = read_json(native_path)
    resource = read_json(run / 'native/native.receipt.json')
    if native is not None and native != raw:
        anomalies.append(name + ' native record differs from outer raw result')
    stderr = (run / 'native.stderr.log').read_text(errors='replace')
    match = re.search(r'^\s*([0-9.]+)\s+real\s+([0-9.]+)\s+user\s+([0-9.]+)\s+sys\s*$', stderr, re.M)
    cpu = None
    if match:
        real, user, system = map(float, match.groups())
        cpu = {'real_seconds': real, 'user_seconds': user, 'system_seconds': system,
               'user_plus_system_seconds_derived': user + system,
               'scope': 'public native command and waited descendants; excludes build, orchestration and other trials'}
    cert = run / 'native/certificate.json'
    records[name] = {'run_id': run.name, 'outer_raw_result': raw, 'native_result': native,
                     'native_resources': resource, 'os_time': cpu,
                     'certificate': {'sha256': digest(cert), 'bytes': cert.stat().st_size} if cert.is_file() else None,
                     'environment': read_json(run / 'environment.json')}

construct = records['construct']
verify = records['verify']
if verify['outer_raw_result'].get('status') == 'NOT_STARTED':
    if verify['native_result'] is not None or verify['native_resources'] is not None or verify['os_time'] is not None:
        anomalies.append('NOT_STARTED verification has unexpected native execution receipts')
if construct['certificate'] is not None:
    certificate_hash = construct['certificate']['sha256']
    sealed = (RUNS['construct'] / 'certificate.sha256').read_text().split()[0]
    if certificate_hash != sealed:
        anomalies.append('Post-run certificate differs from pre-verification seal')
    native_verified_input = (verify['native_result'] or {}).get('input_sha256')
    if native_verified_input is not None and native_verified_input != certificate_hash:
        anomalies.append('Independent native verifier input hash mismatch')


cert_path = RUNS['construct'] / 'native/certificate.json'
cert_data = read_json(cert_path)
certificate_metadata = None
if cert_data is not None:
    certificate_metadata = {'exponent': cert_data['exponent'],
        'degree_decimal_digits': len(cert_data['degree']),
        'source_icv1': cert_data['domain']['source_icv1'],
        'representation': cert_data['representation'],
        'a_decimal_characters': len(cert_data['a']),
        'b_decimal_characters': len(cert_data['b']),
        'public_evaluation_count': len(cert_data['evaluations']),
        'primality_metadata': cert_data['primality']}
    if cert_data['exponent'] != 44497 or cert_data['domain']['source_icv1'] != 'icv1-fp256-t432420386565659656852420866390673177327-76dadd18':
        anomalies.append('Certificate target metadata mismatch')
if (verify['outer_raw_result'] or {}).get('status') == 'VERIFIED_COMPACT':
    if verify['outer_raw_result'].get('degree_bits') != 44497 or verify['outer_raw_result'].get('source_icv1') != 'icv1-fp256-t432420386565659656852420866390673177327-76dadd18':
        anomalies.append('Verified target metadata mismatch')
    if verify['native_resources'] is None or verify['native_resources'].get('status') != 'PASS':
        anomalies.append('Verified result missing passing native resource receipt')

files = sorted(p for run in RUNS.values() for p in run.rglob('*') if p.is_file())
files += sorted(p for p in OUT.iterdir() if p.is_file())
before = {str(p.relative_to(ROOT)): digest(p) for p in files}
summary = {'schema': 'isogeny-compact-terminal-observation/v1',
           'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'goal': 'GOAL-ISOU-f30a07', 'experiment': 'EXP-ISOU-0c7e60',
           'task': 'TASK-20261016-6db186', 'native_records': records, 'certificate_metadata': certificate_metadata,
           'post_run_frozen_bindings': post_identity, 'post_run_binary_sha256': binary_after,
           'original_raw_file_count': len(files), 'anomalies': anomalies,
           'scientific_promotion': False}
archive = OUT / 'native-evidence.tar.gz'
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for path in files:
            tar.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
        extras = {
            'metadata/files.sha256': ''.join(d + '  ' + n + '\n' for n, d in sorted(before.items())).encode(),
            'metadata/terminal-summary.json': (json.dumps(summary, indent=2) + '\n').encode(),
            'metadata/collector.py': Path(__file__).read_bytes(),
            'metadata/conductor-wrapper-prefix.log': (SCRATCH / 'wrapper.log').read_bytes(),
        }
        for name, data in extras.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            tar.addfile(entry, io.BytesIO(data))
assert before == {str(p.relative_to(ROOT)): digest(p) for p in files}, 'raw files changed while packaging'


lines = ['# Terminal native M44497 compact observation', '',
 'EXP-ISOU-0c7e60 / TASK-20261016-6db186 / GOAL-ISOU-f30a07. Observation delivery only; independent postrun review and admission remain separate. One candidate, one conditional verifier, no retry or substitution.', '',
 'Constructor RUN-ISOU-bb340e status: ' + str(construct['outer_raw_result'].get('status')) + '.',
 'Independent verifier RUN-ISOU-384b62 status: ' + str(verify['outer_raw_result'].get('status')) + '.',
 'Exact target: degree2^44497-1 on secp256k1 ICV1 icv1-fp256-t432420386565659656852420866390673177327-76dadd18. Compact unreduced integer CM expression; native verifier recomputed degree primality and norm/point/dual checks. SEC2 p/n primality remains TRUSTED_STANDARD. No expanded-map challenge score or worldwide-record conclusion.', '',
 '## Recorded resources and custody', '', '~~~json',
 json.dumps({name: {'resources': value['native_resources'], 'os_time': value['os_time'], 'certificate': value['certificate']} for name, value in records.items()}, indent=2), '~~~', '',
 'OS CPU covers each public native command and its waited descendants only. Worker elapsed, supervisor elapsed and OS real are distinct retained timers; nested intervals are not summed. Canonical cpu_seconds:null is preserved. Shared-host single-instance observations establish no speed ratio.', '',
 'Certificate metadata (string lengths and counts; no additional arithmetic implementation):', '', '~~~json',
 json.dumps(certificate_metadata, indent=2), '~~~', '',
 '## Immutable provenance', '',
 'Sourcee82d80feaf82d3730576ccd9137911b336f9dab8; postrun binarySHA256 ' + binary_after + '.',
 'Frozen plan, source/input/adapter and approved queue were rehashed. Original bytes remained stable during packaging.',
 'Raw archiveSHA256 ' + digest(archive) + '; bytes ' + str(archive.stat().st_size) + '; original raw files ' + str(len(files)) + '.',
 'Archive contains the exact certificate, both original native/run trees, OS logs, per-file hashes, terminal metadata, collector source, OS first-start receipt and an explicitly labelled wrapper-prefix snapshot rather than a final close receipt.',
 'The initial goal-claim push refused a concurrent remote auto-update before any mathematics started. The existing claim/epoch was retained, the own branch fetched, its file diff verified empty, then a normal merge/push published4b2ebf2956eda0c038252aa461173c7c16428418. The goal-claim-published.json receipt preserves claim identity and launch timing; no native candidate was repeated.', '',
 'Anomalies: ' + (json.dumps(anomalies) if anomalies else 'none detected by this descriptive collector; independent review pending.'), '',
 'First constructor invocationUTC ' + (OUT / 'construct-started-utc.txt').read_text().strip() + '; OS worker start independently retained in construct-worker-start.json.',
 'Both adapters terminalUTC ' + (OUT / 'ended-utc.txt').read_text().strip() + '.',
 'Next: producer release, declared binderTASK-20261016-3e1186, reserved four-file reportTASK-20261016-6239ad at run-20261016T1205Z,22-path snapshotTASK-20261016-47aaec and independent postrun reviewTASK-20261016-4bad89. No new scientific trial is authorized here.', '']
with (OUT / 'observation.md').open('x') as stream:
    stream.write('\n'.join(lines))
print(json.dumps({'construct_status': construct['outer_raw_result'].get('status'),
 'verify_status': verify['outer_raw_result'].get('status'),
 'certificate': construct['certificate'], 'certificate_metadata': certificate_metadata,
 'archive_sha256': digest(archive), 'archive_bytes': archive.stat().st_size,
 'raw_files': len(files), 'anomalies': anomalies,
 'os_times': {name: value['os_time'] for name,value in records.items()}}, indent=2))

