#!/bin/sh
# Frozen native trial commands plus metadata/receipt orchestration only.
set -u
# Wait for the already published goal claim before any scientific command.
launch_wait=0
while [ ! -f /private/tmp/isou-compact-m44497-6db186/launch-authorized.flag ] && [ "$launch_wait" -lt 900 ]; do sleep 1; launch_wait=$((launch_wait+1)); done
if [ ! -f /private/tmp/isou-compact-m44497-6db186/launch-authorized.flag ]; then echo 'Scientific launch not authorized; no native trial started.'; exit 75; fi
cd /Volumes/SSD990-2/crypto-autoresearcher-isogeny-frontier-20261015 || exit 70
execution='coordination/goals/GOAL-ISOU-f30a07/m44497/execution/TASK-20261016-6db186'
adapter='coordination/goals/GOAL-ISOU-f30a07/m44497/native-command.sh'
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$execution/started-utc.txt"
prepare_metadata() {
  python3 - "$1" "$2" <<'PYMETA'
import datetime,json,subprocess,sys
from pathlib import Path
run=Path(sys.argv[1]);mode=sys.argv[2]
assert not run.exists(), 'fresh run required'
run.mkdir(parents=True)
def read(argv): return subprocess.check_output(argv,text=True).strip()
argv=['/bin/sh','coordination/goals/GOAL-ISOU-f30a07/m44497/native-command.sh',mode,str(run)]
env={'schema':'isogeny-native-execution-environment/v1','collected_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':{'cpu_model':read(['/usr/sbin/sysctl','-n','machdep.cpu.brand_string']),'memory_bytes':int(read(['/usr/sbin/sysctl','-n','hw.memsize'])),'logical_cpus':int(read(['/usr/sbin/sysctl','-n','hw.logicalcpu'])),'kernel_arch':read(['/usr/bin/uname','-sm']),'macos_version':read(['/usr/bin/sw_vers','-productVersion']),'load_average':read(['/usr/sbin/sysctl','-n','vm.loadavg']),'shared_host':True},'source_repository':'aburan28/crypto','source_commit':'e82d80feaf82d3730576ccd9137911b336f9dab8','source_dirty':False,'binary_sha256':'b3cbd6ac5d457a0f6d6398d1fcefc408f627e60be52c81c9009406486b61587b','harness_commit':read(['git','rev-parse','HEAD']),'harness_branch':read(['git','branch','--show-current']),'argv':argv,'goal':'GOAL-ISOU-f30a07','task':'TASK-20261016-6db186','approval':'DEC-20261016-4c28d0','execution':'direct native executable via frozen thin shell receipt adapter; Python used only for metadata','selected_dispatch_queue':'coordination/goals/GOAL-ISOU-f30a07/m44497/dispatch_queue.json','selected_dispatch_queue_sha256':'d1e7c11947053727752934c8018a13282bc9ffa7e1e81bd888026d06fe3f3371','trial_plan_sha256':'fb453554fb217b39458c3c9cad1ca0959a13f878184d90d1097f67a4cba8a416','actual_served_model':None,'actual_served_effort':None}
with (run/'environment.json').open('x') as f:f.write(json.dumps(env,indent=2)+'\n')
with (run/'command.txt').open('x') as f:f.write(' '.join(argv)+'\n')
PYMETA
}
construct='/Volumes/SSD990-2/crypto-autoresearcher-isogeny-frontier-20261015/experiments/EXP-ISOU-0c7e60/runs/RUN-ISOU-bb340e'
verify='/Volumes/SSD990-2/crypto-autoresearcher-isogeny-frontier-20261015/experiments/EXP-ISOU-0c7e60/runs/RUN-ISOU-384b62'
if ! prepare_metadata "$construct" construct; then
  printf '%s\n' 'Constructor metadata setup failed before native invocation; preserve files and inspect. No retry.' > "$execution/setup-failure.txt"
  exit 74
fi
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$execution/construct-started-utc.txt"
/bin/sh "$adapter" construct "$construct" > "$construct/stdout.log" 2> "$construct/stderr.log"
construct_adapter_exit=$?
printf '%s\n' "$construct_adapter_exit" > "$execution/construct-adapter.exit-code.txt"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$execution/construct-ended-utc.txt"
if ! prepare_metadata "$verify" verify; then
  printf '%s\n' 'Verification metadata setup failed before adapter invocation; preserve files and inspect. No retry.' > "$execution/verify-setup-failure.txt"
  exit 74
fi
# This is the adapter invocation time. Its frozen conditional gate records
# NOT_STARTED if construction or the sealed certificate is unsuitable.
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$execution/verify-adapter-invoked-utc.txt"
/bin/sh "$adapter" verify "$verify" > "$verify/stdout.log" 2> "$verify/stderr.log"
verify_adapter_exit=$?
printf '%s\n' "$verify_adapter_exit" > "$execution/verify-adapter.exit-code.txt"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$execution/verify-adapter-ended-utc.txt"
date -u '+%Y-%m-%dT%H:%M:%SZ' > "$execution/ended-utc.txt"
printf '%s\n' 'Both frozen adapters are terminal; actual native results remain authoritative.'
n=0
while [ ! -f /private/tmp/isou-compact-m44497-6db186/postprocessing.done ] && [ "$n" -lt 360 ]; do
  sleep 20
  n=$((n+1))
done
if [ ! -f /private/tmp/isou-compact-m44497-6db186/postprocessing.done ]; then
  printf '%s\n' 'Postprocessing was not acknowledged within two hours; preserve terminal receipts.'
  exit 124
fi
/Users/adamburan/.local/bin/conductor task release T-3264

