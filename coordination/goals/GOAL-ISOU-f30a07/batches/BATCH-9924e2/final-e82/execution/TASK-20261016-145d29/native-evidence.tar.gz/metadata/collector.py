"""Seal terminal native receipts. Metadata only; never runs mathematical code."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import tarfile

ROOT = Path('/Volumes/SSD990-2/crypto-autoresearcher-isogeny-frontier-20261015')
BASE = ROOT / 'coordination/goals/GOAL-ISOU-f30a07/batches/BATCH-9924e2/final-e82'
OUT = BASE / 'execution/TASK-20261016-145d29'
SCRATCH = Path('/private/tmp/isou-compact-m8191-145d29')
RUNS = {name: ROOT / 'experiments/EXP-ISOU-feb102/runs' / rid for name, rid in (
    ('construct', 'RUN-ISOU-bdbf5d'), ('verify', 'RUN-ISOU-2b2372'))}
assert (OUT / 'ended-utc.txt').is_file(), 'both adapters must be terminal'
assert not (OUT / 'native-evidence.tar.gz').exists()
assert not (OUT / 'observation.md').exists()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text()) if path.is_file() else None


anomalies = []
plan_path = ROOT / 'experiments/EXP-ISOU-feb102/trial-plan.json'
plan = read_json(plan_path)
bindings = dict(plan['source_sha256'])
bindings[str(plan_path.relative_to(ROOT))] = '76e6cedc60c78b9d4553058934d0aed06270c3958a5ff98b04a233f70ffabc98'
bindings[str((BASE / 'dispatch_queue.json').relative_to(ROOT))] = '47eb12f024cefb9922d1163c3e8f46f215235a3eb2c1d3390d4c2fcaa5a56e92'
selected = ROOT / 'coordination/goals/GOAL-ISOU-f30a07/batches/BATCH-9924e2/final-e82-report-completion/dispatch_queue.json'
bindings[str(selected.relative_to(ROOT))] = 'dcb5374e6dcaef2809e7f50f722073364ca8224517991a8087cde5cb2f427328'
post_identity = {}
for name, expected in bindings.items():
    actual = digest(ROOT / name)
    post_identity[name] = actual
    if actual != expected:
        anomalies.append('Post-run frozen binding mismatch: ' + name)
inputs = read_json(ROOT / 'experiments/EXP-ISOU-feb102/inputs.json')
binary = Path(inputs['binary'])
binary_after = digest(binary)
if binary_after != inputs['binary_sha256']:
    anomalies.append('Post-run executable hash mismatch')

records = {}
for name, run in RUNS.items():
    raw = read_json(run / 'raw-result.json')
    native_path = run / 'native' / ('construction.json' if name == 'construct' else 'verification.json')
    native = read_json(native_path)
    resource = read_json(run / 'native/native.receipt.json')
    if native is not None and native != raw:
        anomalies.append(name + ' native record differs from outer raw result')
    stderr = (run / 'native.stderr.log').read_text(errors='replace')
    match = re.search(r'^\s*([0-9.]+)\s+real\s+([0-9.]+)\s+user\s+([0-9.]+)\s+sys\s*$', stderr, re.M)
    cpu = None
    if match:
        real, user, system = map(float, match.groups())
        cpu = {'real_seconds': real, 'user_seconds': user, 'system_seconds': system,
               'user_plus_system_seconds_derived': user + system,
               'scope': 'public native command and waited descendants; excludes build, orchestration and other trials'}
    cert = run / 'native/certificate.json'
    records[name] = {'run_id': run.name, 'outer_raw_result': raw, 'native_result': native,
                     'native_resources': resource, 'os_time': cpu,
                     'certificate': {'sha256': digest(cert), 'bytes': cert.stat().st_size} if cert.is_file() else None,
                     'environment': read_json(run / 'environment.json')}

construct = records['construct']
verify = records['verify']
if verify['outer_raw_result'].get('status') == 'NOT_STARTED':
    if verify['native_result'] is not None or verify['native_resources'] is not None or verify['os_time'] is not None:
        anomalies.append('NOT_STARTED verification has unexpected native execution receipts')
if construct['certificate'] is not None:
    certificate_hash = construct['certificate']['sha256']
    sealed = (RUNS['construct'] / 'certificate.sha256').read_text().split()[0]
    if certificate_hash != sealed:
        anomalies.append('Post-run certificate differs from pre-verification seal')
    native_verified_input = (verify['native_result'] or {}).get('input_sha256')
    if native_verified_input is not None and native_verified_input != certificate_hash:
        anomalies.append('Independent native verifier input hash mismatch')

files = sorted(p for run in RUNS.values() for p in run.rglob('*') if p.is_file())
files += sorted(p for p in OUT.iterdir() if p.is_file())
before = {str(p.relative_to(ROOT)): digest(p) for p in files}
summary = {'schema': 'isogeny-compact-terminal-observation/v1',
           'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'goal': 'GOAL-ISOU-f30a07', 'experiment': 'EXP-ISOU-feb102',
           'task': 'TASK-20261016-145d29', 'native_records': records,
           'post_run_frozen_bindings': post_identity, 'post_run_binary_sha256': binary_after,
           'original_raw_file_count': len(files), 'anomalies': anomalies,
           'scientific_promotion': False}
archive = OUT / 'native-evidence.tar.gz'
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for path in files:
            tar.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
        extras = {
            'metadata/files.sha256': ''.join(d + '  ' + n + '\n' for n, d in sorted(before.items())).encode(),
            'metadata/terminal-summary.json': (json.dumps(summary, indent=2) + '\n').encode(),
            'metadata/collector.py': Path(__file__).read_bytes(),
            'metadata/conductor-wrapper-prefix.log': (SCRATCH / 'wrapper.log').read_bytes(),
        }
        for name, data in extras.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            tar.addfile(entry, io.BytesIO(data))
assert before == {str(p.relative_to(ROOT)): digest(p) for p in files}, 'raw files changed while packaging'

error = construct['outer_raw_result'].get('error', '')
error_hash = hashlib.sha256(error.encode()).hexdigest()
lines = ['# Terminal native compact-candidate observation', '',
         'EXP-ISOU-feb102 / TASK-20261016-145d29 / GOAL-ISOU-f30a07. Observation delivery only; independent review and any admission remain separate. No candidate was repeated or substituted.', '',
         'Constructor RUN-ISOU-bdbf5d status: ' + str(construct['outer_raw_result'].get('status')) + '.',
         'Constructor error prefix: ' + error[:90] + ('... (full error preserved in raw JSON)' if len(error) > 90 else ''),
         'Full constructor error UTF-8 SHA256: ' + error_hash + '; characters: ' + str(len(error)) + '.',
         'The terminal residue is retained in full in the original native JSON. This observation does not replace independent arithmetic review.', '',
         'Verification RUN-ISOU-2b2372 status: ' + str(verify['outer_raw_result'].get('status')) + '.',
         'Verification reason: ' + str(verify['outer_raw_result'].get('reason')) + '.',
         'Verification adapter invocation time is not a native-process start. Missing verification CPU/time/resource receipts remain unavailable, not measured zero.', '',
         '## Actual resources and terminal OS receipts', '', '```json',
         json.dumps({name: {'resources': value['native_resources'], 'os_time': value['os_time'], 'certificate': value['certificate']} for name, value in records.items()}, indent=2), '```', '',
         'OS CPU covers the public native process and waited descendants only. Canonical manifest cpu_seconds:null is preserved. The resource receipt, public native exit, adapter delivery exit and mathematical outcome are distinct. Shared-host single-instance values establish no speed ratio.', '',
         '## Immutable custody', '',
         'Source e82d80feaf82d3730576ccd9137911b336f9dab8; post-run executable SHA256 ' + binary_after + '.',
         'Frozen plan, original adapter/input/protocol and both queue bindings were rehashed. All original raw bytes remained unchanged while packaging.',
         'Raw archive: ' + str(archive.stat().st_size) + ' bytes; SHA256 ' + digest(archive) + '; original raw files: ' + str(len(files)) + '.',
         'Archive includes per-file hashes, exact terminal metadata, launcher/admission/timestamp receipts, both original run trees, collector source and an explicitly labelled Conductor wrapper-prefix snapshot (not a final close receipt).', '',
         'Anomalies: ' + (json.dumps(anomalies) if anomalies else 'none detected by this descriptive collector; independent validation pending.'), '',
         'Constructor first trial start: ' + (OUT / 'construct-started-utc.txt').read_text().strip() + '.',
         'Next: release original delivery, then publish the separately scoped single EXP/session report at run-20261016T1046Z covering construction and the verification nonstart, then terminal snapshot. No new candidate or source optimization is authorized by this observation.', '']
with (OUT / 'observation.md').open('x') as stream:
    stream.write('\n'.join(lines))
print(json.dumps({'construct_status': construct['outer_raw_result'].get('status'),
                  'verify_status': verify['outer_raw_result'].get('status'),
                  'archive_sha256': digest(archive), 'archive_bytes': archive.stat().st_size,
                  'raw_files': len(files), 'anomalies': anomalies,
                  'construct_os_time': construct['os_time']}, indent=2))
