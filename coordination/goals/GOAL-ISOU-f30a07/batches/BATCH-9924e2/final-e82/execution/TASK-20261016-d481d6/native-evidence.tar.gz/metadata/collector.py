"""Package terminal native receipts. No mathematical algorithm or trial launch."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import subprocess
import tarfile

ROOT = Path('/Volumes/SSD990-2/crypto-autoresearcher-isogeny-frontier-20261015')
RUN = ROOT / 'experiments/EXP-ISOU-32a530/runs/RUN-ISOU-93b2b3'
OUT = ROOT / 'coordination/goals/GOAL-ISOU-f30a07/batches/BATCH-9924e2/final-e82/execution/TASK-20261016-d481d6'
assert (OUT / 'executor.exit-code.txt').is_file() and (OUT / 'ended-utc.txt').is_file(), 'native adapter is not terminal'
alive = subprocess.run(['/bin/ps', '-p', '5885', '-o', 'pid='], capture_output=True, text=True)
assert not alive.stdout.strip(), 'original worker PID still exists; inspect before packaging'
assert not (OUT / 'observation.md').exists() and not (OUT / 'native-evidence.tar.gz').exists(), 'refuse overwrite'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inputs = json.loads((ROOT / 'experiments/EXP-ISOU-32a530/inputs.json').read_text())
anomalies = []
identity = {}
for name, spec in inputs['sealed_input_files'].items():
    p = ROOT / name
    identity[name] = {'sha256': digest(p), 'bytes': p.stat().st_size}
    if identity[name] != {'sha256': spec['sha256'], 'bytes': spec['bytes']}:
        anomalies.append('Post-run frozen input mismatch: ' + name)
    snapshot = RUN / 'native/artifact' / name.split('/construction/', 1)[1]
    if snapshot.is_file():
        snapshot_name = str(snapshot.relative_to(ROOT))
        identity[snapshot_name] = {'sha256': digest(snapshot), 'bytes': snapshot.stat().st_size}
        if identity[snapshot_name] != {'sha256': spec['sha256'], 'bytes': spec['bytes']}:
            anomalies.append('Judge snapshot input mismatch: ' + snapshot_name)
    else:
        anomalies.append('Judge snapshot input absent: ' + str(snapshot.relative_to(ROOT)))
binary = Path(inputs['binary'])
binary_after = digest(binary)
if binary_after != inputs['binary_sha256']:
    anomalies.append('Post-run executable hash mismatch')

entry_path = RUN / 'native/entry.json'
entry = json.loads(entry_path.read_text()) if entry_path.is_file() else None
raw = json.loads((RUN / 'raw-result.json').read_text())
if entry is None:
    anomalies.append('Native entry.json absent; outer fallback retained')
elif raw != entry:
    anomalies.append('Outer raw-result differs from native entry; both preserved')
resources = entry.get('verification') if isinstance(entry, dict) else None

trace_path = RUN / 'replay-trace.jsonl'
events = []
parse_errors = []
for index, line in enumerate(trace_path.read_bytes().splitlines(), 1):
    try:
        events.append(json.loads(line))
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        parse_errors.append({'line': index, 'error': str(error)})
begins = {}
stages = []
terminals = []
for event in events:
    kind = event.get('event')
    sid = event.get('stage_id')
    if kind == 'begin':
        if sid in begins:
            anomalies.append('Duplicate trace begin ' + str(sid))
        begins[sid] = event
    elif kind in ('end', 'error'):
        begin = begins.pop(sid, None)
        if begin is None or any(begin.get(k) != event.get(k) for k in ('stage', 'parent_id', 'pid')):
            anomalies.append('Unmatched trace completion ' + str(sid))
        else:
            elapsed = event['elapsed_ms_operational_only'] - begin['elapsed_ms_operational_only']
            stages.append({'stage_id': sid, 'parent_id': begin['parent_id'], 'stage': begin['stage'], 'event': kind, 'elapsed_ms_operational_only': elapsed})
    elif kind == 'terminal':
        terminals.append(event)
if parse_errors:
    anomalies.append('Trace has unparseable lines, retained byte for byte')

time_text = (RUN / 'native.stderr.log').read_text(errors='replace')
matched = re.search(r'^\s*([0-9.]+)\s+real\s+([0-9.]+)\s+user\s+([0-9.]+)\s+sys\s*$', time_text, re.M)
cpu = None
if matched:
    real, user, system = map(float, matched.groups())
    cpu = {'real_seconds': real, 'user_seconds': user, 'system_seconds': system, 'user_plus_system_seconds_derived': user + system, 'scope': 'public native judge and its waited descendants; excludes build, orchestration and historical attempts'}

files = sorted(p for p in RUN.rglob('*') if p.is_file())
files += sorted(p for p in OUT.iterdir() if p.is_file())
before = {str(p.relative_to(ROOT)): digest(p) for p in files}
summary = {'schema': 'isogeny-terminal-observation/v1', 'experiment': 'EXP-ISOU-32a530', 'task': 'TASK-20261016-d481d6', 'run': 'RUN-ISOU-93b2b3', 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'adapter_exit': int((OUT / 'executor.exit-code.txt').read_text()), 'native_entry': entry, 'outer_raw_result': raw, 'native_resources': resources, 'os_time_receipt': cpu, 'completed_or_error_stages': stages, 'unfinished_stages': list(begins.values()), 'trace_terminals': terminals, 'trace_parse_errors': parse_errors, 'post_run_input_identity': identity, 'post_run_binary_sha256': binary_after, 'anomalies': anomalies, 'raw_file_count': len(files), 'scientific_promotion': False}

archive = OUT / 'native-evidence.tar.gz'
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for p in files:
            tar.add(p, arcname=str(p.relative_to(ROOT)), recursive=False)
        extras = {
            'metadata/files.sha256': ''.join(value + '  ' + name + '\n' for name, value in sorted(before.items())).encode(),
            'metadata/terminal-summary.json': (json.dumps(summary, indent=2) + '\n').encode(),
            'metadata/collector.py': Path(__file__).read_bytes(),
            'metadata/conductor-wrapper-prefix.log': Path('/private/tmp/isou-profile-93b2b3-wrapper-20261016.log').read_bytes(),
        }
        for name, data in extras.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
after = {str(p.relative_to(ROOT)): digest(p) for p in files}
assert before == after, 'raw source changed during packaging; preserve archive for investigation'
archive_hash = digest(archive)
status = entry.get('status', 'MISSING') if isinstance(entry, dict) else 'MISSING'
reason = entry.get('reason') if isinstance(entry, dict) else None
lines = [
    '# Terminal native observation: EXP-ISOU-32a530 / RUN-ISOU-93b2b3',
    '',
    'Observation delivery only; no frontier, worldwide-record or performance promotion. The sealed map was not regenerated.',
    '',
    f'Native public status: {status}; reason: {reason}. Exact entry, resource receipt and outer result are embedded in the raw archive summary. Adapter exit acknowledges observation delivery and is not mathematical success.',
    '',
    'Source e82d80feaf82d3730576ccd9137911b336f9dab8; expected executable SHA256 ' + inputs['binary_sha256'] + '; post-run executable SHA256 ' + binary_after + '.',
    'Sealed map SHA256 82e3951488c793c5901ecf1dfeb3ab072b7cda16730899330df7caa9832a170c; all post-run input identities are retained in the summary.',
    '',
    '## Recorded resource and OS receipts',
    '', '```json', json.dumps({'native_resources': resources, 'os_time': cpu}, indent=2), '```',
    '',
    'Actual OS CPU is recorded only when the terminal time receipt parses. Its scope is the public native process and waited children, not the complete campaign. Sampled ps readings are not terminal CPU receipts.',
    '',
    '## Trace observations',
    '',
    'Times below are recorded monotonic wall differences in milliseconds on a shared host. Stages nest: do not add overlapping parent/child values. An unfinished stage has no completed duration; core COMPLETED, if present, is separate from public admission.',
    '', '| Stage ID | Parent ID | Stage | Terminal event | Derived elapsed ms |', '|---|---|---|---|---|',
]
for stage in sorted(stages, key=lambda row: row['stage_id']):
    lines.append(f"| {stage['stage_id']} | {stage['parent_id']} | {stage['stage']} | {stage['event']} | {stage['elapsed_ms_operational_only']} |")
for stage in sorted(begins.values(), key=lambda row: row['stage_id']):
    lines.append(f"| {stage['stage_id']} | {stage['parent_id']} | {stage['stage']} | no end recorded | unavailable |")
lines += ['', f'Parseable trace records: {len(events)}; parse errors: {len(parse_errors)}; terminal trace records: {len(terminals)}.', '', '## Custody and limitations', '', f'Archive native-evidence.tar.gz: {archive.stat().st_size} bytes; SHA256 {archive_hash}. It preserves {len(files)} original raw files, exact per-file hashes, parsed metadata, the collector source and an explicitly labelled Conductor wrapper prefix snapshot. Original raw files hash-identical before/after packaging. Wrapper prefix is not a final session-close receipt.', '', 'Anomalies: ' + (json.dumps(anomalies) if anomalies else 'none detected by this descriptive collector; independent validation remains pending.'), '', 'A timeout is censored verification evidence, not an algebraic counterexample. No speed ratio is derived from the historical timeout, this diagnostic, or shared-host observations. Native point/map acceptance and any leaderboard change require the separate complete admission/review gates. Next: report-only completion and terminal snapshot, then the already queued compact construction and fresh verification.', '']
with (OUT / 'observation.md').open('x') as output:
    output.write('\n'.join(lines))
print(json.dumps({'status': status, 'reason': reason, 'archive_sha256': archive_hash, 'archive_bytes': archive.stat().st_size, 'raw_files': len(files), 'anomalies': anomalies, 'os_time': cpu}, indent=2))
